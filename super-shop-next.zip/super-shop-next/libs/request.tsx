import axios from 'axios';
import Cookie from 'js-cookie';

const request = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_BASE_URL + '/api',
    headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
    },
});

request.interceptors.request.use((config) => {
    const token = Cookie.get('token');
    const lang = 'bn';

    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    config.headers.lang = lang ? lang : 'en';
    config.headers.apisecretkeycheck = process.env.NEXT_PUBLIC_SECRET_KEY;
    return config;
});

// request.interceptors.response.use(
//     (response) => response,
//     (error) => {
//         if (error.response && error.response.status === 403) {
//             // Redirect to the '/' page when a 403 error occurs
//             window.location.href = '/admin'; // Replace '/' with your desired page URL
//         }
//         return Promise.reject(error);
//     }
// );

export function apiRequest(base: any, query: any) {
    if (query === null) {
        return request(base);
    } else {
        return axios.get(base + query);
    }
}

export default request;
