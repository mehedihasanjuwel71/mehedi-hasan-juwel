import { useSelector } from 'react-redux';
import request from './request';
import { format } from 'date-fns';
import { toast } from 'react-toastify';

export const callApi = async (type: any, endPoint: any, payload?: any, token?: any, isFile?: boolean) => {
    try {
        if (type == 'post') {
            if (isFile) {
                const { data } = await request.post(endPoint, payload, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                });
                return data;
            } else {
                const { data } = await request.post(endPoint, payload);
                return data;
            }
        } else {
            if (token) {
                const { data } = await request.get(endPoint, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                return data;
            } else {
                const { data } = await request.get(endPoint);
                return data;
            }
        }
    } catch (error: any) {
        if (error.response && error.response.status === 400) {
            // Handle the 400 error status code appropriately
            let message = error.response.data.message[0];
            // Additional error handling logic for 400 status code
            return {
                success: false,
                message: message,
            };
        } else if (error.response && error.response.status === 422) {
            let message = error.response.data.message;
            // Additional error handling logic for 422 status code
            return {
                success: false,
                message: message,
            };
        } else if (error.response && error.response.status === 401) {
            // Handle other errors or status codes
            return {
                success: false,
                message: 'Unauthorized',
            };
        } else if (error.response && error.response.status === 403) {
            // Handle other errors or status codes
            window.location.href = '/admin';
            toast.error('Access denied!');
            return {
                success: false,
                message: 'Access denied',
            };
        } else if (error.response && error.response.status === 413) {
            // Handle other errors or status codes
            let message = error.response.data.message;
            return {
                success: false,
                message: message,
            };
        } else {
            return {
                success: false,
                message: 'Something happened wrong2',
            };
        }
    }
};

export const formattingDate = (date: any) => {
    const formattedDate = format(new Date(date), 'd MMM yyyy');
    return formattedDate;
};

export const formattingMonthDate = (date: any) => {
    const formattedDate = format(new Date(date), 'MMMM yyyy');
    return formattedDate;
};

export const countryArray = (input = null) => {
    const array = { BD: 'Bangladesh', AR: 'Argentina', US: 'United States', GB: 'United Kingdom' };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const statusArray = (input = null) => {
    const output = {
        1: 'Active',
        0: 'Inactive',
    };

    if (input === null) {
        return output;
    } else {
        return output[input];
    }
};

export const verifyArray = (input = null) => {
    const output = {
        1: 'Verified',
        0: 'Pending',
    };

    if (input === null) {
        return output;
    } else {
        return output[input];
    }
};

export const yesNoArray = (input = null) => {
    const output = {
        1: 'Yes',
        0: 'No',
    };

    if (input === null) {
        return output;
    } else {
        return output[input];
    }
};

export const enableArray = (input = null) => {
    const output = {
        1: 'Enable',
        0: 'Disable',
    };

    if (input === null) {
        return output;
    } else {
        return output[input];
    }
};

export const statusDueArray = (input = null) => {
    const output = {
        1: 'Due',
        0: 'Paid',
    };

    if (input === null) {
        return output;
    } else {
        return output[input];
    }
};

export const purchaseStatusArray = (input = null) => {
    const array = { 1: 'Receive', 0: 'Pending' };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const barcodeTypeArray = (input = null) => {
    const array = {
        Code25: 'Code25',
        Code39: 'Code39',
        Code128: 'Code128',
        EAN8: 'EAN8',
        EAN13: 'EAN13',
    };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};
export const dateTypeArray = (input = null) => {
    const array = {
        daily: 'Daily',
        weekly: 'Weekly',
        monthly: 'Monthly',
        yearly: 'Yearly',
    };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};
export const payTerm = (input = null) => {
    const array = { 1: 'Months', 2: 'Days' };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const productTypeArray = (input = null) => {
    const array = { 1: 'Single' };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const discountTypeArray = (input = null) => {
    const array = { 1: 'Percentage', 2: 'Fixed' };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const genderArray = (input = null) => {
    const array = { 1: 'Male', 2: 'Female', 3: 'Others' };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const calculateDiscount = (discountType: number, discount: number, price: number) => {
    if (discountType == DISCOUNT_TYPE_FIXED) {
        return discount.toFixed(2);
    } else {
        return (price * discount * 0.01).toFixed(2);
    }
};

export const currencyType = (input: string): string | undefined => {
    const array: Record<string, string> = {
        USD: '$',
        BDT: '৳',
        EUR: '€',
        INR: '₨',
        PKR: '₹',
    };

    return array[input]; // This might return undefined if input is not a valid currency code.
};

export const currencyTypeArray = (input = null) => {
    const array = {
        USD: '$',
        BDT: '৳',
        EUR: '€',
        INR: '₨',
        PKR: '₹',
    };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const currencyTextArray = (input = null) => {
    const array = {
        USD: 'United State Dollar',
        BDT: 'Bangladeshi Taka',
        EUR: 'Euro',
        INR: 'Indian Rupee',
        PKR: 'Pakistani Rupee',
    };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const languageArray = (input = null) => {
    const array = {
        en: 'English',
    };
    if (input === null) {
        return array;
    } else {
        return array[input];
    }
};

export const useGetCurrency = () => {
    const commonSetting = useSelector((state: any) => state.commonData);
    const currencyText = commonSetting ? commonSetting?.settings?.currency : 'USD';
    const currency = () => {
        return currencyType(currencyText);
    };
    return currency;
};

export const useCommonSettingData = () => {
    const commonSetting = useSelector((state: any) => state.commonData);
    const currency = () => {
        const currencyText = commonSetting ? commonSetting?.settings?.currency : 'USD';
        return currencyType(currencyText);
    };
    const checkMenuPermission = (urlRoute: any) => {
        let menuPermission = false;
        const user = commonSetting ? commonSetting?.user : '';
        if (user) {
            if (user.module == USER_MODULE_SUPERADMIN) {
                menuPermission = true;
            } else if (user.module == USER_MODULE_CUSTOMER) {
                menuPermission = false;
            } else {
                const checkRoute = rolePermissionRouteList(urlRoute);

                const permissionList = user.roles?.permissions;
                if (permissionList && permissionList.length > 0) {
                    
                    permissionList.map((permission: any) => {
                        if (permission.slug == checkRoute) {
                            menuPermission = true;
                        }
                    });
                }
            }
        }

        return menuPermission;
    };

    return { checkMenuPermission, currency };
};

export const rolePermissionRouteList = (input: any | null) => {
    const list = {
        'admin/user': 'user_list',
        'admin/user/add': 'user_create',
        'user/update-user': 'user_edit',
        'user/delete': 'user_delete',
        'user/update-user-status': 'user_update_status',
        'user/update-user-password': 'user_update_password',

        'admin/customer/add': 'customer_create',
        'user/update-customer': 'customer_edit',
        'admin/customer': 'customer_list',
        'user/customerdelete': 'customer_delete',

        'admin/attribute': 'attribute_list',
        'attribute/create': 'attribute_create',
        'attribute/update': 'attribute_edit',
        'attribute/delete': 'attribute_delete',

        'admin/attribute/type': 'attribute_type_list',
        'attribute-type': 'attribute_type_show',
        'attribute-type/create': 'attribute_type_create',
        'attribute-type/update': 'attribute_type_edit',
        'attribute-type/delete': 'attribute_type_delete',

        'admin/branch': 'branch_list',
        'admin/branch/add': 'branch_create',
        'branch/update': 'branch_edit',
        'branch/delete': 'branch_delete',

        'admin/expense': 'expense_list',
        // expense: 'expense_show',
        'expense/create': 'expense_create',
        'expense/update': 'expense_edit',
        'expense/delete': 'expense_delete',

        'admin/expense/category': 'expense_category_list',
        'expense-category': 'expense_category_show',
        'expense-category/create': 'expense_category_create',
        'expense-category/update': 'expense_category_edit',
        'expense-category/delete': 'expense_category_delete',

        'admin/files': 'file_upload',
        'file/delete': 'file_delete',

        'admin/payment-method': 'payment_method_list',
        'payment-method': 'payment_method_show',
        'payment-method/create': 'payment_method_create',
        'payment-method/update': 'payment_method_edit',
        'payment-method/delete': 'payment_method_delete',

        'admin/product': 'product_list',
        'admin/product/add': 'product_create',
        'product/update': 'product_edit',
        'product/delete': 'product_delete',

        'admin/brand': 'brand_list',
        'brand/add': 'brand_create',
        'brand/update': 'brand_edit',
        'brand/delete': 'brand_delete',

        'admin/product/category': 'product_category_list',
        'product-category': 'product_category_show',
        'product-category/create': 'product_category_create',
        'product-category/update': 'product_category_edit',
        'product-category/delete': 'product_category_delete',

        'admin/product/purchase/list': 'purchase_list',
        'admin/reports/purchased-product-report': 'purchased_product_list',
        'admin/product/purchase': 'purchase_create',
        'purchase/update': 'purchase_edit',
        'purchase/delete': 'purchase_delete',

        'admin/role': 'role_list',
        'admin/role/add': 'role_create',
        'role/update': 'role_edit',
        'role/delete': 'role_delete',

        'admin/sell/order': 'sell_list',
        'admin/sell': 'sell_create',
        'sell/update': 'sell_edit',
        'sell/delete': 'sell_delete',

        'admin/settings': 'update_setting',
        'admin/reports/accounting': 'accounting_data',

        'admin/shipping-method': 'shipping_method_list',
        'shipping-method': 'shipping_method_show',
        'shipping-method/create': 'shipping_method_create',
        'shipping-method/update': 'shipping_method_edit',
        'shipping-method/delete': 'shipping_method_delete',

        'admin/supplier': 'supplier_list',
        'admin/supplier/add': 'supplier_create',
        'supplier/update': 'supplier_edit',
        'supplier/delete': 'supplier_delete',

        'admin/unit': 'unit_list',
        // unit: 'unit_show',
        'unit/create': 'unit_create',
        'unit/update': 'unit_edit',
        'unit/delete': 'unit_delete',

        'admin/borrow': 'staff_borrower_list',
        // borrow: 'staff_borrower_show',
        'borrow/create': 'staff_borrower_create',
        'borrow/update': 'staff_borrower_edit',
        'borrow/delete': 'staff_borrower_delete',

        'admin/staff-salary': 'staff_salary_list',
        // salary: 'staff_salary_show',
        'salary/create': 'staff_salary_create',
        'salary/update': 'staff_salary_edit',
        'salary/delete': 'staff_salary_delete',

        'admin/daily-cash': 'daily_cash_list',
        // cash: 'daily_cash_show',
        'cash/create': 'daily_cash_create',
        'cash/update': 'daily_cash_edit',
        'cash/delete': 'daily_cash_delete',
    };
    if (input === null) {
        return list;
    } else {
        return list[input as keyof typeof list] ? list[input as keyof typeof list] : '';
    }
};

export const STATUS_PENDING = 0;
export const STATUS_ACTIVE = 1;
export const PAY_TERM_MONTH = 1;
export const PAY_TERM_DAY = 2;
export const USER_MODULE_SUPERADMIN = 1;
export const USER_MODULE_ADMIN = 2;
export const USER_MODULE_CUSTOMER = 3;

export const FILE_LIST_TYPE_GENERAL = 1;

// discount type
export const DISCOUNT_TYPE_PERCENTAGE = 1;
export const DISCOUNT_TYPE_FIXED = 2;

//
export const SETTING_GROUP_GENERAL = 'general';
export const SETTING_GROUP_MAIL = 'email';
export const SETTING_GROUP_SELL = 'sell';
export const SETTING_GROUP_LANDING = 'landing';
