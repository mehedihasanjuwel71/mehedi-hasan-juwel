import { callApi } from '@/libs/functions';

export const SalaryAddService = async (payload: any) => {
    return await callApi('post', 'salary/create', payload);
};

export const SalaryUpdateService = async (payload: any) => {
    return await callApi('post', 'salary/update', payload);
};

export const SalaryListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    branch_id: any,
    staff_id: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/salary/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&branch_id=${branch_id}&staff_id=${staff_id}&list_size=${list_size}`
    );
};

export const SalaryGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/salary/${uid}`, '', token);
};


export const SalaryDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/salary/delete/${uid}`);
};
