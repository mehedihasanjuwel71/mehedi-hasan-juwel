import { callApi } from '@/libs/functions';

export const ProductCategoryAddService = async (payload: any) => {
    return await callApi('post', 'product-category/create', payload);
};

export const ProductCategoryUpdateService = async (payload: any) => {
    return await callApi('post', 'product-category/update', payload);
};

export const ProductCategoryListService = async (
    per_page: number,
    page: number,
    status: any,
    parent_id: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/product-category/list?per_page=${per_page}&page=${page}&status=${status}&parent_id=${parent_id}&search=${search}&list_size=${list_size}`);
};

export const ProductCategoryGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/product-category/${uid}`, '', token);
};


export const ProductCategoryDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/product-category/delete/${uid}`);
};
