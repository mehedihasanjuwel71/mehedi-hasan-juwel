import { callApi } from '@/libs/functions';

export const PurchaseAddService = async (payload: any) => {
    return await callApi('post', 'purchase/create', payload);
};

export const PurchasePreAddService = async (payload: any) => {
    return await callApi('post', 'purchase/pre-purchase', payload);
};

export const PurchaseUpdateService = async (payload: any) => {
    return await callApi('post', 'purchase/update', payload);
};

export const PurchaseDueAdjustService = async (payload: any) => {
    return await callApi('post', 'purchase/adjust-due', payload);
};

export const UpdateSellPriceService = async (payload: any) => {
    return await callApi('post', 'purchase/sell-price-update', payload);
};

export const PurchaseListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    due_status: any,
    branch_id: any,
    supplier_id: any,
    added_by: any,
    payment_method: any,
    shipping_method: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/purchase/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&due_status=${due_status}&branch_id=${branch_id}&supplier_id=${supplier_id}&added_by=${added_by}&payment_method=${payment_method}&shipping_method=${shipping_method}&list_size=${list_size}`
    );
};

export const PurchaseGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/purchase/${uid}`, '', token);
};

export const PurchasedProductGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/purchase/getpurchased/${uid}`, '', token);
};


export const PurchaseDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/purchase/delete/${uid}`);
};


export const PurchaseListProductService = async (payload: any) => {
    return await callApi('get', `purchase/purchased-product?products_id=${payload}`);
};
