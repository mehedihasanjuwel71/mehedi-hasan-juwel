import { callApi } from '@/libs/functions';

export const AttributeTypeAddService = async (payload: any) => {
    return await callApi('post', 'attribute-type/create', payload);
};

export const AttributeTypeUpdateService = async (payload: any) => {
    return await callApi('post', 'attribute-type/update', payload);
};

export const AttributeTypeListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size:any
) => {
    return await callApi('get', `/attribute-type/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const AttributeTypeGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/attribute-type/${uid}`, '', token);
};

export const AttributeTypeGetDataService = async (
    uid: number,
    token?:any
) => {
    return await callApi('get', `/attribute-type/getdata/${uid}`, '', token);
};


export const AttributeTypeDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/attribute-type/delete/${uid}`);
};
