import { callApi } from '@/libs/functions';

export const FileAddService = async (payload: any) => {
    return await callApi('post', 'file/upload', payload, '',true);
};

export const FileListService = async (per_page: number, page: number, status: any, type: any, search: any, listSize?:any) => {
    return await callApi('get', `/file/list?per_page=${per_page}&page=${page}&status=${status}&type=${type}&search=${search}&list_size=${listSize}`);
};

export const FileGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/file/get/${uid}`, '', token);
};


export const FileDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/file/delete/${uid}`);
};
