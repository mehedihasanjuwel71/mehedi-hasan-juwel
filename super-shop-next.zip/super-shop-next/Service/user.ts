import { callApi } from '@/libs/functions';

export const UserAddService = async (payload: any) => {
    return await callApi('post', 'user/create-user', payload);
};
export const CustomerAddService = async (payload: any) => {
    return await callApi('post', 'user/create-customer', payload);
};

export const UserUpdateService = async (payload: any) => {
    return await callApi('post', 'user/update-user', payload);
};

export const ProfileUpdateService = async (payload: any) => {
    return await callApi('post', 'user/update-profile', payload);
};

export const CustomerUpdateService = async (payload: any) => {
    return await callApi('post', 'user/update-customer', payload);
};

export const UserUpdatePassword = async (payload: any) => {
    return await callApi('post', 'user/update-user-password', payload);
};

export const UpdatePassword = async (payload: any) => {
    return await callApi('post', 'user/update-password', payload);
};

export const UserListService = async (
    per_page: number,
    page: number,
    status: number,
    module: number,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
) => {
    return await callApi(
        'get',
        `/user/list?per_page=${per_page}&page=${page}&status=${status}&module=${module}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&list_size=${list_size}`
    );
};

export const CustomerListService = async (
    per_page: number,
    page: number,
    status: number,
    module: number,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
) => {
    return await callApi(
        'get',
        `/user/customerlist?per_page=${per_page}&page=${page}&status=${status}&module=${module}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&list_size=${list_size}`
    );
};

export const UserGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/user/${uid}`,'',token);
};


export const UserDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/user/delete/${uid}`);
};

export const CustomerDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/user/customerdelete/${uid}`);
};
