import { callApi } from '@/libs/functions';

export const RoleAddService = async (payload: any) => {
    return await callApi('post', 'role/create', payload);
};

export const RoleUpdateService = async (payload: any) => {
    return await callApi('post', 'role/update', payload);
};

export const RoleListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/role/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const PermissionListService = async (
    group: any,
    search: any
) => {
    return await callApi('get', `/role/permissions?&group=${group}&search=${search}`);
};

export const RoleGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/role/${uid}`, '', token);
};


export const RoleDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/role/delete/${uid}`);
};
