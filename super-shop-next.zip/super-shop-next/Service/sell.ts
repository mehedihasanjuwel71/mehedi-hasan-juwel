import { callApi } from '@/libs/functions';

export const SellCreateService = async (payload: any) => {
    return await callApi('post', 'sell/create', payload);
};

export const SellPreCreateService = async (payload: any) => {
    return await callApi('post', 'sell/pre-create', payload);
};

export const SellUpdateService = async (payload: any) => {
    return await callApi('post', 'sell/update', payload);
};

export const SellDueAdjustService = async (payload: any) => {
    return await callApi('post', 'sell/adjust-due', payload);
};

export const SellListService = async (
    per_page: number,
    page: number,
    status: any,
    branch_id: any,
    customer_id: any,
    seller_id: any,
    payment_type: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    dueStatus: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/sell/list?per_page=${per_page}&page=${page}&status=${status}&branch_id=${branch_id}&customer_id=${customer_id}&seller_id=${seller_id}&payment_type=${payment_type}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&due_status=${dueStatus}&list_size=${list_size}`
    );
};

export const PurchasedProductListService = async (
    per_page: number,
    page: number,
    status: any,
    category_id: any,
    brand_id: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
    available_type:any
) => {
    return await callApi(
        'get',
        `/sell/purchased-product?per_page=${per_page}&page=${page}&status=${status}&category_id=${category_id}&brand_id=${brand_id}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&list_size=${list_size}&available_type=${available_type}`
    );
};

export const SellGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/sell/${uid}`, '', token);
};


export const SellDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/sell/delete/${uid}`);
};


// sell return

export const SellReturnCreateService = async (payload: any) => {
    return await callApi('post', 'sell-return/create', payload);
};


export const SellReturnUpdateService = async (payload: any) => {
    return await callApi('post', 'sell-return/update', payload);
};


export const SellReturnListService = async (
    per_page: number,
    page: number,
    status: any,
    sell_id: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/sell-return/list?per_page=${per_page}&page=${page}&status=${status}&sell_id=${sell_id}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&list_size=${list_size}`
    );
};

export const SellReturnGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/sell-return/${uid}`, '', token);
};


export const SellReturnDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/sell-return/delete/${uid}`);
};
