import { callApi } from '@/libs/functions';

export const BorrowAddService = async (payload: any) => {
    return await callApi('post', 'borrow/create', payload);
};

export const BorrowUpdateService = async (payload: any) => {
    return await callApi('post', 'borrow/update', payload);
};

export const BorrowUpdateCashService = async (payload: any) => {
    return await callApi('post', 'borrow/update-cash', payload);
};

export const BorrowListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    borrower: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/borrow/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&borrower=${borrower}&list_size=${list_size}`
    );
};

export const BorrowGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/borrow/${uid}`, '', token);
};


export const BorrowDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/borrow/delete/${uid}`);
};
