import { callApi } from '@/libs/functions';

export const UnitAddService = async (payload: any) => {
    return await callApi('post', 'unit/create', payload);
};

export const UnitUpdateService = async (payload: any) => {
    return await callApi('post', 'unit/update', payload);
};

export const UnitListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/unit/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const UnitGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/unit/${uid}`, '', token);
};


export const UnitDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/unit/delete/${uid}`);
};
