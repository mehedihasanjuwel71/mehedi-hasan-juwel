import { callApi } from '@/libs/functions';

export const BranchAddService = async (payload: any) => {
    return await callApi('post', 'branch/create', payload);
};

export const BranchUpdateService = async (payload: any) => {
    return await callApi('post', 'branch/update', payload);
};

export const BranchListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/branch/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const BranchGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/branch/${uid}`, '', token);
};


export const BranchDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/branch/delete/${uid}`);
};
