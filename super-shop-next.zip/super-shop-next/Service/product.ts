import { callApi } from '@/libs/functions';

export const ProductAddService = async (payload: any) => {
    return await callApi('post', 'product/create', payload);
};

export const ProductUpdateService = async (payload: any) => {
    return await callApi('post', 'product/update', payload);
};

export const ProductListService = async (
    per_page: number,
    page: number,
    status: any,
    category_id: any,
    brand_id: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
) => {
    return await callApi(
        'get',
        `/product/list?per_page=${per_page}&page=${page}&status=${status}&category_id=${category_id}&brand_id=${brand_id}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&list_size=${list_size}`
    );
};

export const ProductGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/product/${uid}`, '', token);
};

export const ProductGetDataService = async (uid: number, token?: any) => {
    return await callApi('get', `/product/getdata/${uid}`, '', token);
};


export const ProductDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/product/delete/${uid}`);
};
