import { callApi } from "@/libs/functions";
import request from "@/libs/request"

export const LoginService = async (payload: any) => {
    return await callApi('post', 'auth/login', payload);
}

export const ForgotPasswordService = async (payload: any) => {
    return await callApi('post', 'auth/forgot-password', payload);
}

export const ResetPasswordService = async (payload: any) => {
    return await callApi('post', 'auth/reset-password', payload);
}

export const RegisterService = async (payload: any) => {
    const { data } = await request.post("register-user", payload);
    return data;
}

export const ParentUser = async () => {
    const { data } = await request.get("parent-user");
    return data;
}

export const Profile = async () => {
    return await request.get("user/profile");
}
