import { callApi } from '@/libs/functions';

export const ExpenseAddService = async (payload: any) => {
    return await callApi('post', 'expense/create', payload);
};

export const ExpenseUpdateService = async (payload: any) => {
    return await callApi('post', 'expense/update', payload);
};

export const ExpenseListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    branch_id: any,
    category_id: any,
    expense_for: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/expense/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&branch_id=${branch_id}&category_id=${category_id}&expense_for=${expense_for}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&list_size=${list_size}`
    );
};

export const ExpenseGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/expense/${uid}`, '', token);
};


export const ExpenseDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/expense/delete/${uid}`);
};
