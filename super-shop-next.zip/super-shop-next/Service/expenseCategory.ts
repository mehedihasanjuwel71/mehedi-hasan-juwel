import { callApi } from '@/libs/functions';

export const ExpenseCategoryAddService = async (payload: any) => {
    return await callApi('post', 'expense-category/create', payload);
};

export const ExpenseCategoryUpdateService = async (payload: any) => {
    return await callApi('post', 'expense-category/update', payload);
};

export const ExpenseCategoryListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/expense-category/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const ExpenseCategoryGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/expense-category/${uid}`, '', token);
};


export const ExpenseCategoryDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/expense-category/delete/${uid}`);
};
