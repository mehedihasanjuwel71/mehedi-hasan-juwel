import { callApi } from '@/libs/functions';

export const BrandAddService = async (payload: any) => {
    return await callApi('post', 'brand/create', payload);
};

export const BrandUpdateService = async (payload: any) => {
    return await callApi('post', 'brand/update', payload);
};

export const BrandListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/brand/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const BrandGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/brand/${uid}`, '', token);
};


export const BrandDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/brand/delete/${uid}`);
};
