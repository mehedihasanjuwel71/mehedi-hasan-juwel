import { callApi } from '@/libs/functions';

export const SupplierAddService = async (payload: any) => {
    return await callApi('post', 'supplier/create', payload);
};

export const SupplierUpdateService = async (payload: any) => {
    return await callApi('post', 'supplier/update', payload);
};

export const SupplierListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
) => {
    return await callApi('get', `/supplier/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const SupplierGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/supplier/${uid}`, '', token);
};


export const SupplierDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/supplier/delete/${uid}`);
};
