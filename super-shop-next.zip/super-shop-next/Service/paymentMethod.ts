import { callApi } from '@/libs/functions';

export const PaymentMethodAddService = async (payload: any) => {
    return await callApi('post', 'payment-method/create', payload);
};

export const PaymentMethodUpdateService = async (payload: any) => {
    return await callApi('post', 'payment-method/update', payload);
};

export const PaymentMethodListService = async (per_page: number, page: number, status: any, search: any, list_size:any) => {
    return await callApi('get', `/payment-method/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const PaymentMethodGetService = async (uid: string, token?: any) => {
    return await callApi('get', `/payment-method/${uid}`, '', token);
};


export const PaymentMethodDeleteService = async (uid: string) => {
    return await callApi('get', `/payment-method/delete/${uid}`);
};
