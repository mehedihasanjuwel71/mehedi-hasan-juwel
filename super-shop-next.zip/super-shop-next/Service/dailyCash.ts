import { callApi } from '@/libs/functions';

export const CashAddService = async (payload: any) => {
    return await callApi('post', 'cash/create', payload);
};

export const CashUpdateService = async (payload: any) => {
    return await callApi('post', 'cash/update', payload);
};

export const CashListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    branch_id: any,
    list_size: any
) => {
    return await callApi(
        'get',
        `/cash/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}&branch_id=${branch_id}&list_size=${list_size}`
    );
};

export const CashGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/cash/${uid}`, '', token);
};


export const CashDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/cash/delete/${uid}`);
};
