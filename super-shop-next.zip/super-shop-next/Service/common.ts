import request from "@/libs/request";

export const CommonSetting = async () => {
    const { data } = await request.get('auth/common-setting');
    return data;
}
