import { callApi } from '@/libs/functions';

export const AttributeAddService = async (payload: any) => {
    return await callApi('post', 'attribute/create', payload);
};

export const AttributeUpdateService = async (payload: any) => {
    return await callApi('post', 'attribute/update', payload);
};

export const AttributeListService = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    type: any,
    list_size: any,
) => {
    return await callApi('get', `/attribute/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&type=${type}&list_size=${list_size}`);
};

export const AttributeGetService = async (
    uid: string,
    token?:any
) => {
    return await callApi('get', `/attribute/${uid}`, '', token);
};


export const AttributeDeleteService = async (
    uid: string,
) => {
    return await callApi('get', `/attribute/delete/${uid}`);
};
