import { callApi } from '@/libs/functions';

export const UpdateAdminSetting = async (payload: any) => {
    return await callApi('post', 'setting/update-general', payload);
};

export const DashboardDataService = async () => {
    return await callApi('get', `/setting/dashboard-data`);
};

export const SettingDataService = async (group:any) => {
    return await callApi('get', `/setting/all?group=${group}`);
};

export const LandingDataService = async (group:any) => {
    return await callApi('get', `/setting/landing-setting`);
};

export const AccountingDataGetService = async (
    fromDate: any,
    toDate: any,
    dateType: any,
) => {
    return await callApi(
        'get',
        `/setting/accounting-data?from_date=${fromDate}&to_date=${toDate}&date_type=${dateType}`
    );
};
