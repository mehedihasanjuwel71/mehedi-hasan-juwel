import { callApi } from '@/libs/functions';

export const ShippingMethodAddService = async (payload: any) => {
    return await callApi('post', 'shipping-method/create', payload);
};

export const ShippingMethodUpdateService = async (payload: any) => {
    return await callApi('post', 'shipping-method/update', payload);
};

export const ShippingMethodListService = async (per_page: number, page: number, status: any, search: any, list_size:any) => {
    return await callApi('get', `/shipping-method/list?per_page=${per_page}&page=${page}&status=${status}&search=${search}&list_size=${list_size}`);
};

export const ShippingMethodGetService = async (uid: string, token?: any) => {
    return await callApi('get', `/shipping-method/${uid}`, '', token);
};


export const ShippingMethodDeleteService = async (uid: string) => {
    return await callApi('get', `/shipping-method/delete/${uid}`);
};
