import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
export default function middleware(req: NextRequest) {
    let verify = req.cookies.get('token');
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL + '/login';
    if (!verify && req.nextUrl.pathname.startsWith('/admin')) {
        return NextResponse.redirect(baseUrl);
    }
}
