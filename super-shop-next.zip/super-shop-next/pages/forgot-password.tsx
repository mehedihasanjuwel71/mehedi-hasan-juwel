import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { IRootState } from '../store';
import { useEffect, useState } from 'react';
import { setPageTitle } from '../store/themeConfigSlice';
import { useRouter } from 'next/router';
import BlankLayout from '@/components/Layouts/BlankLayout';
import { LandingDataAction } from '@/store/actions/settings';
import { ForgotPasswordAction } from '@/store/actions/authentication';

const ForgotPassword = () => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Forgot Password'));
    });
    const router = useRouter();
    const isDark = useSelector((state: IRootState) => state.themeConfig.theme) === 'dark' ? true : false;
    const [data, setData] = useState<any>([]);
    useEffect(() => {
        LandingDataAction(['landing', 'general'], setData);
    }, []);
    const submitForm = (e: any) => {
        e.preventDefault();
        ForgotPasswordAction(credentials, router, dispatch);
    };

    const [credentials, setCredentials] = useState({ email: '' });

    return (
        <div className="grid min-h-screen grid-cols-12 items-center justify-center bg-[url('/assets/images/map.svg')] bg-cover bg-center dark:bg-[url('/assets/images/map-dark.svg')]">
            <div className="col-span-2"></div>
            <div className="col-span-8 ">
                <div className="flex">
                    <div className="hidden min-h-screen w-1/2 flex-col  items-center justify-center  lg:flex">
                        <div className="mx-auto mb-5 w-full">
                            <img src="/assets/images/shop_3.jpg" alt="coming_soon" className="mx-auto object-cover" />
                        </div>
                    </div>
                    <div className="relative flex w-full items-center justify-center lg:w-1/2">
                        <div className="max-w-[480px] p-5 md:p-10">
                            <Link href="/" className="mx-auto mt-10 w-max items-center">
                                <img className="ml-10 w-40" src={data?.logo ? data?.logo : '/assets/images/logo.png'} alt="logo" />
                                <span className="hidden align-middle text-2xl font-semibold transition-all duration-300 ltr:ml-1.5 rtl:mr-1.5 dark:text-white-light md:inline"></span>
                            </Link>
                            <h2 className="mt-5 mb-3 text-center text-3xl font-bold">Forgot Password</h2>
                            <p className="mb-7 text-center">Send mail to reset password</p>
                            <form className="space-y-5" onSubmit={submitForm}>
                                <div>
                                    <label htmlFor="email">Email</label>
                                    <input
                                        id="email"
                                        type="email"
                                        value={credentials.email}
                                        onChange={(e) => {
                                            setCredentials({ ...credentials, email: e.target.value });
                                        }}
                                        className="form-input"
                                        placeholder="Enter Email"
                                    />
                                </div>

                                <button type="submit" className="btn btn-primary w-full">
                                    Send Email
                                </button>
                            </form>

                            <p className="text-center mt-2">
                                Back to Login ?
                                <Link href="/login" className="font-bold text-primary hover:underline ltr:ml-1 rtl:mr-1">
                                    Click Here
                                </Link>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-span-2"></div>
        </div>
    );
};
ForgotPassword.getLayout = (page: any) => {
    return <BlankLayout>{page}</BlankLayout>;
};
export default ForgotPassword;
