import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import Link from 'next/link';
import BlankLayout from '@/components/Layouts/BlankLayout';
import { setPageTitle } from '@/store/themeConfigSlice';
import AnimateHeight from 'react-animate-height';
import { LandingDataAction } from '@/store/actions/settings';

const Home = () => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Home'));
    });
    const [active, setActive] = useState<Number>();
    const togglePara = (value: Number) => {
        setActive((oldValue) => {
            return oldValue === value ? 0 : value;
        });
    };
    const [data,setData] = useState<any>([])
    useEffect(() => {
        LandingDataAction(['landing','general'],setData);
    }, [])
    return (
        <div className="grid min-h-screen grid-cols-12 items-center justify-center bg-gradient-to-t from-[#f1eef2] to-[#f0ecf0]">
            <nav>
                <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 ">
                    <div className="flex h-16 items-center justify-between ">
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <img className="w-22 mt-1 h-16" src={data?.logo ? data?.logo : '/assets/images/logo.png'} alt="Logo" />
                            </div>
                            <div className="hidden md:block">
                                <div className="ml-10 flex items-baseline space-x-4">
                                    <Link href="/login" className="text-black hover:text-gray-300">
                                        Login
                                    </Link>
                                </div>
                            </div>
                        </div>
                        <div className="hidden md:block">
                            <div className="ml-4 flex items-center md:ml-6"></div>
                        </div>
                        <div className="-mr-2 flex md:hidden">
                            {/* Mobile menu button */}
                            <button className="text-gray-300 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800">
                                <span className="sr-only"> menu</span>
                                <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                {/* Mobile menu */}
                <div className="md:hidden" id="mobile-menu">
                    <div className="space-y-1 px-2 pt-2 pb-3 sm:px-3">
                        <Link href="/login" className="text-black hover:text-gray-300">
                            Login
                        </Link>
                    </div>
                </div>
            </nav>
            <div className="col-span-0"></div>
            <div className="col-span-12 ">
                <div className="relative mt-10 bg-[url('/assets/images/shop_1.png')] bg-cover bg-center">
                    <div className="bg-[rgba(255, 255, 255, 0.95)] absolute inset-0 sm:bg-transparent sm:from-white/95 sm:to-white/25" />
                    <div className="relative mx-auto max-w-screen-xl p-6 sm:p-8 lg:p-12 xl:p-32">
                        <div className="max-w-xl bg-white-light bg-opacity-50 p-10 text-center ltr:sm:text-left rtl:sm:text-right ">
                            <h1 className="text-2xl font-extrabold text-black sm:text-4xl md:text-5xl">
                                {data?.landing_title ? data?.landing_title : 'Welcome To Sale Express Enterprise'}
                                <strong className="block font-extrabold text-orange-500">{data?.app_title ? data?.app_title : 'Company Name'}</strong>
                            </h1>
                            <p className="mt-2 max-w-lg text-sm text-black sm:mt-4 sm:text-base md:text-lg lg:text-xl xl:text-2xl">
                                {data?.landing_sub_title ? data?.landing_sub_title : 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model'}
                            </p>
                            <div className="mt-4 flex flex-col gap-2 text-center sm:mt-6 sm:flex-row sm:gap-4 md:mt-8 md:gap-6">
                                <Link
                                    href="/login"
                                    className="block w-full rounded bg-indigo-600 px-6 py-2 text-sm font-medium text-white shadow hover:bg-rose-700 focus:outline-none focus:ring active:bg-rose-500 sm:w-auto sm:px-8 sm:py-3 sm:text-base"
                                >
                                    Get Started
                                </Link>
                                <a
                                    href="#"
                                    className="mt-2 block w-full rounded border border-white px-6 py-2 text-sm font-medium text-white hover:bg-white hover:text-rose-600 focus:outline-none focus:ring active:bg-white active:text-rose-500 sm:mt-0 sm:w-auto sm:px-8 sm:py-3 sm:text-base"
                                >
                                    Learn More
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="pt-1">
                    <section className="bg-transparent text-black">
                        <div className="mx-auto max-w-screen-xl px-4 py-8 sm:py-12 sm:px-6 lg:py-16 lg:px-8">
                            <div className="mx-auto max-w-lg text-center">
                                <h2 className="text-3xl font-bold sm:text-4xl">About {data?.app_title ? data?.app_title : 'Company Name'}</h2>
                                <p className="mt-4 text-black">
                                    {data?.about_company
                                        ? data?.about_company
                                        : "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"}
                                </p>
                            </div>
                            <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-4 lg:grid-cols-4">
                                <a className="block rounded-xl border border-gray-800 p-8 shadow-xl transition hover:border-pink-500/10 hover:shadow-pink-500/10" href="/services/digital-campaigns">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path
                                            opacity="0.5"
                                            d="M7.142 18.9706C5.18539 18.8995 3.99998 18.6568 3.17157 17.8284C2 16.6569 2 14.7712 2 11C2 7.22876 2 5.34315 3.17157 4.17157C4.34315 3 6.22876 3 10 3H14C17.7712 3 19.6569 3 20.8284 4.17157C22 5.34315 22 7.22876 22 11C22 14.7712 22 16.6569 20.8284 17.8284C20.0203 18.6366 18.8723 18.8873 17 18.965"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                            strokeLinecap="round"
                                        />
                                        <path
                                            d="M9.94955 16.0503C10.8806 15.1192 11.3461 14.6537 11.9209 14.6234C11.9735 14.6206 12.0261 14.6206 12.0787 14.6234C12.6535 14.6537 13.119 15.1192 14.0501 16.0503C16.0759 18.0761 17.0888 19.089 16.8053 19.963C16.7809 20.0381 16.7506 20.1112 16.7147 20.1815C16.2973 21 14.8648 21 11.9998 21C9.13482 21 7.70233 21 7.28489 20.1815C7.249 20.1112 7.21873 20.0381 7.19436 19.963C6.91078 19.089 7.92371 18.0761 9.94955 16.0503Z"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                        />
                                    </svg>
                                    <h2 className="mt-4 text-xl font-bold text-black">{data?.landing_feature_title_one ? data?.landing_feature_title_one : 'General'}</h2>
                                </a>
                                <a className="block rounded-xl border border-gray-800 p-8 shadow-xl transition hover:border-pink-500/10 hover:shadow-pink-500/10" href="/services/digital-campaigns">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path
                                            opacity="0.5"
                                            d="M3 10C3 6.22876 3 4.34315 4.17157 3.17157C5.34315 2 7.22876 2 11 2H13C16.7712 2 18.6569 2 19.8284 3.17157C21 4.34315 21 6.22876 21 10V14C21 17.7712 21 19.6569 19.8284 20.8284C18.6569 22 16.7712 22 13 22H11C7.22876 22 5.34315 22 4.17157 20.8284C3 19.6569 3 17.7712 3 14V10Z"
                                            fill="currentColor"
                                        />
                                        <path
                                            fillRule="evenodd"
                                            clipRule="evenodd"
                                            d="M12 5.25C12.4142 5.25 12.75 5.58579 12.75 6V7.25H14C14.4142 7.25 14.75 7.58579 14.75 8C14.75 8.41421 14.4142 8.75 14 8.75L12.75 8.75L12.75 10C12.75 10.4142 12.4142 10.75 12 10.75C11.5858 10.75 11.25 10.4142 11.25 10L11.25 8.75H9.99997C9.58575 8.75 9.24997 8.41421 9.24997 8C9.24997 7.58579 9.58575 7.25 9.99997 7.25H11.25L11.25 6C11.25 5.58579 11.5858 5.25 12 5.25ZM7.25 14C7.25 13.5858 7.58579 13.25 8 13.25H16C16.4142 13.25 16.75 13.5858 16.75 14C16.75 14.4142 16.4142 14.75 16 14.75H8C7.58579 14.75 7.25 14.4142 7.25 14ZM8.25 18C8.25 17.5858 8.58579 17.25 9 17.25H15C15.4142 17.25 15.75 17.5858 15.75 18C15.75 18.4142 15.4142 18.75 15 18.75H9C8.58579 18.75 8.25 18.4142 8.25 18Z"
                                            fill="currentColor"
                                        />
                                    </svg>
                                    <h2 className="mt-4 text-xl font-bold text-black">{data?.landing_feature_title_two ? data?.landing_feature_title_two : 'Free Updates'}</h2>
                                </a>
                                <a className="block rounded-xl border border-gray-800 p-8 shadow-xl transition hover:border-pink-500/10 hover:shadow-pink-500/10" href="/services/digital-campaigns">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path
                                            d="M15.5777 3.38197L17.5777 4.43152C19.7294 5.56066 20.8052 6.12523 21.4026 7.13974C22 8.15425 22 9.41667 22 11.9415V12.0585C22 14.5833 22 15.8458 21.4026 16.8603C20.8052 17.8748 19.7294 18.4393 17.5777 19.5685L15.5777 20.618C13.8221 21.5393 12.9443 22 12 22C11.0557 22 10.1779 21.5393 8.42229 20.618L6.42229 19.5685C4.27063 18.4393 3.19479 17.8748 2.5974 16.8603C2 15.8458 2 14.5833 2 12.0585V11.9415C2 9.41667 2 8.15425 2.5974 7.13974C3.19479 6.12523 4.27063 5.56066 6.42229 4.43152L8.42229 3.38197C10.1779 2.46066 11.0557 2 12 2C12.9443 2 13.8221 2.46066 15.5777 3.38197Z"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                            strokeLinecap="round"
                                        />
                                        <path
                                            opacity="0.5"
                                            d="M21 7.5L17 9.5M12 12L3 7.5M12 12V21.5M12 12C12 12 14.7426 10.6287 16.5 9.75C16.6953 9.65237 17 9.5 17 9.5M17 9.5V13M17 9.5L7.5 4.5"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                            strokeLinecap="round"
                                        />
                                    </svg>
                                    <h2 className="mt-4 text-xl font-bold text-black">{data?.landing_feature_title_three ? data?.landing_feature_title_three : 'Quick Support'}</h2>
                                </a>
                                <a className="block rounded-xl border border-gray-800 p-8 shadow-xl transition hover:border-pink-500/10 hover:shadow-pink-500/10" href="/services/digital-campaigns">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <circle opacity="0.5" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" />
                                        <path d="M12 6V18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                        <path
                                            d="M15 9.5C15 8.11929 13.6569 7 12 7C10.3431 7 9 8.11929 9 9.5C9 10.8807 10.3431 12 12 12C13.6569 12 15 13.1193 15 14.5C15 15.8807 13.6569 17 12 17C10.3431 17 9 15.8807 9 14.5"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                            strokeLinecap="round"
                                        />
                                    </svg>
                                    <h2 className="mt-4 text-xl font-bold text-black">{data?.landing_feature_title_four ? data?.landing_feature_title_four : 'Pricing'}</h2>
                                </a>
                            </div>
                        </div>
                    </section>
                    <section>
                        <div className="mx-auto max-w-screen-2xl px-4 py-16 sm:px-6 lg:px-8">
                            <div className="grid grid-cols-1 lg:h-screen lg:grid-cols-2">
                                <div className="relative z-10 lg:py-16">
                                    <div className="relative h-64 sm:h-80 lg:h-full">
                                        <img alt="shop" src="assets/images/shop.png" className="absolute inset-0 h-full w-full object-cover" />
                                    </div>
                                </div>
                                <div className="relative flex items-center bg-gray-100">
                                    <span className="lg:-start-16 hidden lg:absolute lg:inset-y-0 lg:block lg:w-16 lg:bg-gray-100" />
                                    <div className="p-8 sm:p-16 lg:p-24">
                                        <h2 className="text-2xl font-bold sm:text-3xl">innovative approach to retail has transformed the traditional shopping landscape. .</h2>
                                        <p className="mt-4 text-gray-600">
                                            Say goodbye to long checkout lines! Super Shop's automated checkout system enables customers to make purchases swiftly and conveniently. Self-checkout
                                            kiosks, contactless payment options, and biometric authentication ensure a hassle-free payment process.
                                        </p>
                                        <Link
                                            href="/login"
                                            className="mt-8 inline-block rounded border border-indigo-600 bg-indigo-600 px-12 py-3 text-sm font-medium text-white hover:bg-transparent hover:text-indigo-600 focus:outline-none focus:ring active:text-indigo-500"
                                        >
                                            Get in Touch
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section className="bg-gray-100">
                        <div className="mx-auto max-w-screen-xl px-4 py-16 sm:px-6 lg:px-8">
                            <div className="grid grid-cols-1 gap-x-16 gap-y-8 lg:grid-cols-5">
                                <div className="lg:col-span-2 lg:py-12">
                                    <p className="max-w-xl text-lg">
                                        At the same time, the fact that we are wholly owned and totally independent from manufacturer and other group control gives you confidence that we will only
                                        recommend what is right for you.
                                    </p>
                                    <div className="mt-8">
                                        <a className="text-2xl font-bold text-pink-600">0151 475 4450</a>
                                        <address className="mt-2 not-italic">282 Kevin Brook, Imogeneborough, CA 58517</address>
                                    </div>
                                </div>
                                <div className="rounded-lg bg-white p-8 shadow-lg lg:col-span-3 lg:p-12">
                                    <form className="space-y-4">
                                        <div>
                                            <label className="sr-only" htmlFor="name">
                                                Name
                                            </label>
                                            <input className="w-full rounded-lg border-gray-200 p-3 text-sm" placeholder="Name" type="text" id="name" />
                                        </div>
                                        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                            <div>
                                                <label className="sr-only" htmlFor="email">
                                                    Email
                                                </label>
                                                <input className="w-full rounded-lg border-gray-200 p-3 text-sm" placeholder="Email address" type="email" id="email" />
                                            </div>
                                            <div>
                                                <label className="sr-only" htmlFor="phone">
                                                    Phone
                                                </label>
                                                <input className="w-full rounded-lg border-gray-200 p-3 text-sm" placeholder="Phone Number" type="tel" id="phone" />
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-1 gap-4 text-center sm:grid-cols-3">
                                            <div>
                                                <input className="peer sr-only" id="option1" type="radio" tabIndex={-1} name="option" />
                                                <label
                                                    htmlFor="option1"
                                                    className="block w-full rounded-lg border border-gray-200 p-3 text-gray-600 hover:border-black peer-checked:border-black peer-checked:bg-black peer-checked:text-white"
                                                    tabIndex={0}
                                                >
                                                    <span className="text-sm"> Option 1 </span>
                                                </label>
                                            </div>
                                            <div>
                                                <input className="peer sr-only" id="option2" type="radio" tabIndex={-1} name="option" />
                                                <label
                                                    htmlFor="option2"
                                                    className="block w-full rounded-lg border border-gray-200 p-3 text-gray-600 hover:border-black peer-checked:border-black peer-checked:bg-black peer-checked:text-white"
                                                    tabIndex={0}
                                                >
                                                    <span className="text-sm"> Option 2 </span>
                                                </label>
                                            </div>
                                            <div>
                                                <input className="peer sr-only" id="option3" type="radio" tabIndex={-1} name="option" />
                                                <label
                                                    htmlFor="option3"
                                                    className="block w-full rounded-lg border border-gray-200 p-3 text-gray-600 hover:border-black peer-checked:border-black peer-checked:bg-black peer-checked:text-white"
                                                    tabIndex={0}
                                                >
                                                    <span className="text-sm"> Option 3 </span>
                                                </label>
                                            </div>
                                        </div>
                                        <div>
                                            <label className="sr-only" htmlFor="message">
                                                Message
                                            </label>
                                            <textarea className="w-full rounded-lg border-gray-200 p-3 text-sm" placeholder="Message" rows={8} id="message" defaultValue={''} />
                                        </div>
                                        <div className="mt-4">
                                            <button type="submit" className="inline-block w-full rounded-lg bg-indigo-600 px-5 py-3 font-medium text-white sm:w-auto">
                                                Send Enquiry
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <div className="col-span-0"></div>
        </div>
    );
};
Home.getLayout = (page: any) => {
    return <BlankLayout>{page}</BlankLayout>;
};
export default Home;
