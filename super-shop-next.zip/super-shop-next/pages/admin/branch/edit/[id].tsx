import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { setPageTitle } from '@/store/themeConfigSlice';
import { countryArray, statusArray, payTerm } from '@/libs/functions';
import { BranchUpdateAction, GetBranch } from '@/store/actions/branch';
import { FileGet } from '@/store/actions/fileSystem';
import FileListModal from '@/components/modal/file.modal';

const EditBranch = (): any => {
    const [data, setData] = useState<any>({});

    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Branch Edit'));
    });

    const router = useRouter();
    const { id } = router.query;

    useEffect(() => {
        id && GetBranch(id?.toString(), setLoading, setData);
    }, [id]);
    const [processing, setProcessing] = useState(false);
    const submitForm = (e: any) => {
        setProcessing(true);
        e.preventDefault();
        BranchUpdateAction(credentials, router);
        setProcessing(false)
    };

    const [credentials, setCredentials] = useState({
        uid: id,
        name: '',
        manager_name: '',
        mobile: '',
        phone: '',
        email: '',
        country: '',
        address: '',
        longitude: '',
        latitude: '',
        city: '',
        state: '',
        status: '1',
        image: '',
    });

    useEffect(() => {
        setCredentials({
            ...credentials,
            name: data?.name,
            manager_name: data?.manager_name,
            email: data?.email,
            country: data?.country,
            address: data?.address,
            mobile: data?.mobile,
            phone: data?.phone,
            longitude: data?.longitude,
            latitude: data?.latitude,
            city: data?.city,
            state: data?.state,
            status: data?.status,
            uid: data?.unique_code,
        });
    }, [data]);

    const [loading, setLoading] = useState(false);
    const [imageId, setImageId] = useState<any>('');
    const [imageData, setImageData] = useState<any>('');
    const [modalImage, setModalImage] = useState(false);

    useEffect(() => {
        setCredentials((prevCredentials: any) => ({
            ...prevCredentials,
            image: imageId,
        }));
        imageId && FileGet(imageId?.toString(), setLoading, setImageData);
    }, [imageId]);

    return (
        <div>
            <ul className="mb-4 flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/supplier" className="text-primary hover:underline">
                        {'Branch'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Branch Update'}</span>
                </li>
            </ul>

            <div className="flex flex-col gap-2.5 xl:flex-row">
                {modalImage && <FileListModal modalImage={modalImage} setModalImage={setModalImage} dependency="1" setImageId={setImageId} />}

                <div className="panel flex-1 px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
                    <form className="space-y-5" onSubmit={submitForm}>
                        <div className="mt-8 px-4">
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="text-lg">{'Branch Basic Info'}</div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="name" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Branch Name <span className="text-danger">*</span>
                                        </label>
                                        <input
                                            value={credentials.name}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, name: e.target.value });
                                            }}
                                            id="name"
                                            type="text"
                                            className="form-input flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="nick_name" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Manager Name <span className="text-danger">*</span>
                                        </label>
                                        <input
                                            value={credentials.manager_name}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, manager_name: e.target.value });
                                            }}
                                            id="nick_name"
                                            type="text"
                                            className="form-input flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="mobile" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Mobile No. <span className="text-danger">*</span>
                                        </label>
                                        <input
                                            value={credentials.mobile}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, mobile: e.target.value });
                                            }}
                                            id="mobile"
                                            type="text"
                                            className="form-input flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="phone" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Phone No.
                                        </label>
                                        <input
                                            value={credentials.phone}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, phone: e.target.value });
                                            }}
                                            id="phone"
                                            type="text"
                                            className="form-input flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="address" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Address <span className="text-danger">*</span>
                                        </label>
                                        <input
                                            value={credentials.address}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, address: e.target.value });
                                            }}
                                            id="address"
                                            type="text"
                                            className="form-input flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="status" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Activation Status <span className="text-danger">*</span>
                                        </label>
                                        <select
                                            id="status"
                                            name="status"
                                            className="form-select flex-1"
                                            value={credentials.status}
                                            onChange={(e) => setCredentials({ ...credentials, status: e.target.value })}
                                        >
                                            <option value="">Choose Status</option>
                                            {Object.entries(statusArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                                <div className="w-full lg:w-1/2">
                                    <div className="text-lg">Additional Information:</div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="email" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Email
                                        </label>
                                        <input
                                            value={credentials.email}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, email: e.target.value });
                                            }}
                                            id="email"
                                            type="email"
                                            className="form-input flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="country" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Country
                                        </label>
                                        <select
                                            id="country"
                                            name="country"
                                            className="form-select flex-1"
                                            value={credentials.country}
                                            onChange={(e) => setCredentials({ ...credentials, country: e.target.value })}
                                        >
                                            <option value="">Choose Country</option>
                                            {Object.entries(countryArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="city" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            City
                                        </label>
                                        <input
                                            value={credentials.city}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, city: e.target.value });
                                            }}
                                            id="city"
                                            type="city"
                                            className="form-input w-2/3 flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="state" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            State
                                        </label>
                                        <input
                                            value={credentials.state}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, state: e.target.value });
                                            }}
                                            id="state"
                                            type="state"
                                            className="form-input w-2/3 flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="longitude" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Longitude
                                        </label>
                                        <input
                                            value={credentials.longitude}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, longitude: e.target.value });
                                            }}
                                            id="longitude"
                                            type="longitude"
                                            className="form-input w-2/3 flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="latitude" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Latitude
                                        </label>
                                        <input
                                            value={credentials.latitude}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, latitude: e.target.value });
                                            }}
                                            id="latitude"
                                            type="latitude"
                                            className="form-input w-2/3 flex-1"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-8 px-4">
                            <div className="mt-1">
                                <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                                    <div className="w-full">
                                        <label>Branch Image</label>
                                        <div className="custom-file-container">
                                            <div className="label-container">
                                                <button
                                                    type="button"
                                                    className="custom-file-container__custom-file"
                                                    title="Upload Image"
                                                    onClick={(e) => {
                                                        setModalImage(true);
                                                    }}
                                                >
                                                    {imageData ? 'Change' : 'Upload'}
                                                </button>
                                            </div>
                                            {imageData && (
                                                <div>
                                                    <img className="w-50 h-50" src={imageData?.file_path} alt="Preview" />
                                                </div>
                                            )}
                                            {data && <div>{data?.image && <img className="w-50 h-50" src={data?.image} alt="Preview" />}</div>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="mt-4">
                                <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                                    <div>
                                        <button type="submit" disabled={processing} className="btn btn-success w-full gap-2">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                <path
                                                    d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                    stroke="currentColor"
                                                    strokeWidth="1.5"
                                                />
                                                <path
                                                    d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                    stroke="currentColor"
                                                    strokeWidth="1.5"
                                                />
                                                <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            </svg>
                                            {processing ? 'Processing...' : 'Update'}
                                        </button>
                                    </div>
                                    <div>
                                        <Link href="/admin/branch">
                                            <button type="button" className="btn btn-warning w-full gap-2">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                    <path
                                                        d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                        stroke="currentColor"
                                                        strokeWidth="1.5"
                                                    />
                                                    <path
                                                        d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                        stroke="currentColor"
                                                        strokeWidth="1.5"
                                                    />
                                                    <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                                </svg>
                                                Cancel
                                            </button>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
export default EditBranch;
