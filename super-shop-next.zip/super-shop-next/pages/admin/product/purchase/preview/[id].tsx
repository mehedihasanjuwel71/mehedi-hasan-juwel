import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { setPageTitle } from '@/store/themeConfigSlice';
import { IRootState } from '@/store';
import { formattingDate, STATUS_ACTIVE, discountTypeArray } from '@/libs/functions';
import UpdateSellPriceModal from '@/components/modal/update.sell.price.modal';
import { useRouter } from 'next/router';
import { PurchaseGet } from '@/store/actions/purchase';

const PurchaseDetails = ():any => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Purchase Details'));
    });
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});
    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;
    const [unique_code, setUniqueCode] = useState(null);
    const [dependency, setDependency] = useState(0);
    const [modal1, setModal1] = useState(false);

    const router = useRouter();
    const { id } = router.query;
    useEffect(() => {
        id && PurchaseGet(id?.toString(), setLoading, setData);
    }, [id]);

    return (
        <div>
            <ul className="flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/product/purchase/list" className="text-primary hover:underline">
                        {'Product'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Purchase Details'}</span>
                </li>
            </ul>
            <div className="pt-5">
                <div className="mb-5 grid grid-cols-1 gap-5 lg:grid-cols-3 xl:grid-cols-4">
                    <div className="panel lg:col-span-2 xl:col-span-3">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light">Purchase Information</h5>
                        </div>
                        <div className=" -mx-5 flex flex-wrap">
                            <div className="mb-5 w-full px-5 lg:w-1/3 ">
                                <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                    <table className="whitespace-nowrap">
                                        <tbody className="dark:text-white-dark">
                                            <tr>
                                                <td>Purchase Date :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.purchase_date ? formattingDate(data?.purchase_date) : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Branch :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.branch ? data?.branch.name : 'N/A'}</div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>Supplier Name :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.supplier ? data?.supplier.name : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Purchase Status :</td>
                                                <td>
                                                    <div className="flex w-full ">
                                                        {data?.status == STATUS_ACTIVE ? <span className="text-success"> Received</span> : <span className="text-danger">Pending</span>}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Payment Status :</td>
                                                <td>
                                                    <div className="flex  w-full ">
                                                        {data?.due_status == STATUS_ACTIVE ? <span className="text-danger"> Due</span> : <span className="text-success">Paid</span>}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Purchased By :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.user ? data?.user.username : 'N/A'}</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="mb-5 w-full px-5 lg:w-1/3 ">
                                <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                    <table className="whitespace-nowrap">
                                        <tbody className="dark:text-white-dark">
                                            <tr>
                                                <td>Given Amount :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.given_amount}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Due Amount :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.due_amount}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Payment Method :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.payment ? data?.payment.name : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Shipping Method :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.shipping ? data?.shipping.name : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Shipping Charge :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.shipping_charge}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Reference no :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.reference_no}</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="mb-5 w-full px-5 lg:w-1/3 ">
                                <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                    <table className="whitespace-nowrap">
                                        <tbody className="dark:text-white-dark">
                                            <tr>
                                                <td>Discount Type :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.discount_type ? String(discountTypeArray(data?.discount_type)) : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Tax Type :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.tax_type ? String(discountTypeArray(data?.tax_type)) : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Tax :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.tax}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Discount :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.discount}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Net Total :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.net_total}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Total Quantity :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.total_quantity}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Total Amount :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.total_amount}</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="panel ">
                        <div className="mb-5 flex items-center justify-between">
                            <h5 className="text-lg font-semibold dark:text-white-light">Attachment</h5>
                        </div>
                        <div className="mb-5">
                            <div className="flex flex-col items-center justify-center">
                                <img src={data?.attachment ? data?.attachment : '/assets/images/demo.png'} alt="img" className="h-34 w-34 mb-5 object-cover" />
                                <p className="text-xl font-semibold text-primary"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="pt-5">
                <div className="grid grid-cols-1 ">
                    <div className="panel">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light">Purchased Product List</h5>
                        </div>
                        <div className="space-y-4">
                            {modal1 && <UpdateSellPriceModal modal1={modal1} setModal1={setModal1} uid={unique_code} setDependency={setDependency} />}

                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Sold</th>
                                            <th>Available</th>
                                            <th>Buy Price</th>
                                            <th>Sell Price</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody className="dark:text-white-dark">
                                        {data &&
                                            data?.products &&
                                            data?.products.map((product: any) => (
                                                <tr key={product.id}>
                                                    <td>
                                                        <div className="flex items-center font-semibold">
                                                            <div className="w-max rounded-full bg-white-dark/30 p-0.5 ltr:mr-2 rtl:ml-2">
                                                                <img
                                                                    className="h-8 w-8 rounded-full object-cover"
                                                                    src={product.product.featured_image ? product.product.featured_image : '/assets/images/demo.png'}
                                                                    alt=""
                                                                />
                                                            </div>
                                                            <div>{product.product.name}</div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full items-center">{product.quantity}</div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">{product.sold}</div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">{product.available}</div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">{product.buy_price}</div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">{product.sell_price}</div>
                                                    </td>
                                                    <td>
                                                        <div className="mx-auto flex w-max items-center gap-4">
                                                            <Link title="Preview product" href={`/admin/product/preview/${product.product.unique_code}`} className="flex hover:text-primary">
                                                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        opacity="0.5"
                                                                        d="M3.27489 15.2957C2.42496 14.1915 2 13.6394 2 12C2 10.3606 2.42496 9.80853 3.27489 8.70433C4.97196 6.49956 7.81811 4 12 4C16.1819 4 19.028 6.49956 20.7251 8.70433C21.575 9.80853 22 10.3606 22 12C22 13.6394 21.575 14.1915 20.7251 15.2957C19.028 17.5004 16.1819 20 12 20C7.81811 20 4.97196 17.5004 3.27489 15.2957Z"
                                                                        stroke="currentColor"
                                                                        strokeWidth="1.5"
                                                                    />
                                                                    <path
                                                                        d="M15 12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12C9 10.3431 10.3431 9 12 9C13.6569 9 15 10.3431 15 12Z"
                                                                        stroke="currentColor"
                                                                        strokeWidth="1.5"
                                                                    />
                                                                </svg>
                                                            </Link>
                                                            <button
                                                                title="Update sell price"
                                                                type="button"
                                                                className="flex hover:text-danger"
                                                                onClick={(e) => {
                                                                    setUniqueCode(product.id);
                                                                    setModal1(true);
                                                                }}
                                                            >
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4.5 w-4.5">
                                                                    <path
                                                                        d="M21 12C21 16.714 21 19.0711 19.682 20.5355C18.364 22 16.2426 22 12 22C7.75736 22 5.63604 22 4.31802 20.5355C3 19.0711 3 16.714 3 12C3 7.28595 3 4.92893 4.31802 3.46447C5.63604 2 7.75736 2 12 2C16.2426 2 18.364 2 19.682 3.46447C20.5583 4.43821 20.852 5.80655 20.9504 8"
                                                                        stroke="currentColor"
                                                                        strokeWidth="1.5"
                                                                        strokeLinecap="round"
                                                                    />
                                                                    <path
                                                                        d="M7 8C7 7.53501 7 7.30252 7.05111 7.11177C7.18981 6.59413 7.59413 6.18981 8.11177 6.05111C8.30252 6 8.53501 6 9 6H15C15.465 6 15.6975 6 15.8882 6.05111C16.4059 6.18981 16.8102 6.59413 16.9489 7.11177C17 7.30252 17 7.53501 17 8C17 8.46499 17 8.69748 16.9489 8.88823C16.8102 9.40587 16.4059 9.81019 15.8882 9.94889C15.6975 10 15.465 10 15 10H9C8.53501 10 8.30252 10 8.11177 9.94889C7.59413 9.81019 7.18981 9.40587 7.05111 8.88823C7 8.69748 7 8.46499 7 8Z"
                                                                        stroke="currentColor"
                                                                        strokeWidth="1.5"
                                                                    />
                                                                    <circle cx="8" cy="13" r="1" fill="currentColor" />
                                                                    <circle cx="8" cy="17" r="1" fill="currentColor" />
                                                                    <circle cx="12" cy="13" r="1" fill="currentColor" />
                                                                    <circle cx="12" cy="17" r="1" fill="currentColor" />
                                                                    <circle cx="16" cy="13" r="1" fill="currentColor" />
                                                                    <circle cx="16" cy="17" r="1" fill="currentColor" />
                                                                </svg>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PurchaseDetails;
