import Link from 'next/link';
import React, { useRef } from 'react';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { STATUS_ACTIVE, barcodeTypeArray, discountTypeArray, useGetCurrency } from '@/libs/functions';
import { setPageTitle } from '@/store/themeConfigSlice';
import {  PurchaseListProductAction } from '@/store/actions/purchase';
import Select from 'react-select';
import Barcode from 'react-barcode';


const ProductTag = () => {

    const commonSetting = useSelector((state: any) => state.commonData);
    const currency = useGetCurrency();
    const [data, setData] = useState<any>([]);
    const [pData, setPData] = useState<any>({});
    const [dataOption, setDataOption] = useState<any>([]);
    const [productList, setProductList] = useState<any>([]);
    const [barcodeType, setBarcodeType] = useState<any>('Code128');
    const [numberOfCopy, setNumberOfCopy] = useState<any>(1);
    const [appName, setAppName] = useState<any>(0);
    const [productName, setProductName] = useState<any>(0);
    const [price, setPrice] = useState<any>(0);

    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Product Purchase'));
    });
    const router = useRouter();


    const [loading, setLoading] = useState(false);


    useEffect(() => {
        setLoading(true);
        PurchaseListProductAction('', setPData, setPData);
        setLoading(false);
    }, []);
    useEffect(() => {
        if (pData && pData.length > 0) {
            const options = pData.map((item: any) => ({
                value: item.id,
                label: item.product_name,
                discountedPrice: item.discountedPrice,
                price:item.price,
                barcode:item.barcode
            }));
            setDataOption(options);
        }
    }, [pData]);


    const productHandler = (params: any) => {
        let newArray = [...productList];

        setProductList(params);
    };

    const containerStyle: React.CSSProperties = {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        width: '150px',
        margin: '0 auto',
        background: "white",
        fontFamily: 'sans-serif',
        marginBottom: '20px', // Add margin to create space between barcodes and other content
      };


      const headerStyle: React.CSSProperties = {
        textAlign: 'center',
        marginBottom: '20px', // Add margin to create space between header and barcodes
      };
      const tagStyle: React.CSSProperties  = {
        textAlign: 'center',
      };


      const applyHandler = () => {
        if (productList.length > 0) {
            const newBarcodeData = productList.flatMap((product: any) => {
                // Create an array with the specified number of copies
                const copies = Array.from({ length: numberOfCopy }, (_, index) => (
                    <div key={`${product.value}_${index}`} style={{ marginBottom: '20px' }}>
                        <div style={{ textAlign: 'center' }}>
                            <div style={{ display: "flex", alignItems: "center", flexDirection: "column", justifyContent: "center" }}>
                                <div>{appName === 1 && (commonSetting?.settings?.app_title ? commonSetting?.settings?.app_title : 'Company Name')}</div>
                                <div>{productName === 1 && product.label}</div>
                                {price === 1 && '(' + (currency() + product.discountedPrice) + ')'}
                            </div>
                            <Barcode width={1.8} height={50} value={product.barcode} background="#ffffff"


                            /> {/* Increase width and height */}
                        </div>
                    </div>
                ));

                return copies;
            });

            setData(newBarcodeData);
        }
    };


      const exportTable = () => {
        const printableDiv = document.getElementById('printable-div');
        console.log(printableDiv, "printableDiv");
        if (printableDiv) {
            const printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>Print</title>');

                // Include the Tailwind CSS styles directly
                const tailwindStyles = document.querySelector('style[id="tailwind"]');
                if (tailwindStyles) {
                    printWindow.document.write(tailwindStyles.outerHTML);
                }
                printWindow.document.write('</head><body style="display: flex; justify-content: center; align-items: center; flex-direction: column;">');

                // Apply inline styles to the entire printable content
                const printableContent = printableDiv.innerHTML;
                const styledPrintableContent = `
                    <div style="font-size: 9pt; color: #000; text-align: center; background-color: white; width: 250px;">
                        ${printableContent}
                    </div>
                `;
                printWindow.document.write(styledPrintableContent);

                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.print();

                // Close the print window after printing
                printWindow.addEventListener('afterprint', () => {
                    printWindow.close();
                });
            }
        }
    };



    return (
        <div>
            <ul className="mb-4 flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/product/purchase/list" className="text-primary hover:underline">
                        {'Purchase'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Product Purchase'}</span>
                </li>
            </ul>
            <div className="flex flex-col gap-2.5 xl:flex-row">

                <div className="panel flex-1 px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
                        <div className="mt-8 px-4">
                            <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                <div className="text-lg">{'Other Info'}</div>
                            </div>
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 w-full lg:w-3/12 ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="mt-4 flex items-center">
                                        <div className="w-full">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Barcode Type</label>
                                            <select
                                                className="form-select flex-1"
                                                value={barcodeType}
                                                onChange={(e) => setBarcodeType( e.target.value)}
                                            >
                                                <option value="">Choose Type</option>
                                                {Object.entries(barcodeTypeArray()).map(([key, value]): any => (
                                                    <option key={key} value={key}>
                                                        {value}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>

                                    </div>
                                    <div className="space-y-2 mt-4">
                                    <div>
                                        <label className="inline-flex">
                                            <input type="checkbox" onChange={(e) => setAppName(e.target.checked ? 1 : 0)}
                                                checked={appName === 1}
                                                className="form-checkbox rounded-full" />
                                            <span>Shop Name</span>
                                        </label>
                                    </div>
                                    <div>
                                        <label className="inline-flex">
                                            <input onChange={(e) => setProductName(e.target.checked ? 1 : 0)}
                                                 checked={productName === 1}
                                                type="checkbox" className="form-checkbox rounded-full" />
                                            <span>Product Name</span>
                                        </label>
                                    </div>
                                    <div>
                                        <label className="inline-flex">
                                            <input type="checkbox" onChange={(e) => setPrice(e.target.checked ? 1 : 0)}
                                                checked={price === 1}
                                                className="form-checkbox rounded-full" />
                                            <span>Price</span>
                                        </label>
                                    </div>
                                </div>
                                    <div className="mt-4 flex items-center">
                                        <div className="w-full gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Products</label>
                                            <Select placeholder="Select Product" value={productList}  options={dataOption} isMulti isSearchable={true}
                                                onChange={(params) => productHandler(params)} />
                                        </div>

                                    </div>
                                    <div className="mt-4 flex items-center">

                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Number of Copy</label>
                                            <input
                                                value={numberOfCopy}
                                                onChange={(e) => {
                                                    if(Number(e.target.value) < 0){
                                                        return
                                                    }
                                                    setNumberOfCopy(Number(e.target.value));
                                                }}
                                                type="number"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                    </div>
                                    <div className="mt-8 px-4">
                                        <div className="grid grid-cols-1">
                                            <div>
                                                <button onClick={applyHandler}  className="btn btn-success w-full gap-2">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                        <path
                                                            d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                            stroke="currentColor"
                                                            strokeWidth="1.5"
                                                        />
                                                        <path
                                                            d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                            stroke="currentColor"
                                                            strokeWidth="1.5"
                                                        />
                                                        <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                                    </svg>
                                                    { 'Apply'}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="w-full lg:w-9/12">
                                    {data && data.length > 0 &&
                                    <div className="mb-6 flex flex-wrap items-center justify-center gap-4 lg:justify-end">
                                    <button type="button" className="btn btn-primary gap-2" onClick={() => exportTable()}>
                                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M6 17.9827C4.44655 17.9359 3.51998 17.7626 2.87868 17.1213C2 16.2426 2 14.8284 2 12C2 9.17157 2 7.75736 2.87868 6.87868C3.75736 6 5.17157 6 8 6H16C18.8284 6 20.2426 6 21.1213 6.87868C22 7.75736 22 9.17157 22 12C22 14.8284 22 16.2426 21.1213 17.1213C20.48 17.7626 19.5535 17.9359 18 17.9827"
                                                stroke="currentColor"
                                                strokeWidth="1.5"
                                            />
                                            <path opacity="0.5" d="M9 10H6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            <path d="M19 14L5 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            <path
                                                d="M18 14V16C18 18.8284 18 20.2426 17.1213 21.1213C16.2426 22 14.8284 22 12 22C9.17157 22 7.75736 22 6.87868 21.1213C6 20.2426 6 18.8284 6 16V14"
                                                stroke="currentColor"
                                                strokeWidth="1.5"
                                                strokeLinecap="round"
                                            />
                                            <path
                                                opacity="0.5"
                                                d="M17.9827 6C17.9359 4.44655 17.7626 3.51998 17.1213 2.87868C16.2427 2 14.8284 2 12 2C9.17158 2 7.75737 2 6.87869 2.87868C6.23739 3.51998 6.06414 4.44655 6.01733 6"
                                                stroke="currentColor"
                                                strokeWidth="1.5"
                                            />
                                            <circle opacity="0.5" cx="17" cy="10" r="1" fill="currentColor" />
                                            <path opacity="0.5" d="M15 16.5H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            <path opacity="0.5" d="M13 19H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                        </svg>
                                        Print
                                    </button>

                                </div>
                                }
                                    <div className="mt-4 flex items-center">
                                        <div className="mb-5 w-full px-5 lg:w-1/2 " >
                                            <div id="printable-div"  style={containerStyle}>
                                                {data && data.length > 0 && data}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    );
};

export default ProductTag;
