import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { ProductListShow } from '@/store/actions/product';
import { STATUS_ACTIVE, discountTypeArray, purchaseStatusArray } from '@/libs/functions';
import { setPageTitle } from '@/store/themeConfigSlice';
import ProductForPurchase from '@/components/AdditionalField/product.list.purchase';
import { ShowBranchList } from '@/store/actions/branch';
import { showSupplierList } from '@/store/actions/supplier';
import { ShippingMethodListShow } from '@/store/actions/shippingMethod';
import { PaymentMethodListShow } from '@/store/actions/paymentMethod';
import { PurchaseAddAction } from '@/store/actions/purchase';
import FileListModal from '@/components/modal/file.modal';
import { FileGet } from '@/store/actions/fileSystem';
import { PurchasePreAddService } from '@/Service/purchase';

const ProductPurchase = () => {
    const [branchList, setBranchList] = useState<any>([]);
    const [supplierList, setSupplierList] = useState<any>([]);
    const [paymentMethodList, setPaymentMethodList] = useState<any>([]);
    const [shippingMethodList, setShippingMethodList] = useState<any>([]);
    const [productData, setProductData] = useState<any>([]);
    const [productInfo, setProductInfo] = useState<any>([]);
    const [data, setData] = useState<any>([]);

    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Product Purchase'));
    });
    const router = useRouter();

    const preSubmit = async (e: any|null) => {
        if (productInfo) {
            // Prepare the data
            const products = productInfo.map((product: any) => product.product_id);
            const productQuantity = productInfo.map((product: any) => product.quantity);
            const unitBuyPrice = productInfo.map((product: any) => product.buy_price);
            const unitSellPrice = productInfo.map((product: any) => product.sell_price);

            let newCredentials = {
                ...credentials,
                products: products,
                product_quantity: productQuantity,
                unit_buy_price: unitBuyPrice,
                unit_sell_price: unitSellPrice,
            };
          e &&  e.preventDefault();
            const prePurchase = await PurchasePreAddService(newCredentials);
            if (prePurchase.success) {
                setData(prePurchase.data);
            }
        } else {
        }
    };

    const [processing, setProcessing] = useState(false)
    const submitForm = (e: any) => {
        setProcessing(true)
        if (productInfo) {
            // Prepare the data
            const products = productInfo.map((product: any) => product.product_id);
            const productQuantity = productInfo.map((product: any) => product.quantity);
            const unitBuyPrice = productInfo.map((product: any) => product.buy_price);
            const unitSellPrice = productInfo.map((product: any) => product.sell_price);

            let newCredentials = {
                ...credentials,
                products: products,
                product_quantity: productQuantity,
                unit_buy_price: unitBuyPrice,
                unit_sell_price: unitSellPrice,
            };
            e.preventDefault();
            PurchaseAddAction(newCredentials, router);
        } else {

        }
        setProcessing(false)
    };

    const [credentials, setCredentials] = useState({
        branch_id: '',
        supplier_id: '',
        note: '',
        reference_no: '',
        discount_type: '',
        discount: 0,
        tax_type: '',
        tax: 0,
        given_amount: 0,
        shipping_method: '',
        shipping_charge: 0,
        shipping_note: '',
        payment_note: '',
        payment_method: '',
        status: '1',
        attachment: '',
        purchase_date: '',
        products: [],
        product_quantity: [],
        unit_buy_price: [],
        unit_sell_price: [],
    });

   useEffect(() => {
       preSubmit(null);
   }, [credentials, productInfo]);

    useEffect(() => {
        ShowBranchList(200, 1, STATUS_ACTIVE, '', 'all', setBranchList, setBranchList);
    }, []);

    useEffect(() => {
        if (branchList.length > 0) {
            setCredentials({
                ...credentials,
                branch_id: branchList[0].id,
            });
        }
    }, [branchList]);



    useEffect(() => {
        showSupplierList(200, 1, STATUS_ACTIVE, '', 'all', setSupplierList, setSupplierList);
    }, []);

    useEffect(() => {
        if (supplierList.length > 0) {
            setCredentials({
                ...credentials,
                supplier_id: supplierList[0].id,
            });
        }
    }, [supplierList]);

    useEffect(() => {
        ShippingMethodListShow(20, 1, STATUS_ACTIVE, '', 'all', setShippingMethodList, setShippingMethodList);
    }, []);

    useEffect(() => {
        PaymentMethodListShow(20, 1, STATUS_ACTIVE, '', 'all', setPaymentMethodList, setPaymentMethodList);
    }, []);


    const [searchValue, setSearchValue] = useState('');
    const [selectedProduct, setSelectedProduct] = useState<any>([]);
    const onSearch = (searchTerm: any, itemId: any, index: any) => {
        if (itemId && !selectedProduct.includes(itemId)) {
            setSearchValue(searchTerm);
            setSelectedProduct((prev: any) => [...prev, itemId]);

            setProductInfo((prev: any) => [...prev, { product_id: itemId }]);
        }
    };
    const removeData = (i: number, id: number) => {
        const delVal = [...selectedProduct];
        const product = [...productInfo];
        delVal.splice(i, 1);
        product.splice(i, 1);
        setSelectedProduct(delVal);
        setProductInfo(product);
    };
    useEffect(() => {
        ProductListShow(10, 1, STATUS_ACTIVE, '', '', searchValue,'','','','', setProductData, setProductData);
    }, [searchValue]);

    const [loading, setLoading] = useState(false);
    const [imageId, setImageId] = useState<any>('');
    const [imageData, setImageData] = useState<any>('');
    const [modalImage, setModalImage] = useState(false);

    useEffect(() => {
        setCredentials((prevCredentials: any) => ({
            ...prevCredentials,
            attachment: imageId,
        }));
        imageId && FileGet(imageId?.toString(), setLoading, setImageData);
    }, [imageId]);

    return (
        <div>
            <ul className="mb-4 flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/product/purchase/list" className="text-primary hover:underline">
                        {'Purchase'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Product Purchase'}</span>
                </li>
            </ul>
            <div className="flex flex-col gap-2.5 xl:flex-row">
                {modalImage && <FileListModal modalImage={modalImage} setModalImage={setModalImage} dependency="1" setImageId={setImageId} />}

                <div className="panel flex-1 px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
                    <form className="space-y-5" onSubmit={submitForm}>
                        <div className="mt-8 px-4">
                            <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                <div className="text-lg">{'Purchase Basic Info'}</div>
                            </div>
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Branch <span className='text-danger'>*</span></label>
                                            <select className="form-select flex-1" value={credentials.branch_id} onChange={(e) => setCredentials({ ...credentials, branch_id: e.target.value })}>
                                                <option value="">Choose Branch</option>
                                                {branchList &&
                                                    branchList?.map((item: any) => (
                                                        <option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </option>
                                                    ))}
                                            </select>
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Supplier</label>
                                            <select className="form-select flex-1" value={credentials.supplier_id} onChange={(e) => setCredentials({ ...credentials, supplier_id: e.target.value })}>
                                                <option value="">Choose Supplier <span className='text-danger'>*</span></option>
                                                {supplierList &&
                                                    supplierList?.map((item: any) => (
                                                        <option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </option>
                                                    ))}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div className="w-full lg:w-1/2">
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Reference No. </label>
                                            <input
                                                value={credentials.reference_no}
                                                onChange={(e) => {
                                                    setCredentials({ ...credentials, reference_no: e.target.value });
                                                }}
                                                type="text"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Purchase date <span className='text-danger'>*</span></label>
                                            <input
                                                value={credentials.purchase_date}
                                                onChange={(e) => {
                                                    setCredentials({ ...credentials, purchase_date: e.target.value });
                                                }}
                                                type="date"
                                                name="inv-date"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-4 px-4">
                            <label>Purchase Note (if any)</label>
                            <textarea
                                className="form-textarea min-h-[20px]"
                                placeholder="Note"
                                onChange={(e) => {
                                    setCredentials({ ...credentials, note: e.target.value });
                                }}
                            ></textarea>
                        </div>
                        <hr />
                        <div className="mt-8 px-4">
                            <div className="relative w-full max-w-xl">
                                <input
                                    type="text"
                                    value={searchValue}
                                    onChange={(e) => setSearchValue(e.target.value)}
                                    placeholder="Search Product..."
                                    className="form-input h-11 rounded-full bg-white shadow-[0_0_4px_2px_rgb(31_45_61_/_10%)] placeholder:tracking-wider ltr:pr-11 rtl:pl-11"
                                />
                                <button type="button" className="btn btn-primary absolute inset-y-0 m-auto flex h-9 w-9 items-center justify-center rounded-full p-0 ltr:right-1 rtl:left-1">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="11.5" cy="11.5" r="9.5" stroke="currentColor" strokeWidth="1.5" opacity="0.5"></circle>
                                        <path d="M18.5 18.5L22 22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
                                    </svg>
                                </button>
                            </div>

                            <div className="absolute mt-2 w-full overflow-hidden rounded-md bg-white">
                                {productData &&
                                    productData.length > 0 &&
                                    productData
                                        .filter((item: any) => {
                                            const searchTerm = searchValue.toLowerCase();
                                            const fullName = item.name.toLowerCase();
                                            const slug = item.slug.toLowerCase();
                                            const unique_code = item.unique_code;
                                            const sku = item.sku;
                                            const barcode = item.barcode;

                                            // Check if the searchTerm matches the start of any of the columns
                                            const nameMatch = fullName.includes(searchTerm);
                                            const slugMatch = slug.includes(searchTerm);
                                            const uniqueCodeMatch = unique_code.includes(searchTerm);
                                            const skuMatch = sku.includes(searchTerm);
                                            const barcodeMatch = barcode.includes(searchTerm);

                                            // Return true if any of the columns match the searchTerm
                                            return searchTerm && (nameMatch || slugMatch || uniqueCodeMatch || skuMatch || barcodeMatch);
                                        })
                                        .map((items: any, index: any) => (
                                            <div onClick={() => onSearch(items.name, items.id, index)} key={items?.id} className="cursor-pointer px-3 py-2 hover:bg-slate-100">
                                                <p className="text-sm font-medium text-gray-600">{items?.name}</p>
                                            </div>
                                        ))}
                            </div>
                        </div>
                        <div className="mt-8 px-4">
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 mt-8 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="text-lg">Selected Product: <span className='text-danger'>*</span></div>

                                    {selectedProduct.map((data: any, i: any) => (
                                        <div className="mt-4 flex flex-col justify-between lg:flex-row" key={i}>
                                            <ProductForPurchase uid={data} arrayIndex={i} productInfo={productInfo} setProductInfo={setProductInfo} />
                                            <button onClick={() => removeData(i, data)} type="button" className="btn btn-danger btn-sm ml-1 mt-5 h-9">
                                                x
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <hr />
                        <div className="mt-8 px-4">
                            <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                <div className="text-lg">{'Other Info'}</div>
                            </div>
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Discount Type</label>
                                            <select
                                                className="form-select flex-1"
                                                value={credentials.discount_type}
                                                onChange={(e) => setCredentials({ ...credentials, discount_type: e.target.value })}
                                            >
                                                <option value="">Choose Type</option>
                                                {Object.entries(discountTypeArray()).map(([key, value]): any => (
                                                    <option key={key} value={key}>
                                                        {value}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Discount</label>
                                            <input
                                                value={credentials.discount}
                                                onChange={(e) => {
                                                    if(Number(e.target.value) < 0){
                                                        return
                                                    }
                                                    setCredentials({ ...credentials, discount: Number(e.target.value) });
                                                }}
                                                type="number"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Tax Type</label>
                                            <select className="form-select flex-1" value={credentials.tax_type} onChange={(e) => setCredentials({ ...credentials, tax_type: e.target.value })}>
                                                <option value="">Choose Type</option>
                                                {Object.entries(discountTypeArray()).map(([key, value]): any => (
                                                    <option key={key} value={key}>
                                                        {value}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Tax</label>
                                            <input
                                                value={credentials.tax}
                                                onChange={(e) => {
                                                    if(Number(e.target.value) < 0){
                                                        return
                                                    }
                                                    setCredentials({ ...credentials, tax: Number(e.target.value) });
                                                }}
                                                type="number"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Shipping Method <span className='text-danger'>*</span></label>
                                            <select
                                                className="form-select flex-1"
                                                value={credentials.shipping_method}
                                                onChange={(e) => setCredentials({ ...credentials, shipping_method: e.target.value })}
                                            >
                                                <option value="">Choose method</option>
                                                {shippingMethodList &&
                                                    shippingMethodList?.map((item: any) => (
                                                        <option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </option>
                                                    ))}
                                            </select>
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Shipping Charge <span className='text-danger'>*</span></label>
                                            <input
                                                value={credentials.shipping_charge}
                                                onChange={(e) => {
                                                    if(Number(e.target.value) < 0){
                                                        return
                                                    }
                                                    setCredentials({ ...credentials, shipping_charge: Number(e.target.value) });
                                                }}
                                                type="number"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Payment Method <span className='text-danger'>*</span></label>
                                            <select
                                                className="form-select flex-1"
                                                value={credentials.payment_method}
                                                onChange={(e) => setCredentials({ ...credentials, payment_method: e.target.value })}
                                            >
                                                <option value="">Choose method</option>
                                                {paymentMethodList &&
                                                    paymentMethodList?.map((item: any) => (
                                                        <option key={item.id} value={item.id}>
                                                            {item.name}
                                                        </option>
                                                    ))}
                                            </select>
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Given Amount <span className='text-danger'>*</span></label>
                                            <input
                                                value={credentials.given_amount}
                                                onChange={(e) => {
                                                    if(Number(e.target.value) < 0){
                                                        return
                                                    }
                                                    setCredentials({ ...credentials, given_amount: Number(e.target.value) });
                                                }}
                                                type="number"
                                                className="form-input flex-1"
                                            />
                                        </div>
                                    </div>
                                    <div className="mt-4 items-center">
                                        <label>Shipping Note (if any)</label>
                                        <textarea
                                            className="form-textarea mt-1 min-h-[10px]"
                                            placeholder="Note"
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, shipping_note: e.target.value });
                                            }}
                                        ></textarea>
                                    </div>
                                    <div className="mt-4 items-center">
                                        <label>Payment Note (if any)</label>
                                        <textarea
                                            className="form-textarea mt-1 min-h-[10px]"
                                            placeholder="Note"
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, payment_note: e.target.value });
                                            }}
                                        ></textarea>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Purchase Status</label>
                                            <select className="form-select flex-1" value={credentials.status} onChange={(e) => setCredentials({ ...credentials, status: e.target.value })}>
                                                <option value="">Choose Status <span className='text-danger'>*</span></option>
                                                {Object.entries(purchaseStatusArray()).map(([key, value]): any => (
                                                    <option key={key} value={key}>
                                                        {value}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div className="w-full lg:w-1/2">
                                    <div className="mt-4 flex items-center">
                                        <div className="mb-5 w-full px-5 lg:w-1/3 ">

                                        </div>
                                        <div className="mb-5 w-full px-5 lg:w-1/2 ">
                                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                                <table className="whitespace-nowrap">
                                                    <tbody className="dark:text-white-dark">
                                                        <tr>
                                                            <td>Total Quantity :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.total_quantity}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Net Total :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.net_total}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Total Tax :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.total_tax}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Total Discount :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.total_discount}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Shipping Charge :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.shipping_charge}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Given Amount :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.given_amount}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Total :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.total_amount}</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Due :</td>
                                                            <td>
                                                                <div className="flex h-1.5 w-full ">{data?.due_amount}</div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-4">
                            <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                                <div className="w-full">
                                    <label>Attachment</label>
                                    <div className="custom-file-container">
                                        <div className="label-container">
                                            <button
                                                type="button"
                                                className="custom-file-container__custom-file"
                                                title="Upload Image"
                                                onClick={(e) => {
                                                    setModalImage(true);
                                                }}
                                            >
                                                {imageData ? 'Change' : 'Upload'}
                                            </button>
                                        </div>
                                        {imageData && (
                                            <div>
                                                <img className="w-50 h-50" src={imageData?.file_path} alt="Preview" />
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-8 px-4">
                            <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                                <div>
                                    <button type="submit" disabled={processing} className="btn btn-success w-full gap-2">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                            <path
                                                d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                stroke="currentColor"
                                                strokeWidth="1.5"
                                            />
                                            <path
                                                d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                stroke="currentColor"
                                                strokeWidth="1.5"
                                            />
                                            <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                        </svg>
                                        {processing ? 'Processing...' : 'Purchase'}
                                    </button>
                                </div>
                                <div>
                                    <Link href="/admin/product/purchase">
                                        <button type="button" className="btn btn-warning w-full gap-2">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                <path
                                                    d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                    stroke="currentColor"
                                                    strokeWidth="1.5"
                                                />
                                                <path
                                                    d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                    stroke="currentColor"
                                                    strokeWidth="1.5"
                                                />
                                                <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            </svg>
                                            Cancel
                                        </button>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ProductPurchase;
