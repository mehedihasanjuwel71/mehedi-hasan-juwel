import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { setPageTitle } from '@/store/themeConfigSlice';
import { IRootState } from '@/store';

import { formattingDate, countryArray, STATUS_ACTIVE, productTypeArray, discountTypeArray } from '@/libs/functions';
import { ProductGet } from '@/store/actions/product';
import { useRouter } from 'next/router';


const ProductDetails = ():any => {
    const [loading, setLoading] = useState(false);
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Product Details'));
    });
    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;
    const [data, setData] = useState<any>({});
    const router = useRouter();
    const { id } = router.query;
    useEffect(() => {
        id && ProductGet(id?.toString(), setLoading, setData);
    }, [id]);

    return (
        <div>
            <ul className="flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/product" className="text-primary hover:underline">
                        {'Product'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Product Details'}</span>
                </li>
            </ul>
            <div className="pt-5">
                <div className="mb-5 grid grid-cols-1 gap-5 lg:grid-cols-3 xl:grid-cols-4">
                    <div className="panel">
                        <div className="mb-5 flex items-center justify-between">
                            <h5 className="text-lg font-semibold dark:text-white-light">Featured Image</h5>
                            <Link href={`/admin/product/edit/${id}`} className="btn btn-primary rounded-full p-2 ltr:ml-auto rtl:mr-auto">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5">
                                    <path opacity="0.5" d="M4 22H20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                    <path
                                        d="M14.6296 2.92142L13.8881 3.66293L7.07106 10.4799C6.60933 10.9416 6.37846 11.1725 6.17992 11.4271C5.94571 11.7273 5.74491 12.0522 5.58107 12.396C5.44219 12.6874 5.33894 12.9972 5.13245 13.6167L4.25745 16.2417L4.04356 16.8833C3.94194 17.1882 4.02128 17.5243 4.2485 17.7515C4.47573 17.9787 4.81182 18.0581 5.11667 17.9564L5.75834 17.7426L8.38334 16.8675L8.3834 16.8675C9.00284 16.6611 9.31256 16.5578 9.60398 16.4189C9.94775 16.2551 10.2727 16.0543 10.5729 15.8201C10.8275 15.6215 11.0583 15.3907 11.5201 14.929L11.5201 14.9289L18.3371 8.11195L19.0786 7.37044C20.3071 6.14188 20.3071 4.14999 19.0786 2.92142C17.85 1.69286 15.8581 1.69286 14.6296 2.92142Z"
                                        stroke="currentColor"
                                        strokeWidth="1.5"
                                    />
                                    <path
                                        opacity="0.5"
                                        d="M13.8879 3.66406C13.8879 3.66406 13.9806 5.23976 15.3709 6.63008C16.7613 8.0204 18.337 8.11308 18.337 8.11308M5.75821 17.7437L4.25732 16.2428"
                                        stroke="currentColor"
                                        strokeWidth="1.5"
                                    />
                                </svg>
                            </Link>
                        </div>
                        <div className="mb-5">
                            <div className="flex flex-col items-center justify-center">
                                <img src={data?.featured_image ? data?.featured_image : '/assets/images/demo.png'} alt="img" className="h-34 w-34 mb-5 rounded-full  object-cover" />
                                <p className="text-xl font-semibold text-primary"></p>
                            </div>
                        </div>
                    </div>
                    <div className="panel lg:col-span-2 xl:col-span-3">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light">Basic Information</h5>
                        </div>
                        <div className="mb-5">
                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <tbody className="dark:text-white-dark">
                                        <tr>
                                            <td>Product Name :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.name ? data?.name : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Category :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.category ? data?.category.name : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Brand :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.brand ? data?.brand.name : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Unit :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.unit ? data?.unit.name : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Purchased Status :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">
                                                    {data?.purchase_product && data?.purchase_product.length > 0 ? <span className="text-success"> Purchased</span> : <span className="text-danger">Not Purchased</span>}
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Activation Status :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">
                                                    {data?.status == STATUS_ACTIVE ? <span className="text-success"> Active</span> : <span className="text-danger">Inactive</span>}
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="pt-5">
                <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <div className="panel">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light"></h5>
                        </div>
                        <div className="space-y-4">
                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <tbody className="dark:text-white-dark">
                                        <tr>
                                            <td>SKU :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.sku}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Product Type:</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{String(productTypeArray(data?.product_type))}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Discount Type:</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{String(discountTypeArray(data?.discount_type))}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Discount:</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.discount}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Added By :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.user ? data?.user.username : ''}</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="panel">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light"></h5>
                        </div>
                        <div className="space-y-4">
                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <tbody className="dark:text-white-dark">
                                        {data && data?.attributes && data?.attributes.length > 0 ? (
                                            <tr>
                                                <td>Attributes :</td>
                                                <td>
                                                    {data?.attributes?.map((item: any) => (
                                                        <div key={item.id}>
                                                            <b className="mr-2">{item.attributeType?.name} : </b>
                                                            {item.attribute_mapping && item.attribute_mapping?.map((attr: any) => <span key={attr.id}>|{attr.attribute?.name}|</span>)}
                                                        </div>
                                                    ))}
                                                </td>
                                            </tr>
                                        ) : (
                                            ''
                                        )}
                                        <tr>
                                            <td>Alert Quantity :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.alert_quantity}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Barcode Type:</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.barcode_type}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Barcode:</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.barcode}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Description :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.description}</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDetails;
