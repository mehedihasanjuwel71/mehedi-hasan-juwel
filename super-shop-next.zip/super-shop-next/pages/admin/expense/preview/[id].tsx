import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { setPageTitle } from '@/store/themeConfigSlice';
import { IRootState } from '@/store';
import Dropdown from '@/components/Dropdown';
import { GetServerSideProps } from 'next';
import { parseCookies } from 'nookies';
import { UserGetService } from '@/Service/user';
import { formattingDate, countryArray } from '@/libs/functions';
import { ExpenseGetService } from '@/Service/expense';
import { useRouter } from 'next/router';
import { ExpenseGet } from '@/store/actions/expense';


const ExpenseDetails = ():any => {
    const [loading, setLoading] = useState(false);

    const [data, setData] = useState<any>({});
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Expense Details'));
    });
    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;

    const router = useRouter();
    const { id } = router.query;

    useEffect(() => {
        id && ExpenseGet(id?.toString(), setLoading, setData);
    }, [id]);

    return (
        <div>
            <ul className="flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/expense" className="text-primary hover:underline">
                        {'Expense'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Expense Details'}</span>
                </li>
            </ul>
            <div className="pt-5">
                <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                    <div className="panel">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light"></h5>
                        </div>
                        <div className="space-y-4">
                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <tbody className="dark:text-white-dark">
                                        <tr>
                                            <td>Branch :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.branch ? data?.branch.name : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Category :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.category ? data?.category.name : ''}</div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>Reference No. :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.reference_no ? data?.reference_no : ''}</div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>Cost :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.amount ? data?.amount : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Attachment :</td>
                                            <td>
                                                <div className="flex  w-full ">{data?.attachment ? <img className="w-30 h-30" src={data?.attachment} alt="" /> : ''}</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="panel">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light"></h5>
                        </div>
                        <div className="space-y-4">
                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <tbody className="dark:text-white-dark">
                                        <tr>
                                            <td>Note :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.note ? data?.note : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Expense for :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.expense_for ? data?.expenseFor?.username : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Added By :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.added_by ? data?.user?.username : ''}</div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Date :</td>
                                            <td>
                                                <div className="flex h-1.5 w-full ">{data?.expense_date ? formattingDate(data?.expense_date) : ''}</div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ExpenseDetails;
