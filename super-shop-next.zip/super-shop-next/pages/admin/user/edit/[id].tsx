import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { UserUpdateAction, getUser } from '@/store/actions/user';
import { useRouter } from 'next/router';
import { setPageTitle } from '@/store/themeConfigSlice';
import { FileGet } from '@/store/actions/fileSystem';
import FileListModal from '@/components/modal/file.modal';
import { RoleListAction } from '@/store/actions/role';
import { countryArray, genderArray, statusArray, verifyArray } from '@/libs/functions';

const EditUser = (): any => {
    const [data, setData] = useState<any>({});
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Staff Edit'));
    });

    const router = useRouter();
    const { id } = router.query;

    const [roleList, setRoleList] = useState<any>([]);

    useEffect(() => {
        RoleListAction(100, 1, 1, '','all', setRoleList, setRoleList);
    }, []);

    useEffect(() => {
        id && getUser(id?.toString(), setLoading, setData);
    },[id]);


    const [processing, setProcessing] = useState(false)
    const submitForm = (e: any) => {
        setProcessing(true)
        e.preventDefault();
        UserUpdateAction(credentials, router, dispatch);
        setProcessing(false)
    };

    const [credentials, setCredentials] = useState({
        user_id: id,
        username: '',
        nick_name: '',
        email: '',
        phone: '',
        country: '',
        address: '',
        bio: '',
        birth_date: '',
        gender: '',
        image: '',
        role: '',
        status: '1',
        email_verified: '0',
        phone_verified: '0'
    });

    useEffect(() => {
        if (data) {
            setCredentials({
                ...credentials,
                username: data?.item?.username,
                nick_name: data?.item?.nick_name,
                email: data?.item?.email,
                country: data?.item?.country,
                address: data?.item?.address,
                bio: data?.item?.bio,
                birth_date: data?.item?.birth_date ? data.item.birth_date.substring(0, 10) : '',
                gender: data?.item?.gender,
                phone: data?.item?.phone,
                role: data?.item?.role,
                status: data?.item?.status,
                email_verified: data?.item?.email_verified,
                phone_verified: data?.item?.phone_verified,
                user_id: data?.item?.unique_code,
            });
        }

    }, [data])

    const [loading, setLoading] = useState(false);
    const [imageId, setImageId] = useState<any>('');
    const [imageData, setImageData] = useState<any>('');
    const [modalImage, setModalImage] = useState(false);

    useEffect(() => {
        setCredentials((prevCredentials: any) => ({
            ...prevCredentials,
            image: imageId,
        }));
        imageId && FileGet(imageId?.toString(), setLoading, setImageData);
    }, [imageId]);


    return (
        <div>
            <ul className="mb-4 flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/user" className="text-primary hover:underline">
                        {'Staff'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Staff Update'}</span>
                </li>
            </ul>

            <div className="flex flex-col gap-2.5 xl:flex-row">
                {modalImage && <FileListModal modalImage={modalImage} setModalImage={setModalImage} dependency="1" setImageId={setImageId} />}

                <div className="panel flex-1 px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
                    <form className="space-y-5" onSubmit={submitForm}>
                        <div className="mt-8 px-4">
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="text-lg">{'Update User Basic Info'}</div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="name" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Full Name <span className='text-danger'>*</span>
                                        </label>
                                        <input
                                            value={credentials.username}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, username: e.target.value });
                                            }}
                                            id="name"
                                            type="text"
                                            className="form-input flex-1"
                                            placeholder="Enter Full Name"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="nick_name" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Username <span className='text-danger'>*</span>
                                        </label>
                                        <input
                                            value={credentials.nick_name}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, nick_name: e.target.value });
                                            }}
                                            id="nick_name"
                                            type="text"
                                            className="form-input flex-1"
                                            placeholder="Enter unique username"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="email" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Email <span className='text-danger'>*</span>
                                        </label>
                                        <input
                                            value={credentials.email}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, email: e.target.value });
                                            }}
                                            id="email"
                                            type="email"
                                            className="form-input flex-1"
                                            placeholder="Enter Email"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="email" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Phone
                                        </label>
                                        <input
                                            value={credentials.phone}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, phone: e.target.value });
                                            }}
                                            className="form-input flex-1"
                                            placeholder="Enter Phone"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">Role <span className='text-danger'>*</span></label>
                                        <select className="form-select flex-1" value={credentials.role} onChange={(e) => setCredentials({ ...credentials, role: e.target.value })}>
                                            <option value="">Choose Role </option>
                                            {roleList &&
                                                roleList.map((item: any) => (
                                                    <option key={item.id} value={item.id}>
                                                        {item.name}
                                                    </option>
                                                ))}
                                        </select>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="country" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Country
                                        </label>
                                        <select
                                            id="country"
                                            name="country"
                                            className="form-select flex-1"
                                            value={credentials.country}
                                            onChange={(e) => setCredentials({ ...credentials, country: e.target.value })}
                                        >
                                            <option value="">Choose Country</option>
                                            {Object.entries(countryArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                                <div className="w-full lg:w-1/2">
                                    <div className="text-lg">Update Additional Information:</div>

                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="country" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Gender
                                        </label>
                                        <select
                                            id="country"
                                            name="country"
                                            className="form-select flex-1"
                                            value={credentials.gender}
                                            onChange={(e) => setCredentials({ ...credentials, gender: e.target.value })}
                                        >
                                            <option value="">Choose Gender</option>
                                            {Object.entries(genderArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="birth_date" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Birth date
                                        </label>
                                        <input
                                            value={credentials.birth_date}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, birth_date: e.target.value });
                                            }}
                                            id="birth_date"
                                            type="date"
                                            name="inv-date"
                                            className="form-input w-2/3 flex-1"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="address" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Address
                                        </label>
                                        <input
                                            value={credentials.address}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, address: e.target.value });
                                            }}
                                            id="address"
                                            type="text"
                                            className="form-input flex-1"
                                            placeholder="Enter Address"
                                        />
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Activation Status <span className='text-danger'>*</span>
                                        </label>
                                        <select
                                            name="status"
                                            className="form-select flex-1"
                                            value={credentials.status}
                                            onChange={(e) => setCredentials({ ...credentials, status: e.target.value })}
                                        >
                                            <option value="">Choose Status</option>
                                            {Object.entries(statusArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Email Verification
                                        </label>
                                        <select
                                            name="status"
                                            className="form-select flex-1"
                                            value={credentials.email_verified}
                                            onChange={(e) => setCredentials({ ...credentials, email_verified: e.target.value })}
                                        >
                                            <option value="">Choose Type</option>
                                            {Object.entries(verifyArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <label htmlFor="" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                            Phone Verification
                                        </label>
                                        <select
                                            name="status"
                                            className="form-select flex-1"
                                            value={credentials.phone_verified}
                                            onChange={(e) => setCredentials({ ...credentials, phone_verified: e.target.value })}
                                        >
                                            <option value="">Choose Type</option>
                                            {Object.entries(verifyArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="mt-8 px-4">
                            <label htmlFor="notes">Bio</label>
                            <textarea
                                id="notes"
                                name="notes"
                                className="form-textarea min-h-[30px]"
                                placeholder="About user"
                                value={credentials.bio}
                                onChange={(e) => {
                                    setCredentials({ ...credentials, bio: e.target.value });
                                }}
                            ></textarea>
                            <div className="mt-4">
                                <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                                    <div className="w-full">
                                        <label>Profile Image</label>
                                        <div className="custom-file-container">
                                            <div className="label-container">
                                                <button
                                                    type="button"
                                                    className="custom-file-container__custom-file"
                                                    title="Upload Image"
                                                    onClick={(e) => {
                                                        setModalImage(true);
                                                    }}
                                                >
                                                    {imageData ? 'Change' : 'Upload'}
                                                </button>
                                            </div>
                                            {imageData && (
                                                <div>
                                                    <img className="w-50 h-50" src={imageData?.file_path} alt="Preview" />
                                                </div>
                                            )}
                                            {data && <div>{data?.item?.image && <img className="w-50 h-50" src={data?.item.image} alt="Preview" />}</div>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="mt-4">
                                <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                                    <div>
                                        <button type="submit" disabled={processing} className="btn btn-success w-full gap-2">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                <path
                                                    d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                    stroke="currentColor"
                                                    strokeWidth="1.5"
                                                />
                                                <path
                                                    d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                    stroke="currentColor"
                                                    strokeWidth="1.5"
                                                />
                                                <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            </svg>
                                            {processing ? 'Processing...' : 'Update'}
                                        </button>
                                    </div>
                                    <div>
                                        <Link href="/admin/user">
                                            <button type="button" className="btn btn-warning w-full gap-2">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                    <path
                                                        d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                        stroke="currentColor"
                                                        strokeWidth="1.5"
                                                    />
                                                    <path
                                                        d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                        stroke="currentColor"
                                                        strokeWidth="1.5"
                                                    />
                                                    <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                                </svg>
                                                Cancel
                                            </button>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default EditUser;
