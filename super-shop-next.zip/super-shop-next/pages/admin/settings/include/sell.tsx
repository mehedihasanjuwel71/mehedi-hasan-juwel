import FileListModal from '@/components/modal/file.modal';
import { SETTING_GROUP_GENERAL, SETTING_GROUP_SELL, currencyTextArray, discountTypeArray, enableArray, languageArray } from '@/libs/functions';
import { GetAttributeTypeData } from '@/store/actions/attributeType';
import { FileGet } from '@/store/actions/fileSystem';
import { SettingUpdateAction } from '@/store/actions/settings';
import { UpdatePasswordAction } from '@/store/actions/user';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import Select from 'react-select';

const SellSetting = ({ data }: any) => {
    const [processing, setProcessing] = useState(false);
    const router = useRouter();
    const submitForm = (e: any) => {
        setProcessing(true);
        e.preventDefault();
        SettingUpdateAction(credentials, router);
        setProcessing(false);
    };

    const [credentials, setCredentials] = useState({
        group: SETTING_GROUP_SELL,
        tax_type: '',
        tax: '',
        vat_type: '',
        vat: '',
        enable_product_alert_modal: '',
        product_alert_count: '',
    });

    useEffect(() => {
        setCredentials({
            ...credentials,
            tax_type: data?.tax_type,
            tax: data?.tax,
            vat_type: data?.vat_type,
            vat: data?.vat,
            product_alert_count: data?.vat,
            enable_product_alert_modal: data?.vat,
        });
    }, [data]);

    return (
        <div className="panel  px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
            <form className="space-y-5" onSubmit={submitForm}>
                <div className="mt-8 px-4">
                    <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                        <div className="text-lg">{'Update Sell Settings'} </div>
                        <small>
                            From here you can update your all type of general setting like company name, logo , favicon etc also can change the copyright text From here you can update your all type of
                            general setting like company name, logo , favicon etc also can change the copyright text
                        </small>
                    </div>
                    <div className="">
                        <div className="mb-6 w-full lg:w-full ltr:lg:mr-6 rtl:lg:ml-6">
                            <div className="mt-4 flex items-center">
                                <div className=" w-1/2 gap-2">
                                    <label className="mb-0  ltr:mr-2 rtl:ml-2">Vat Type</label>
                                    <select className="form-select flex-1" value={credentials.vat_type} onChange={(e) => setCredentials({ ...credentials, vat_type: e.target.value })}>
                                        <option>Choose Type</option>
                                        {Object.entries(discountTypeArray()).map(([key, value]) => (
                                            <option key={key} value={key}>
                                                {value}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="ml-2 w-1/2 gap-2">
                                    <label className="mb-0  ltr:mr-2 rtl:ml-2">Vat</label>
                                    <input
                                        value={credentials.vat}
                                        onChange={(e) => {
                                            setCredentials({ ...credentials, vat: e.target.value });
                                        }}
                                        type="text"
                                        className="form-input flex-1"
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="mb-6 w-full lg:w-full ltr:lg:mr-6 rtl:lg:ml-6">
                            <div className="mt-4 flex items-center">
                                <div className="w-1/2 gap-2">
                                    <label className="mb-0  ltr:mr-2 rtl:ml-2">Tax Type</label>
                                    <select className="form-select flex-1" value={credentials.tax_type} onChange={(e) => setCredentials({ ...credentials, tax_type: e.target.value })}>
                                        <option>Choose Type</option>
                                        {Object.entries(discountTypeArray()).map(([key, value]) => (
                                            <option key={key} value={key}>
                                                {value}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="ml-2 w-1/2 gap-2">
                                    <label className="mb-0 ltr:mr-2 rtl:ml-2">Tax</label>
                                    <input
                                        value={credentials.tax}
                                        onChange={(e) => {
                                            setCredentials({ ...credentials, tax: e.target.value });
                                        }}
                                        type="text"
                                        className="form-input flex-1"
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="mb-6 w-full lg:w-full ltr:lg:mr-6 rtl:lg:ml-6">
                            <div className="mt-4 flex items-center">
                                <div className="w-1/2 gap-2">
                                    <label className="mb-0  ltr:mr-2 rtl:ml-2">Alert Modal Enable/Disable</label>
                                    <select
                                        className="form-select flex-1"
                                        value={credentials.enable_product_alert_modal}
                                        onChange={(e) => setCredentials({ ...credentials, enable_product_alert_modal: e.target.value })}
                                    >
                                        <option>Choose Type</option>
                                        {Object.entries(enableArray()).map(([key, value]) => (
                                            <option key={key} value={key}>
                                                {value}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="ml-2 w-1/2 gap-2">
                                    <label className="mb-0 ltr:mr-2 rtl:ml-2">Alert Modal Count</label>
                                    <input
                                        value={credentials.product_alert_count}
                                        onChange={(e) => {
                                            setCredentials({ ...credentials, product_alert_count: e.target.value });
                                        }}
                                        type="text"
                                        className="form-input flex-1"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-8 px-4">
                    <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                        <div>
                            <button type="submit" disabled={processing} className="btn btn-success w-full gap-2">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                    <path
                                        d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                        stroke="currentColor"
                                        strokeWidth="1.5"
                                    />
                                    <path
                                        d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                        stroke="currentColor"
                                        strokeWidth="1.5"
                                    />
                                    <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                </svg>
                                {processing ? 'Processing' : 'Update'}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default SellSetting;
