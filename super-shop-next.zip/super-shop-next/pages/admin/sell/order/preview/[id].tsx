import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { setPageTitle } from '@/store/themeConfigSlice';
import { IRootState } from '@/store';
import { formattingDate, STATUS_ACTIVE, STATUS_PENDING, useGetCurrency } from '@/libs/functions';
import { SellReturnDeleteService } from '@/Service/sell';
import SellRetrnModal from '@/components/modal/sell.return.modal';
import { SellGetAction, SellReturnListAction } from '@/store/actions/sell';
import SellRetrnStatusModal from '@/components/modal/sell.return.status.modal';
import { toast } from 'react-toastify';
import { useRouter } from 'next/router';

const SellOrderDetails = () => {
    const [loading, setLoading] = useState(false);
    const currency = useGetCurrency();
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Sell Details'));
    });
    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;

    const [unique_code, setUniqueCode] = useState(null);
    const [sellId, setSellId] = useState(null);
    const [unique_id, setUniqueId] = useState(null);
    const [dependency, setDependency] = useState(0);
    const [modal1, setModal1] = useState(false);
    const [modal, setModal] = useState(false);

    const [returnProduct,setReturnProduct] = useState<any>([])
    const [record,setRecords] = useState<any>([])
    const [data, setData] = useState<any>({});
    const router = useRouter();
    const { id } = router.query;
    useEffect(() => {
        id && SellGetAction(id?.toString(), setLoading, setData);
    }, [id]);
    useEffect(() => {
        data && setSellId(data.unique_code)
        data && data?.id && SellReturnListAction(10, 1, '', data?.id, '','','','','all', setReturnProduct, setRecords);
    },[data,setDependency]);


    const deleteRow = async (id: any = null) => {
        if (window.confirm('Are you sure want to delete selected row ?')) {
            if (id) {
                const response = await SellReturnDeleteService(id);
                if (response.success) {
                    toast.success(response.message);
                    setRecords(returnProduct.filter((user: any) => user.unique_code !== id));
                    setRecords(returnProduct.filter((user: any) => user.unique_code !== id));
                    setReturnProduct(returnProduct.filter((user: any) => user.unique_code !== id));
                } else {
                    toast.error(response.message);
                }
            } else {
            }
        }
    };

    return (
        <div>
            <ul className="flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/sell" className="text-primary hover:underline">
                        {'Sell'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Order Details'}</span>
                </li>
            </ul>
            <div className="pt-5">
                <div className="mb-5 grid grid-cols-1 gap-5 lg:grid-cols-3 xl:grid-cols-4">
                    <div className="panel lg:col-span-1 xl:col-span-4">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light">Order Information</h5>
                        </div>
                        <div className=" -mx-5 flex flex-wrap">
                            <div className="mb-5 w-full px-5 lg:w-1/3 ">
                                <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                    <table className="whitespace-nowrap">
                                        <tbody className="dark:text-white-dark">
                                            <tr>
                                                <td>Invoice Id :</td>
                                                <td>
                                                    <div className="flex  w-full ">#{data?.order_id}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Order Date :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.createdAt ? formattingDate(data?.createdAt) : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Branch :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.branch ? data?.branch.name : 'N/A'}</div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>Customer:</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.customer ? data?.customer.username : 'Walk In Customer'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Payment Method:</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.payment_method ? data?.payment_method.name : 'N/A'}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Seller :</td>
                                                <td>
                                                    <div className="flex w-full ">{data?.seller ? data?.seller.username : 'N/A'}</div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="mb-5 w-full px-5 lg:w-1/3 ">
                                <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                    <table className="whitespace-nowrap">
                                        <tbody className="dark:text-white-dark">
                                            <tr>
                                                <td>Status :</td>
                                                <td>
                                                    <div className="flex w-full ">
                                                        {data?.status == STATUS_ACTIVE ? <span className="text-success"> Complete</span> : <span className="text-danger">Refunded</span>}
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>Vat :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.calculated_vat}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Tax :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.calculated_tax}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Product Discount :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.total_discount}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Customer Discount :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.customer_discount}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Special Discount :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.admin_discount}
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="mb-5 w-full px-5 lg:w-1/3 ">
                                <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                    <table className="whitespace-nowrap">
                                        <tbody className="dark:text-white-dark">
                                            <tr>
                                                <td>Quantity :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">{data?.total_quantity}</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Total :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.total_price}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Net Total :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.net_total}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Paid :</td>
                                                <td>
                                                    <div className="flex  w-full ">
                                                        {currency()}
                                                        {data?.given_amount}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Due :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.due}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Change :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.return_cash}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Profit :</td>
                                                <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {currency()}
                                                        {data?.profit}
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="pt-5">
                <div className="grid grid-cols-1 ">
                    <div className="panel">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light">Ordered Product</h5>
                        </div>
                        <div className="space-y-4">
                        {modal1 && <SellRetrnModal modal1={modal1} setModal1={setModal1} uid={unique_code} sellId={sellId} setDependency={setDependency} />}

                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Net Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody className="dark:text-white-dark">
                                        {data &&
                                            data?.sell_products &&
                                            data?.sell_products.map((product: any) => (
                                                <tr key={product.id}>
                                                    <td>
                                                        <div className="flex items-center font-semibold">
                                                            <div className="w-max rounded-full bg-white-dark/30 p-0.5 ltr:mr-2 rtl:ml-2">
                                                                <img
                                                                    className="h-8 w-8 rounded-full object-cover"
                                                                    src={product.product?.featured_image ? product.product.featured_image : '/assets/images/demo.png'}
                                                                    alt=""
                                                                />
                                                            </div>
                                                            <div>{product.product.name}</div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full items-center">{product.quantity}</div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">
                                                            {currency()}
                                                            {product.price}
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">
                                                            {currency()}
                                                            {product.cal_discount}
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">
                                                            {currency()}
                                                            {product.sub_total}
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="mx-auto flex w-max items-center gap-4">
                                                        <button
                                                            title="Return this product"
                                                            type="button"
                                                            className="flex hover:text-danger"
                                                            onClick={(e) => {
                                                                setUniqueCode(product.id);
                                                                setModal1(true);
                                                            }}
                                                        >
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4.5 w-4.5">
                                                                <path
                                                                    d="M21 12C21 16.714 21 19.0711 19.682 20.5355C18.364 22 16.2426 22 12 22C7.75736 22 5.63604 22 4.31802 20.5355C3 19.0711 3 16.714 3 12C3 7.28595 3 4.92893 4.31802 3.46447C5.63604 2 7.75736 2 12 2C16.2426 2 18.364 2 19.682 3.46447C20.5583 4.43821 20.852 5.80655 20.9504 8"
                                                                    stroke="currentColor"
                                                                    strokeWidth="1.5"
                                                                    strokeLinecap="round"
                                                                />
                                                                <path
                                                                    d="M7 8C7 7.53501 7 7.30252 7.05111 7.11177C7.18981 6.59413 7.59413 6.18981 8.11177 6.05111C8.30252 6 8.53501 6 9 6H15C15.465 6 15.6975 6 15.8882 6.05111C16.4059 6.18981 16.8102 6.59413 16.9489 7.11177C17 7.30252 17 7.53501 17 8C17 8.46499 17 8.69748 16.9489 8.88823C16.8102 9.40587 16.4059 9.81019 15.8882 9.94889C15.6975 10 15.465 10 15 10H9C8.53501 10 8.30252 10 8.11177 9.94889C7.59413 9.81019 7.18981 9.40587 7.05111 8.88823C7 8.69748 7 8.46499 7 8Z"
                                                                    stroke="currentColor"
                                                                    strokeWidth="1.5"
                                                                />
                                                                <circle cx="8" cy="13" r="1" fill="currentColor" />
                                                                <circle cx="8" cy="17" r="1" fill="currentColor" />
                                                                <circle cx="12" cy="13" r="1" fill="currentColor" />
                                                                <circle cx="12" cy="17" r="1" fill="currentColor" />
                                                                <circle cx="16" cy="13" r="1" fill="currentColor" />
                                                                <circle cx="16" cy="17" r="1" fill="currentColor" />
                                                            </svg>
                                                        </button>
                                                            <Link href={`/admin/product/preview/${product.product.unique_code}`} className=" hover:text-primary">
                                                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        opacity="0.5"
                                                                        d="M3.27489 15.2957C2.42496 14.1915 2 13.6394 2 12C2 10.3606 2.42496 9.80853 3.27489 8.70433C4.97196 6.49956 7.81811 4 12 4C16.1819 4 19.028 6.49956 20.7251 8.70433C21.575 9.80853 22 10.3606 22 12C22 13.6394 21.575 14.1915 20.7251 15.2957C19.028 17.5004 16.1819 20 12 20C7.81811 20 4.97196 17.5004 3.27489 15.2957Z"
                                                                        stroke="currentColor"
                                                                        strokeWidth="1.5"
                                                                    />
                                                                    <path
                                                                        d="M15 12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12C9 10.3431 10.3431 9 12 9C13.6569 9 15 10.3431 15 12Z"
                                                                        stroke="currentColor"
                                                                        strokeWidth="1.5"
                                                                    />
                                                                </svg>
                                                            </Link>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    { returnProduct &&  returnProduct?.length > 0 &&
                    <div className="panel mt-5">
                        <div className="mb-5">
                            <h5 className="text-lg font-semibold dark:text-white-light">Return Product</h5>
                        </div>
                        <div className="space-y-4">
                        {/* {modal && <SellRetrnStatusModal modal1={modal} setModal1={setModal} uid={unique_id} sellId={sellId} setDependency={setDependency} />} */}

                            <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                <table className="whitespace-nowrap">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Return Price</th>
                                            <th>Net Total</th>
                                            <th>Return Status</th>
                                            {/* <th>Action</th> */}
                                        </tr>
                                    </thead>

                                    <tbody className="dark:text-white-dark">
                                        {
                                            returnProduct.map((product: any) => (
                                                <tr key={product.id}>
                                                    <td>
                                                        <div className="flex items-center font-semibold">
                                                            <div className="w-max rounded-full bg-white-dark/30 p-0.5 ltr:mr-2 rtl:ml-2">
                                                                <img
                                                                    className="h-8 w-8 rounded-full object-cover"
                                                                    src={product.product?.featured_image ? product.product?.featured_image : '/assets/images/demo.png'}
                                                                    alt=""
                                                                />
                                                            </div>
                                                            <div>{product.product?.name}</div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full items-center">{product.quantity}</div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">
                                                            {currency()}
                                                            {product.price}
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">
                                                            {currency()}
                                                            {product.return_price}
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div className="flex h-1.5 w-full ">
                                                            {currency()}
                                                            {product.sub_total}
                                                        </div>
                                                    </td>
                                                    <td>
                                                    <div className="flex h-1.5 w-full ">
                                                        {product?.status == STATUS_ACTIVE ? <span className="text-success"> Paid</span> : <span className="text-danger">Due</span>}
                                                    </div>
                                                    </td>
                                                    {/* <td>
                                                        <div className="mx-auto flex w-max items-center gap-4">
                                                        {product?.status == STATUS_PENDING && ( <button
                                                            title="Return this product"
                                                            type="button"
                                                            className="flex hover:text-danger"
                                                            onClick={(e) => {
                                                                setUniqueId(product.unique_code);
                                                                setModal(true);
                                                            }}
                                                        >
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4.5 w-4.5">
                                                                <path
                                                                    d="M21 12C21 16.714 21 19.0711 19.682 20.5355C18.364 22 16.2426 22 12 22C7.75736 22 5.63604 22 4.31802 20.5355C3 19.0711 3 16.714 3 12C3 7.28595 3 4.92893 4.31802 3.46447C5.63604 2 7.75736 2 12 2C16.2426 2 18.364 2 19.682 3.46447C20.5583 4.43821 20.852 5.80655 20.9504 8"
                                                                    stroke="currentColor"
                                                                    strokeWidth="1.5"
                                                                    strokeLinecap="round"
                                                                />
                                                                <path
                                                                    d="M7 8C7 7.53501 7 7.30252 7.05111 7.11177C7.18981 6.59413 7.59413 6.18981 8.11177 6.05111C8.30252 6 8.53501 6 9 6H15C15.465 6 15.6975 6 15.8882 6.05111C16.4059 6.18981 16.8102 6.59413 16.9489 7.11177C17 7.30252 17 7.53501 17 8C17 8.46499 17 8.69748 16.9489 8.88823C16.8102 9.40587 16.4059 9.81019 15.8882 9.94889C15.6975 10 15.465 10 15 10H9C8.53501 10 8.30252 10 8.11177 9.94889C7.59413 9.81019 7.18981 9.40587 7.05111 8.88823C7 8.69748 7 8.46499 7 8Z"
                                                                    stroke="currentColor"
                                                                    strokeWidth="1.5"
                                                                />
                                                                <circle cx="8" cy="13" r="1" fill="currentColor" />
                                                                <circle cx="8" cy="17" r="1" fill="currentColor" />
                                                                <circle cx="12" cy="13" r="1" fill="currentColor" />
                                                                <circle cx="12" cy="17" r="1" fill="currentColor" />
                                                                <circle cx="16" cy="13" r="1" fill="currentColor" />
                                                                <circle cx="16" cy="17" r="1" fill="currentColor" />
                                                            </svg>
                                                        </button> )}
                                                        <button type="button" className="flex hover:text-danger" onClick={(e) => deleteRow(product.unique_code)}>
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5">
                                                                <path d="M20.5001 6H3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
                                                                <path
                                                                    d="M18.8334 8.5L18.3735 15.3991C18.1965 18.054 18.108 19.3815 17.243 20.1907C16.378 21 15.0476 21 12.3868 21H11.6134C8.9526 21 7.6222 21 6.75719 20.1907C5.89218 19.3815 5.80368 18.054 5.62669 15.3991L5.16675 8.5"
                                                                    stroke="currentColor"
                                                                    strokeWidth="1.5"
                                                                    strokeLinecap="round"
                                                                ></path>
                                                                <path opacity="0.5" d="M9.5 11L10 16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
                                                                <path opacity="0.5" d="M14.5 11L14 16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
                                                                <path
                                                                    opacity="0.5"
                                                                    d="M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6"
                                                                    stroke="currentColor"
                                                                    strokeWidth="1.5"
                                                                ></path>
                                                            </svg>
                                                        </button>
                                                        </div>
                                                    </td> */}
                                                </tr>
                                            ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
}
                </div>
            </div>
        </div>
    );
};

export default SellOrderDetails;
