import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useRouter } from 'next/router';
import { STATUS_ACTIVE, USER_MODULE_CUSTOMER, useGetCurrency } from '@/libs/functions';
import { setPageTitle } from '@/store/themeConfigSlice';
import { ShowBranchList } from '@/store/actions/branch';
import { PaymentMethodListShow } from '@/store/actions/paymentMethod';
import ProductForSell from '@/components/AdditionalField/product.list.sell';
import { showUserList } from '@/store/actions/user';
import { PurchasedProductListShow, SellCreateAction, SellGetAction, SellUpdateAction } from '@/store/actions/sell';
import { SellPreCreateService } from '@/Service/sell';

const EditSellOrder = () => {
    const [loading, setLoading] = useState(false);
    const [branchList, setBranchList] = useState<any>([]);
    const [customerList, setCustomerList] = useState<any>([]);
    const [paymentMethodList, setPaymentMethodList] = useState<any>([]);
    const [productData, setProductData] = useState<any>([]);
    const [productInfo, setProductInfo] = useState<any>([]);
    const [sellData, setSellData] = useState<any>([]);
    const [searchValue, setSearchValue] = useState('');
    const [selectedProduct, setSelectedProduct] = useState<any>([]);
    const [data, setData] = useState<any>({});

    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Edit Sell'));
    });
    const router = useRouter();
    const { id } = router.query;
    const currency = useGetCurrency();

    const preSubmit = async (e: any | null) => {
        if (productInfo) {
            // Prepare the data
            const products = productInfo.map((product: any) => product.product_id);
            const productQuantity = productInfo.map((product: any) => product.quantity);

            let newCredentials = {
                ...credentials,
                products: products,
                product_quantity: productQuantity,
            };
            e && e.preventDefault();
            const preSell = await SellPreCreateService(newCredentials);

            if (preSell.success) {
                setSellData(preSell.data);
            }
        } else {
        }
    };

    const [processing, setProcessing] = useState(false);
    const submitForm = (e: any) => {
        setProcessing(true);
        if (productInfo) {
            // Prepare the data
            const products = productInfo.map((product: any) => product.product_id);
            const productQuantity = productInfo.map((product: any) => product.quantity);

            let newCredentials = {
                ...credentials,
                products: products,
                product_quantity: productQuantity,
            };
            e.preventDefault();
            SellUpdateAction(newCredentials, router);
        }
        setProcessing(false);
    };

    useEffect(() => {
        id && SellGetAction(id?.toString(), setLoading, setData);
    }, [id]);

    const [credentials, setCredentials] = useState({
        uid: id,
        branch_id: 0,
        payment_type: 0,
        customer_id: 0,
        given_amount: 0,
        note: '',
        products: [],
        product_quantity: [],
        admin_discount: 0,
        is_confirm: 1,
    });

    useEffect(() => {
        setCredentials({
            ...credentials,
            branch_id: data.branch_id,
            payment_type: data.payment_type,
            customer_id: data.customer_id,
            given_amount: Number(data.given_amount),
            note: data.note,
            admin_discount: Number(data.admin_discount),
            products: [],
            product_quantity: [],
            uid: data.unique_code,
        });
    }, [data]);

    useEffect(() => {
        preSubmit(null);
    }, [credentials, productInfo, selectedProduct]);

    useEffect(() => {
        ShowBranchList(200, 1, STATUS_ACTIVE, '', 'all', setBranchList, setBranchList);
    }, []);

    useEffect(() => {
        showUserList(200, 1, STATUS_ACTIVE, USER_MODULE_CUSTOMER, '', '', '', '', 'all', setCustomerList, setCustomerList);
    }, []);

    useEffect(() => {
        PaymentMethodListShow(20, 1, STATUS_ACTIVE, '', 'all', setPaymentMethodList, setPaymentMethodList);
    }, []);

    useEffect(() => {
        if (branchList.length > 0) {
            setCredentials({
                ...credentials,
                branch_id: branchList[0].id,
            });
        }
    }, [branchList]);

    const onSearch = (searchTerm: any, itemId: any, index: any) => {
        if (!selectedProduct.includes(itemId)) {
            setSearchValue(searchTerm);
            setSelectedProduct((prev: any) => [...prev, itemId]);
            setProductInfo((prev: any) => [...prev, { product_id: itemId }]);
        }
    };
    const removeData = (i: number, id: number) => {
        const delVal = [...selectedProduct];
        delVal.splice(i, 1);
        const newValue = productInfo.filter((item: any) => item.product_id != id);

        setProductInfo(newValue);
        setSelectedProduct(delVal);
    };
    useEffect(() => {
        setLoading(true);
        PurchasedProductListShow(500, 1, STATUS_ACTIVE, '', '', searchValue, '', '', '', 'all', '', setProductData, setProductData);
        setLoading(false);
    }, [searchValue]);

    useEffect(() => {
        if (data && data.sell_products) {
            const productIds = data.sell_products.map((pData: any) => pData.product_purchase_id);
            setSelectedProduct(productIds);
            const productInfoArray = data.sell_products.map((pData: any) => ({
                product_id: pData.product_purchase_id,
                quantity: pData.quantity,
            }));
            setProductInfo(productInfoArray);
        }
    }, [data]);

    return (
        <div>
            <ul className="mb-4 flex space-x-2 rtl:space-x-reverse">
                <li>
                    <Link href="/admin/sell/order/list" className="text-primary hover:underline">
                        {'Sell'}
                    </Link>
                </li>
                <li className="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                    <span>{'Edit Sell'}</span>
                </li>
            </ul>
            <div className="flex flex-col gap-2.5 xl:flex-row">
                <div className="panel flex-1 px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
                    <form className="space-y-5" onSubmit={submitForm}>
                        <div className="mt-8 px-4">
                            <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                <div className="text-lg">{'Sell Basic Info'}</div>
                            </div>
                            <div className="flex flex-col justify-between lg:flex-row">
                                <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                    <div className="mt-4 flex items-center">
                                        <div className="w-1/2 gap-2">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Branch</label>
                                            <select
                                                className="form-select flex-1"
                                                value={credentials.branch_id}
                                                onChange={(e) => setCredentials({ ...credentials, branch_id: parseInt(e.target.value) })}
                                            >
                                                <option value="">Choose Branch</option>
                                                {branchList &&
                                                    branchList?.map((item: any) => (
                                                        <option key={item.id} value={parseInt(item.id)}>
                                                            {item.name}
                                                        </option>
                                                    ))}
                                            </select>
                                        </div>
                                        <div className="ml-2 w-1/2 gap-2">
                                            <label className="mb-0 ltr:mr-2 rtl:ml-2">Customer</label>
                                            <select
                                                className="form-select flex-1"
                                                value={credentials.customer_id}
                                                onChange={(e) => setCredentials({ ...credentials, customer_id: parseInt(e.target.value) })}
                                            >
                                                <option value="0">Walk in customer</option>
                                                {customerList &&
                                                    customerList?.map((item: any) => (
                                                        <option key={item.id} value={parseInt(item.id)}>
                                                            {item.username}
                                                        </option>
                                                    ))}
                                            </select>
                                        </div>
                                    </div>
                                    <div className="mt-4 flex items-center">
                                        <div className="w-full">
                                            <label className="mb-0  ltr:mr-2 rtl:ml-2">Purchase Note (if any)</label>
                                            <textarea
                                                className="form-textarea min-h-[40px] flex-1"
                                                placeholder="Note"
                                                onChange={(e) => {
                                                    setCredentials({ ...credentials, note: e.target.value });
                                                }}
                                            ></textarea>
                                        </div>
                                    </div>

                                    <div className="mt-8 px-4">
                                        <div className="relative w-full max-w-xl">
                                            <input
                                                type="text"
                                                value={searchValue}
                                                onChange={(e) => setSearchValue(e.target.value)}
                                                placeholder="Search Product..."
                                                className="form-input h-11 rounded-full bg-white shadow-[0_0_4px_2px_rgb(31_45_61_/_10%)] placeholder:tracking-wider ltr:pr-11 rtl:pl-11"
                                            />
                                            <button
                                                // onClick={() => onSearch(searchValue)}
                                                type="button"
                                                className="btn btn-primary absolute inset-y-0 m-auto flex h-9 w-9 items-center justify-center rounded-full p-0 ltr:right-1 rtl:left-1"
                                            >
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <circle cx="11.5" cy="11.5" r="9.5" stroke="currentColor" strokeWidth="1.5" opacity="0.5"></circle>
                                                    <path d="M18.5 18.5L22 22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
                                                </svg>
                                            </button>
                                        </div>

                                        <div className="absolute mt-2 w-full overflow-hidden rounded-md bg-white">
                                            {productData &&
                                                productData.length > 0 &&
                                                productData
                                                    .filter((item: any) => {
                                                        const searchTerm = searchValue.toLowerCase();
                                                        const fullName = item.product.name.toLowerCase();
                                                        return searchTerm && fullName.startsWith(searchTerm) && fullName !== searchTerm;
                                                    })
                                                    .map((items: any, index: any) => (
                                                        <div
                                                            onClick={() => items.available > 0 && onSearch(items.product.name, items.id, index)}
                                                            key={items?.id}
                                                            className={`px-3 py-2 hover:bg-slate-100 ${items && items.available <= 0 ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                                                        >
                                                            <p className={`text-sm font-medium dark:text-gray-600 ${items && items.available <= 0 ? 'text-red-500' : ''}`}>
                                                                {items?.product?.name} (
                                                                {items && items.available > 0 ? 'Available ' + items.available + ' ' + items.product.unit.short_name : 'Out of Stock'})
                                                            </p>
                                                        </div>
                                                    ))}
                                        </div>
                                    </div>
                                    <div className="mt-8 px-4">
                                        <div className="flex flex-col justify-between lg:flex-row">
                                            <div className="mb-6 mt-8 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                                <div className="text-lg">Selected Product:</div>

                                                {selectedProduct.map((data: any, i: any) => (
                                                    <div className="mt-4 flex items-center" key={i}>
                                                        <ProductForSell uid={data} arrayIndex={i} productInfo={productInfo} setProductInfo={setProductInfo} />
                                                        <button onClick={() => removeData(i, data)} type="button" className="btn btn-danger ml-1">
                                                            x
                                                        </button>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mt-8 px-4">
                                        <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                            <div className="text-lg">{'Other Info'}</div>
                                        </div>
                                        <div className="flex flex-col justify-between lg:flex-row">
                                            <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                                <div className="mt-4 flex items-center">
                                                    <div className="w-full">
                                                        <label className="mb-0  ltr:mr-2 rtl:ml-2">Payment Method</label>
                                                        <select
                                                            className="form-select flex-1"
                                                            value={credentials.payment_type}
                                                            onChange={(e) => setCredentials({ ...credentials, payment_type: parseInt(e.target.value) })}
                                                        >
                                                            <option value="">Choose method</option>
                                                            {paymentMethodList &&
                                                                paymentMethodList?.map((item: any) => (
                                                                    <option key={item.id} value={item.id}>
                                                                        {item.name}
                                                                    </option>
                                                                ))}
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="mt-4 flex items-center">
                                                    <div className="w-full">
                                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Given Amount</label>
                                                        <input
                                                            value={credentials.given_amount}
                                                            onChange={(e) => {
                                                                setCredentials({ ...credentials, given_amount: Number(e.target.value) });
                                                            }}
                                                            type="number"
                                                            className="form-input flex-1"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="mt-4 flex items-center">
                                                    <div className="w-full">
                                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Admin Discount</label>
                                                        <input
                                                            value={credentials.admin_discount}
                                                            onChange={(e) => {
                                                                setCredentials({ ...credentials, admin_discount: Number(e.target.value) });
                                                            }}
                                                            type="number"
                                                            className="form-input flex-1"
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="w-full lg:w-full">
                                                <div className="mt-4 flex">
                                                    {/* <div className="mb-5 w-full px-5 lg:w-1/3 "></div> */}
                                                    <div className="mb-5 w-full px-5 lg:w-full ">
                                                        <div className="table-responsive font-semibold text-[#515365] dark:text-white-light">
                                                            <table className="whitespace-nowrap">
                                                                <tbody className="dark:text-white-dark">
                                                                    <tr>
                                                                        <td>Total Quantity :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.total_quantity}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Total Price:</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.total_price}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Total Tax :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.total_tax}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Total Vat :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.total_vat}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Product Discount :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.total_discount}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Admin Discount :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.admin_discount}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Customer Discount :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.customer_discount}</div>
                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td>Net Total :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.net_total}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Given Amount :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.given_amount}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Return :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.return_cash}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Due :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.due}</div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Profit :</td>
                                                                        <td>
                                                                            <div className="flex h-1.5 w-full ">{sellData?.profit}</div>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="mt-8 px-4">
                                        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
                                            <div>
                                                <button type="submit" disabled={processing} className="btn btn-success w-full gap-2">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                        <path
                                                            d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                            stroke="currentColor"
                                                            strokeWidth="1.5"
                                                        />
                                                        <path
                                                            d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                            stroke="currentColor"
                                                            strokeWidth="1.5"
                                                        />
                                                        <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                                    </svg>
                                                    {processing ? 'Processing...' : 'Sell'}
                                                </button>
                                            </div>
                                            <div>
                                                <Link href="/admin/sell/order">
                                                    <button type="button" className="btn btn-warning w-full gap-2">
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                                            <path
                                                                d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                                                stroke="currentColor"
                                                                strokeWidth="1.5"
                                                            />
                                                            <path
                                                                d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                                                stroke="currentColor"
                                                                strokeWidth="1.5"
                                                            />
                                                            <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                                        </svg>
                                                        Cancel
                                                    </button>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="w-full lg:w-1/2">
                                    <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                                        <div className="text-lg">{'Purchased Product'}</div>
                                    </div>
                                    {productData.length ? (
                                        <div className="min-h-[400px] sm:min-h-[300px]">
                                            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
                                                {productData.map((product: any, index: any) => {
                                                    return (
                                                        <div
                                                            key={product.id}
                                                            onClick={() => product.available > 0 && onSearch(product.product.name, product.id, index)}
                                                            className={`panel pb-2 dark:shadow-dark ${product.available <= 0 ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                                                        >
                                                            <div className="min-h-[122px]">
                                                                <div className="flex justify-center">
                                                                    <div className="flex-none">
                                                                        <div className="rounded-full bg-gray-300 p-1 dark:bg-gray-700">
                                                                            <img
                                                                                className="h-10 w-10 rounded-full object-cover"
                                                                                alt="img"
                                                                                src={product.product.featured_image ? product.product.featured_image : '/assets/images/demo.png'}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="mt-1 text-center">
                                                                    <h4 className="font-semibold">{product.product.name}</h4>
                                                                    <p className={`mt-1 text-gray-600 dark:text-gray-400 ${product.available <= 0 ? 'text-red-500' : ''}`}>
                                                                        {product.available > 0 ? 'Available ' + product.available + ' ' + product.product.unit.short_name : 'Out of Stock'}
                                                                    </p>
                                                                    <p className="mt-1 text-gray-600 dark:text-gray-400">
                                                                        {currency()}
                                                                        {product.sell_price}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="flex h-full min-h-[40px] items-center justify-center text-lg font-semibold sm:min-h-[10px]">No data available</div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="mt-8 px-4"></div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default EditSellOrder;
