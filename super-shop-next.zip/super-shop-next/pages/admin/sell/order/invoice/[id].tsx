import Link from 'next/link';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { setPageTitle } from '@/store/themeConfigSlice';
import { GetServerSideProps } from 'next';
import { parseCookies } from 'nookies';
import { formattingDate, STATUS_ACTIVE, useGetCurrency } from '@/libs/functions';
import { SellGetService } from '@/Service/sell';
import { useRouter } from 'next/router';
import { SellGetAction } from '@/store/actions/sell';

const OrderInvoice = () => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});
    const commonSetting = useSelector((state: any) => state.commonData);
    const currency = useGetCurrency();
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Order Invoice'));
    });
    const router = useRouter();
    const { id } = router.query;
    const shouldAutoClick = router.query.shouldAutoClick === 'true';

    useEffect(() => {
        id && SellGetAction(id?.toString(), setLoading, setData);
    }, [id]);


    useEffect(() => {
        // Use JavaScript to find the button element by its ID and trigger a click event.
        const printButton = document.getElementById('printButton');

        if (printButton && shouldAutoClick) {
            printButton.click();
          }
    }, [shouldAutoClick]);

    const exportTable = () => {
        const printableDiv = document.getElementById('printable-div');
        if (printableDiv) {
            const printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>Receipt</title>');

                // Include the Tailwind CSS styles directly
                const tailwindStyles = document.querySelector('style[id="tailwind"]');
                if (tailwindStyles) {
                    printWindow.document.write(tailwindStyles.outerHTML);
                }

                printWindow.document.write('</head><body>');

                // Apply inline styles to the entire printable content
                const printableContent = printableDiv.innerHTML;
                const styledPrintableContent = `
                <div style="font-size: 8pt; color: #000; margin: 1cm;">
                    ${printableContent}
                </div>
            `;
                printWindow.document.write(styledPrintableContent);

                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.print();

                // Close the print window after printing
                printWindow.addEventListener('afterprint', () => {
                    printWindow.close();
                });
            }
        }
    };

    const containerStyle: React.CSSProperties = {
        width: '80mm',
        margin: '0 auto',
        fontFamily: 'Arial, sans-serif',
      };

      const headerStyle: React.CSSProperties = {
        textAlign: 'center',
        marginBottom: '2px',
      };

      const dividerStyle: React.CSSProperties = {
        borderTop: '1px dashed #000',
        margin: '2px 0',
      };

      const tableStyle: React.CSSProperties = {
        width: '100%',
        borderCollapse: 'collapse',
      };

      const tableCellStyle: React.CSSProperties = {
        border: 'none',
        padding: '1px',
        fontSize: '11px',
        margin: '0px'
      };

      const customerInfoStyle: React.CSSProperties = {
        marginTop: '2px',
      };

      const marginLeftStyle: React.CSSProperties = {
        marginLeft: '2px',
      };

      const CompanyNameStyle: React.CSSProperties = {
        fontSize: '16px',
        fontWeight:700
      };

      const tableCellStyleReducedSpace: React.CSSProperties = {
        padding: '4px',   // Adjust the padding as needed
        margin: '2px',    // Adjust the margin as needed
        fontSize: '11px', // Adjust the font size as needed
      };

      const logoStyle: React.CSSProperties = {
        display: 'block',
        margin: '0 auto', // Center-align the logo horizontally
        width: '80px', // Adjust the width to fit your logo's dimensions
      };
    return (
        <div>
            <div className="mb-6 flex flex-wrap items-center justify-center gap-4 lg:justify-end">
                <button id="printButton" type="button" className="btn btn-primary gap-2" onClick={() => exportTable()}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M6 17.9827C4.44655 17.9359 3.51998 17.7626 2.87868 17.1213C2 16.2426 2 14.8284 2 12C2 9.17157 2 7.75736 2.87868 6.87868C3.75736 6 5.17157 6 8 6H16C18.8284 6 20.2426 6 21.1213 6.87868C22 7.75736 22 9.17157 22 12C22 14.8284 22 16.2426 21.1213 17.1213C20.48 17.7626 19.5535 17.9359 18 17.9827"
                            stroke="currentColor"
                            strokeWidth="1.5"
                        />
                        <path opacity="0.5" d="M9 10H6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        <path d="M19 14L5 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        <path
                            d="M18 14V16C18 18.8284 18 20.2426 17.1213 21.1213C16.2426 22 14.8284 22 12 22C9.17157 22 7.75736 22 6.87868 21.1213C6 20.2426 6 18.8284 6 16V14"
                            stroke="currentColor"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                        />
                        <path
                            opacity="0.5"
                            d="M17.9827 6C17.9359 4.44655 17.7626 3.51998 17.1213 2.87868C16.2427 2 14.8284 2 12 2C9.17158 2 7.75737 2 6.87869 2.87868C6.23739 3.51998 6.06414 4.44655 6.01733 6"
                            stroke="currentColor"
                            strokeWidth="1.5"
                        />
                        <circle opacity="0.5" cx="17" cy="10" r="1" fill="currentColor" />
                        <path opacity="0.5" d="M15 16.5H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        <path opacity="0.5" d="M13 19H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                    Print
                </button>
            </div>
            <div className="panel">
                <div id="printable-div" style={containerStyle}>
                <div style={headerStyle}>
        {/* <img src={commonSetting?.settings?.logo ? commonSetting?.settings?.logo : '/assets/images/logo.png'} alt="logo" style={logoStyle} /> */}
        <br />
        <span style={CompanyNameStyle}>{commonSetting?.settings?.app_title ? commonSetting?.settings?.app_title : 'Company Name'}</span><br/>
        {commonSetting?.settings?.company_address ? commonSetting?.settings?.company_address : 'Company Address'}<br />
        {commonSetting?.settings?.company_email ? commonSetting?.settings?.company_email : 'company@email.com'} <br/>
        {commonSetting?.settings?.company_phone ? commonSetting?.settings?.company_phone : '0xxxxxxxxxx'}
      </div>
      <div>
      {commonSetting?.settings?.business_hour ? ' Business Hour: '+ commonSetting?.settings?.business_hour : 'Business Hour: 10AM to 8PM'}
      </div>
      <hr style={dividerStyle} />
      <div style={customerInfoStyle}>
      Issue for: {data?.customer ? data?.customer?.username : 'Walk In Customer'}
        <span style={marginLeftStyle}>(
            {data?.customer && (
                <>
                    {/* <p className="">Address : {data.customer.address ? data.customer.address : 'N/A'}</p> */}
                    <span className="">{data?.customer?.phone ? data?.customer?.phone : 'N/A'}</span>
                </>
            )}
        )</span>

      </div>
      <hr style={dividerStyle} />
      <div>
        Date: {data?.createdAt ? formattingDate(data?.createdAt) : 'N/A'}<br />
        Invoice : #{data?.order_id}<br />
        Served by: {data?.seller ? data?.seller.username : 'N/A'}
      </div>
      <hr style={dividerStyle} />
      <table style={tableStyle}>
        <thead>

          <tr>
            <th style={tableCellStyle}>Item</th>
            <th style={tableCellStyle}>Price</th>
            <th style={tableCellStyle}>Total</th>
          </tr>
        </thead>
        <tbody>
        {data?.sell_products &&
            data?.sell_products.map((product: any, index: any) => {
                const serialNumber = index + 1;
                return (
                    <>
                    <tr key={product.id}>
                    <td style={tableCellStyle} colSpan={3}>
                            {product.product.name}
                        </td>
                    </tr>
                    <tr key={product.id}>
                        <td style={tableCellStyle}>
                            {product.product.barcode}
                        </td>
                        <td style={tableCellStyle}>

                                {currency()}
                                {product.price}
                                x {product.quantity}

                        </td>

                        <td style={tableCellStyle}>
                                {currency()}
                                {product.sub_total}
                        </td>
                    </tr>
                    </>

                );
            })}
            <tr>
                <td colSpan={2} style={tableCellStyle}>
                    Sub Total
                </td>
                <td style={tableCellStyle}>
                    {currency()}
                    {data?.total_price}
                </td>
            </tr>
            {data?.calculated_vat && data?.calculated_vat > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Vat Total
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.calculated_vat}
                    </td>
                </tr>
            )}
            {data?.calculated_tax && data?.calculated_tax > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Tax Total
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.calculated_tax}
                    </td>
                </tr>
            )}
            {data?.total_discount && data?.total_discount > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Product Discount
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.total_discount}
                    </td>
                </tr>
            )}
            {data?.customer_discount && data?.customer_discount > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Customer Discount
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.customer_discount}
                    </td>
                </tr>
            )}
            {data?.admin_discount && data?.admin_discount > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Special Discount
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.admin_discount}
                    </td>
                </tr>
            )}

            <tr>
                <td colSpan={2} style={tableCellStyle}>
                    Grand Total
                </td>
                <td style={tableCellStyle}>
                    {currency()}
                    {data?.net_total}
                </td>
            </tr>
            {data?.given_amount && data?.given_amount > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Paid
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.given_amount}
                    </td>
                </tr>
            )}
            {data?.due && data?.due > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Due
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.due}
                    </td>
                </tr>
            )}
            {data?.return_cash && data?.return_cash > 0 && (
                <tr>
                    <td colSpan={2} style={tableCellStyle}>
                        Change
                    </td>
                    <td style={tableCellStyle}>
                        {currency()}
                        {data?.return_cash}
                    </td>
                </tr>
            )}
        </tbody>
      </table>

      <hr style={dividerStyle} />
      <div>
        Payment Mode: {data?.payment_method ? data?.payment_method.name : 'N/A'}<br />
        Payment Status: {data?.status == STATUS_ACTIVE ? <span className="text-success"> Paid</span> : <span className="text-danger">Pending</span>}<br />
      </div>
      <hr style={dividerStyle} />
      <div className="footer">
        Thank you for shopping with us! <br />

      </div>
                </div>
            </div>
        </div>
    );
};

// export const getServerSideProps: GetServerSideProps = async (ctx: any) => {
//     const { id } = ctx.query;
//     const cookies = parseCookies(ctx);
//     let getData: any;
//     getData = await SellGetService(id, cookies.token);
//     return {
//         props: {
//             id: id,
//             data: getData.data ? getData.data : '',
//         },
//     };
// };
export default OrderInvoice;
