import FileListModal from '@/components/modal/file.modal';
import { countryArray, formattingDate, genderArray } from '@/libs/functions';
import { FileGet } from '@/store/actions/fileSystem';
import { ProfileUpdateAction } from '@/store/actions/user';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import Select from 'react-select';

const UserProfileUpdate = ({ data }: any) => {
    const router = useRouter();
    const [processing, setProcessing] = useState(false);
    const submitForm = (e: any) => {
        setProcessing(true);
        e.preventDefault();
        ProfileUpdateAction(credentials, router);
        setProcessing(false)
    };

    const [credentials, setCredentials] = useState({
        username: '',
        nick_name: '',
        email: '',
        phone: '',
        country: '',
        address: '',
        bio: '',
        birth_date: '',
        gender: '',
        image: '',
    });

    useEffect(() => {
        setCredentials({
            ...credentials,
            username: data?.username,
            nick_name: data?.nick_name,
            email: data?.email,
            country: data?.country,
            address: data?.address,
            bio: data?.bio,
            birth_date: data?.birth_date ? data?.birth_date.substring(0, 10) : '',
            gender: data?.gender,
            phone: data?.phone,
        });
    }, [data]);

    const [loading, setLoading] = useState(false);
    const [imageId, setImageId] = useState<any>('');
    const [imageData, setImageData] = useState<any>('');
    const [modalImage, setModalImage] = useState(false);
    useEffect(() => {
        setCredentials((prevCredentials: any) => ({
            ...prevCredentials,
            image: imageId,
        }));
        imageId && FileGet(imageId?.toString(), setLoading, setImageData);
    }, [imageId]);

    return (
        <div className="flex flex-col gap-2.5 xl:flex-row">
            {modalImage && <FileListModal modalImage={modalImage} setModalImage={setModalImage} dependency="1" setImageId={setImageId} />}

            <div className="panel flex-1 px-0 py-6 ltr:xl:mr-6 rtl:xl:ml-6">
                <form className="space-y-5" onSubmit={submitForm}>
                    <div className="mt-8 px-4">
                        <div className="mb-6 w-full  ltr:lg:mr-6 rtl:lg:ml-6">
                            <div className="text-lg">{'Update Profile'}</div>
                        </div>
                        <div className="flex flex-col justify-between lg:flex-row">
                            <div className="mb-6 w-full lg:w-1/2 ltr:lg:mr-6 rtl:lg:ml-6">
                                <div className="mt-4 flex items-center">
                                    <div className="w-1/2 gap-2">
                                        <label className="mb-0  ltr:mr-2 rtl:ml-2">Full Name</label>
                                        <input
                                            value={credentials.username}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, username: e.target.value });
                                            }}
                                            id="name"
                                            type="text"
                                            className="form-input flex-1"
                                            placeholder="Enter Full Name"
                                        />
                                    </div>
                                    <div className="ml-2 w-1/2 gap-2">
                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Username</label>
                                        <input
                                            value={credentials.nick_name}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, nick_name: e.target.value });
                                            }}
                                            id="nick_name"
                                            type="text"
                                            className="form-input flex-1"
                                            placeholder="Enter unique username"
                                        />
                                    </div>
                                </div>
                                <div className="mt-4 flex items-center">
                                    <div className="w-1/2 gap-2">
                                        <label className="mb-0  ltr:mr-2 rtl:ml-2">Country</label>
                                        <select
                                            id="country"
                                            name="country"
                                            className="form-select flex-1"
                                            value={credentials.country}
                                            onChange={(e) => setCredentials({ ...credentials, country: e.target.value })}
                                        >
                                            <option value="">Choose Country</option>
                                            {Object.entries(countryArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="ml-2 w-1/2 gap-2">
                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Gender</label>
                                        <select
                                            id="country"
                                            name="country"
                                            className="form-select flex-1"
                                            value={credentials.gender}
                                            onChange={(e) => setCredentials({ ...credentials, gender: e.target.value })}
                                        >
                                            <option value="">Choose Gender</option>
                                            {Object.entries(genderArray()).map(([key, value]) => (
                                                <option key={key} value={key}>
                                                    {value}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div className="w-full lg:w-1/2">
                                <div className="mt-4 flex items-center">
                                    <div className="w-1/2 gap-2">
                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Email</label>
                                        <input
                                            value={credentials.email}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, email: e.target.value });
                                            }}
                                            id="email"
                                            type="email"
                                            className="form-input flex-1"
                                            placeholder="Enter Email"
                                        />
                                    </div>
                                    <div className="ml-2 w-1/2 gap-2">
                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Phone</label>
                                        <input
                                            value={credentials.phone}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, phone: e.target.value });
                                            }}
                                            className="form-input flex-1"
                                            placeholder="Enter Phone"
                                        />
                                    </div>
                                </div>
                                <div className="mt-4 flex items-center">
                                    <div className="w-1/2 gap-2">
                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Birth Date</label>
                                        <input
                                            value={credentials.birth_date}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, birth_date: e.target.value });
                                            }}
                                            id="birth_date"
                                            type="date"
                                            name="inv-date"
                                            className="form-input w-2/3 flex-1"
                                        />
                                    </div>
                                    <div className="ml-2 w-1/2 gap-2">
                                        <label className="mb-0 ltr:mr-2 rtl:ml-2">Address</label>
                                        <input
                                            value={credentials.address}
                                            onChange={(e) => {
                                                setCredentials({ ...credentials, address: e.target.value });
                                            }}
                                            id="address"
                                            type="text"
                                            className="form-input flex-1"
                                            placeholder="Enter Address"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="mt-4 px-4">
                        <label>About Me</label>
                        <textarea
                            id="notes"
                            name="notes"
                            className="form-textarea min-h-[30px]"
                            placeholder="About user"
                            value={credentials.bio}
                            onChange={(e) => {
                                setCredentials({ ...credentials, bio: e.target.value });
                            }}
                        ></textarea>
                    </div>

                    <div className="mt-4">
                        <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                            <div className="w-full">
                                <label>Profile Image</label>
                                <div className="custom-file-container">
                                    <div className="label-container">
                                        <button
                                            type="button"
                                            className="custom-file-container__custom-file"
                                            title="Upload Image"
                                            onClick={(e) => {
                                                setModalImage(true);
                                            }}
                                        >
                                            {imageData ? 'Change' : 'Upload'}
                                        </button>
                                    </div>
                                    {imageData && (
                                        <div>
                                            <img className="w-50 h-50" src={imageData?.file_path} alt="Preview" />
                                        </div>
                                    )}
                                    {data && <div>{data?.image && <img className="w-50 h-50" src={data?.image} alt="Preview" />}</div>}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="mt-8 px-4">
                        <div className="grid grid-cols-6 gap-4 sm:grid-cols-6">
                            <div>
                                <button type="submit" disabled={processing} className="btn btn-success w-full gap-2">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ltr:mr-2 rtl:ml-2">
                                        <path
                                            d="M3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 11.6585 22 11.4878 21.9848 11.3142C21.9142 10.5049 21.586 9.71257 21.0637 9.09034C20.9516 8.95687 20.828 8.83317 20.5806 8.58578L15.4142 3.41944C15.1668 3.17206 15.0431 3.04835 14.9097 2.93631C14.2874 2.414 13.4951 2.08581 12.6858 2.01515C12.5122 2 12.3415 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355Z"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                        />
                                        <path
                                            d="M17 22V21C17 19.1144 17 18.1716 16.4142 17.5858C15.8284 17 14.8856 17 13 17H11C9.11438 17 8.17157 17 7.58579 17.5858C7 18.1716 7 19.1144 7 21V22"
                                            stroke="currentColor"
                                            strokeWidth="1.5"
                                        />
                                        <path opacity="0.5" d="M7 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                    </svg>
                                    {processing ? 'Processing...' : 'Update'}
                                </button>
                            </div>
                            <div></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default UserProfileUpdate;
