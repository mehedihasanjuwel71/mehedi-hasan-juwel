import { ProductGetById } from '@/store/actions/product';
import { useState, useEffect } from 'react';

const ProductForPurchase = ({ uid, arrayIndex, productInfo, setProductInfo }: any) => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});


    useEffect(() => {
        uid && ProductGetById(uid, setLoading, setData, setData, setData);
    }, [uid]);

    return (
        <>
            <div className="w-1/4 gap-2">
                <label className="mb-0  bg-center ltr:mr-2 rtl:ml-2">
                    <b>{data ? data.name : ''} : </b>
                </label>
            </div>
            <div className="ml-2 w-1/2 gap-2">
                <label className="mb-0 ltr:mr-2 rtl:ml-2">Purchase Quantity</label>
                <input
                    className="form-input flex-1"
                    type="number"
                    value={productInfo[arrayIndex]?.quantity}
                    onChange={(e) => {
                        setProductInfo((prev: any) => {
                            const updatedInfo = [...prev];
                            updatedInfo[arrayIndex] = {
                                ...updatedInfo[arrayIndex],
                                quantity: e.target.value,
                            };
                            return updatedInfo;
                        });
                    }}
                />
            </div>
            <div className=" ml-2 w-1/2 gap-2">
                <label className="mb-0 ltr:mr-2 rtl:ml-2">Buy Price</label>
                <input
                    className="form-input flex-1"
                    type="number"
                    value={productInfo[arrayIndex]?.buy_price}
                    onChange={(e) => {
                        setProductInfo((prev: any) => {
                            const updatedInfo = [...prev];
                            updatedInfo[arrayIndex] = {
                                ...updatedInfo[arrayIndex],
                                buy_price: e.target.value,
                            };
                            return updatedInfo;
                        });
                    }}
                />
            </div>
            <div className="ml-2 w-1/2 gap-2">
                <label className="mb-0 ltr:mr-2 rtl:ml-2">Sell Price</label>
                <input
                    className="form-input flex-1"
                    type="number"
                    value={productInfo[arrayIndex]?.sell_price}
                    onChange={(e) => {
                        setProductInfo((prev: any) => {
                            const updatedInfo = [...prev];
                            updatedInfo[arrayIndex] = {
                                ...updatedInfo[arrayIndex],
                                sell_price: e.target.value,
                            };
                            return updatedInfo;
                        });
                    }}
                />
            </div>
        </>
    );
};

export default ProductForPurchase;
