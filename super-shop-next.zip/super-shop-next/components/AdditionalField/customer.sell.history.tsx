import { formattingDate } from '@/libs/functions';
import { IRootState } from '@/store';
import { SellListShow } from '@/store/actions/sell';
import { sortBy } from 'lodash';
import { DataTable, DataTableSortStatus } from 'mantine-datatable';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Select from 'react-select';

const CustomerSellHistory = ({ uid }: any) => {
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [totalPage, setTotalPage] = useState(0);
    const PAGE_SIZES = [10, 20, 30, 50, 100];
    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [items, setItems] = useState<any>([]);
    const [initialRecords, setInitialRecords] = useState(sortBy(items, 'id'));
    const [records, setRecords] = useState([]);

    const isDark = useSelector((state: IRootState) => state.themeConfig.theme) === 'dark' ? true : false;

    const [search, setSearch] = useState('');
    const [sortStatus, setSortStatus] = useState<DataTableSortStatus>({
        columnAccessor: 'name',
        direction: 'asc',
    });

    useEffect(() => {
        setLoading(true);
        uid && SellListShow(pageSize, page, '', '', uid, '', '', search, '', '', '', '', '', setItems, setRecords, setPage, setPageSize, setTotalCount, setTotalPage);
        setLoading(false);
    }, [page, pageSize, search, uid]);

    useEffect(() => {
        const data2 = sortBy(records, sortStatus.columnAccessor);
        setRecords(sortStatus.direction === 'desc' ? data2.reverse() : data2);
        setPage(1);
    }, [sortStatus]);

    const columns: any = [
        {
            accessor: 'order_id',
            title: 'Order Id',
            sortable: true,
            render: ({ order_id }: any) => (
                <div className="flex items-center font-semibold">
                    <div>#{order_id ? order_id : ''}</div>
                </div>
            ),
        },
        {
            accessor: 'createdAt',
            title: 'Date',
            sortable: true,
            render: ({ createdAt }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{createdAt ? formattingDate(createdAt) : ''}</div>
                </div>
            ),
        },

        {
            accessor: 'seller_id',
            title: 'Seller',
            sortable: true,
            render: ({ seller }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{seller ? seller.username : ''}</div>
                </div>
            ),
        },

        {
            accessor: 'payment_method',
            title: 'Payment Method',
            sortable: true,
            render: ({ payment_method }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{payment_method ? payment_method.name : ''}</div>
                </div>
            ),
        },
        {
            accessor: 'total_quantity',
            title: 'Quantity',
            sortable: true,
            render: ({ total_quantity }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{total_quantity}</div>
                </div>
            ),
        },
        {
            accessor: 'net_total',
            title: 'Total',
            sortable: true,
            render: ({ net_total }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{net_total} tk</div>
                </div>
            ),
        },
        {
            accessor: 'given_amount',
            title: 'Paid',
            sortable: true,
            render: ({ given_amount }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{given_amount} tk</div>
                </div>
            ),
        },
        {
            accessor: 'due',
            title: 'Due',
            sortable: true,
            render: ({ due }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{due} tk</div>
                </div>
            ),
        },
        {
            accessor: 'action',
            title: 'Actions',
            sortable: false,
            textAlignment: 'center',
            render: ({ unique_code }: any) => (
                <div className="mx-auto flex w-max items-center gap-4">

                    <Link href={`/admin/sell/order/preview/${unique_code}`} className="flex hover:text-primary">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                opacity="0.5"
                                d="M3.27489 15.2957C2.42496 14.1915 2 13.6394 2 12C2 10.3606 2.42496 9.80853 3.27489 8.70433C4.97196 6.49956 7.81811 4 12 4C16.1819 4 19.028 6.49956 20.7251 8.70433C21.575 9.80853 22 10.3606 22 12C22 13.6394 21.575 14.1915 20.7251 15.2957C19.028 17.5004 16.1819 20 12 20C7.81811 20 4.97196 17.5004 3.27489 15.2957Z"
                                stroke="currentColor"
                                strokeWidth="1.5"
                            />
                            <path d="M15 12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12C9 10.3431 10.3431 9 12 9C13.6569 9 15 10.3431 15 12Z" stroke="currentColor" strokeWidth="1.5" />
                        </svg>
                    </Link>
                    
                    <Link href={`/admin/sell/order/invoice/${unique_code}`} className="flex hover:text-primary">
                        <svg className="group-hover:!text-primary" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                opacity="0.5"
                                d="M3 10C3 6.22876 3 4.34315 4.17157 3.17157C5.34315 2 7.22876 2 11 2H13C16.7712 2 18.6569 2 19.8284 3.17157C21 4.34315 21 6.22876 21 10V14C21 17.7712 21 19.6569 19.8284 20.8284C18.6569 22 16.7712 22 13 22H11C7.22876 22 5.34315 22 4.17157 20.8284C3 19.6569 3 17.7712 3 14V10Z"
                                fill="currentColor"
                            />
                            <path
                                fillRule="evenodd"
                                clipRule="evenodd"
                                d="M12 5.25C12.4142 5.25 12.75 5.58579 12.75 6V7.25H14C14.4142 7.25 14.75 7.58579 14.75 8C14.75 8.41421 14.4142 8.75 14 8.75L12.75 8.75L12.75 10C12.75 10.4142 12.4142 10.75 12 10.75C11.5858 10.75 11.25 10.4142 11.25 10L11.25 8.75H9.99997C9.58575 8.75 9.24997 8.41421 9.24997 8C9.24997 7.58579 9.58575 7.25 9.99997 7.25H11.25L11.25 6C11.25 5.58579 11.5858 5.25 12 5.25ZM7.25 14C7.25 13.5858 7.58579 13.25 8 13.25H16C16.4142 13.25 16.75 13.5858 16.75 14C16.75 14.4142 16.4142 14.75 16 14.75H8C7.58579 14.75 7.25 14.4142 7.25 14ZM8.25 18C8.25 17.5858 8.58579 17.25 9 17.25H15C15.4142 17.25 15.75 17.5858 15.75 18C15.75 18.4142 15.4142 18.75 15 18.75H9C8.58579 18.75 8.25 18.4142 8.25 18Z"
                                fill="currentColor"
                            />
                        </svg>
                    </Link>
                </div>
            ),
        },
    ];

    return (
        <div className="panel">

            <div className="mb-4.5 flex flex-col justify-between gap-5 md:flex-row md:items-center">
                <div>
                    <h4>Sell History</h4>
                </div>
                <input type="text" className="form-input w-auto" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="datatables">
                <DataTable
                    className={`${isDark} table-hover whitespace-nowrap`}
                    records={records}
                    columns={columns}
                    highlightOnHover
                    totalRecords={totalCount}
                    recordsPerPage={pageSize}
                    fetching={loading}
                    page={page}
                    onPageChange={(p) => setPage(p)}
                    recordsPerPageOptions={PAGE_SIZES}
                    onRecordsPerPageChange={setPageSize}
                    sortStatus={sortStatus}
                    onSortStatusChange={setSortStatus}
                    paginationText={({ from, to, totalRecords }) => `Showing  ${from} to ${to} of ${totalRecords} entries`}
                />
            </div>
        </div>
    );
};

export default CustomerSellHistory;
