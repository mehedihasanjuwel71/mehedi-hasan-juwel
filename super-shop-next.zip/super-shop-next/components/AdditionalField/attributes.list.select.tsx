import { GetAttributeTypeData } from '@/store/actions/attributeType';
import { useState, useEffect } from 'react';
import Select from 'react-select';

const AttributeListSelectBox = ({ uid, setAttributes, arrayIndex, attributes }: any) => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});
    const [dataOption, setDataOption] = useState<any>([]);


    useEffect(() => {
        uid && GetAttributeTypeData(uid, setLoading, setData);
    }, [uid]);

    useEffect(() => {
        if (data && data.attributes && data.attributes.length > 0) {
            const options = data.attributes.map((item: any) => ({
                value: item.id,
                label: item.name,
                attribute_type_id: item.attribute_type_id,
            }));
            setDataOption(options);
        }
    }, [data]);

    const attributeHandler = (params: any, selectId: any) => {
        let newArray = [...attributes];
        newArray[selectId] = params;

        setAttributes(newArray);
    };

    return (
        <>
            <label className="mb-0 w-1/4 ltr:mr-2 rtl:ml-2">{data ? data.name : ''} :</label>
            <Select placeholder="Select attribute" value={attributes[arrayIndex]} options={dataOption} isMulti isSearchable={true} onChange={(params) => attributeHandler(params, arrayIndex)} />
        </>
    );
};

export default AttributeListSelectBox;
