import { PurchasedProductGetAction } from '@/store/actions/purchase';
import { useState, useEffect } from 'react';

const ProductForSell = ({ uid, arrayIndex, productInfo, setProductInfo }: any) => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});


    useEffect(() => {
        uid && PurchasedProductGetAction(uid, setLoading, setData);
    }, [uid]);

    return (
        <>
            <label className="mb-0 w-1/5 ltr:mr-2 rtl:ml-2">{data ? data.product?.name : ''} :</label>
            <input className="form-input flex-1" type="hidden" value={data?.id} />
            <input className="form-input flex-1" type="text" placeholder="Sell Price" value={data.sell_price} />
            <input
                className="form-input flex-1 ml-1"
                type="number"
                placeholder="Sell quantity"
                value={productInfo[arrayIndex]?.quantity}
                onChange={(e) => {
                    if(Number(e.target.value) < 0){
                        return
                    }
                    setProductInfo((prev: any) => {
                        const updatedInfo = [...prev];
                        updatedInfo[arrayIndex] = {
                            ...updatedInfo[arrayIndex],
                            quantity: parseInt(e.target.value),
                        };
                        return updatedInfo;
                    });
                }}
            />
        </>
    );
};

export default ProductForSell;
