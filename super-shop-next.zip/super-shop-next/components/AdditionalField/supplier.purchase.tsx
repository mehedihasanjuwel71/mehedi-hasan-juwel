import { formattingDate } from '@/libs/functions';
import { IRootState } from '@/store';
import { PurchaseListShow } from '@/store/actions/purchase';
import { sortBy } from 'lodash';
import { DataTable, DataTableSortStatus } from 'mantine-datatable';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Select from 'react-select';

const SupplierPurchaseHistory = ({ uid }: any) => {
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [totalPage, setTotalPage] = useState(0);
    const PAGE_SIZES = [10, 20, 30, 50, 100];
    const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
    const [items, setItems] = useState<any>([]);
    const [initialRecords, setInitialRecords] = useState(sortBy(items, 'id'));
    const [records, setRecords] = useState([]);

        const isDark = useSelector((state: IRootState) => state.themeConfig.theme) === 'dark' ? true : false;

    const [search, setSearch] = useState('');
    const [sortStatus, setSortStatus] = useState<DataTableSortStatus>({
        columnAccessor: 'name',
        direction: 'asc',
    });

    useEffect(() => {
        setLoading(true);
        uid && PurchaseListShow(pageSize, page, '', search, '', '', '', '', '', uid, '', '', '', '', setItems, setRecords, setPage, setPageSize, setTotalCount, setTotalPage);
        setLoading(false);
    }, [page, pageSize, search, uid]);

    useEffect(() => {
        const data2 = sortBy(records, sortStatus.columnAccessor);
        setRecords(sortStatus.direction === 'desc' ? data2.reverse() : data2);
        setPage(1);
    }, [sortStatus]);

    const columns: any = [
        {
            accessor: 'purchase_date',
            title: 'Date',
            sortable: true,
            render: ({ purchase_date }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{purchase_date ? formattingDate(purchase_date) : ''}</div>
                </div>
            ),
        },
        {
            accessor: 'supplier_id',
            title: 'Supplier',
            sortable: true,
            render: ({ supplier }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{supplier ? supplier.name : ''}</div>
                </div>
            ),
        },
        {
            accessor: 'branch_id',
            title: 'Branch',
            sortable: true,
            render: ({ branch }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{branch ? branch.name : ''}</div>
                </div>
            ),
        },
        {
            accessor: 'purchase',
            title: 'Purchase Status',
            sortable: true,
            render: ({ status }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{status ? 'Received' : 'Pending'}</div>
                </div>
            ),
        },

        {
            accessor: 'payment_method',
            title: 'Payment Method',
            sortable: true,
            render: ({ payment }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{payment ? payment.name : ''}</div>
                </div>
            ),
        },
        {
            accessor: 'shipping_method',
            title: 'Shipping Method',
            sortable: true,
            render: ({ shipping }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{shipping ? shipping.name : ''}</div>
                </div>
            ),
        },

        {
            accessor: 'total_amount',
            title: 'Total',
            sortable: true,
            render: ({ total_amount }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{total_amount} tk</div>
                </div>
            ),
        },
        {
            accessor: 'given_amount',
            title: 'Paid',
            sortable: true,
            render: ({ given_amount }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{given_amount} tk</div>
                </div>
            ),
        },
        {
            accessor: 'due_amount',
            title: 'Due',
            sortable: true,
            render: ({ due_amount }: any) => (
                <div className="flex items-center font-semibold">
                    <div>{due_amount} tk</div>
                </div>
            ),
        },
        {
            accessor: 'action',
            title: 'Actions',
            sortable: false,
            textAlignment: 'center',
            render: ({ unique_code }: any) => (
                <div className="mx-auto flex w-max items-center gap-4">

                    <Link title="Preview Purchase" href={`/admin/product/purchase/preview/${unique_code}`} className="flex hover:text-primary">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                opacity="0.5"
                                d="M3.27489 15.2957C2.42496 14.1915 2 13.6394 2 12C2 10.3606 2.42496 9.80853 3.27489 8.70433C4.97196 6.49956 7.81811 4 12 4C16.1819 4 19.028 6.49956 20.7251 8.70433C21.575 9.80853 22 10.3606 22 12C22 13.6394 21.575 14.1915 20.7251 15.2957C19.028 17.5004 16.1819 20 12 20C7.81811 20 4.97196 17.5004 3.27489 15.2957Z"
                                stroke="currentColor"
                                strokeWidth="1.5"
                            />
                            <path d="M15 12C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12C9 10.3431 10.3431 9 12 9C13.6569 9 15 10.3431 15 12Z" stroke="currentColor" strokeWidth="1.5" />
                        </svg>
                    </Link>

                </div>
            ),
        },
    ];

    return (
        <div className="panel">

            <div className="mb-4.5 flex flex-col justify-between gap-5 md:flex-row md:items-center">
                <div>
                    <h4>Purchase History</h4>
                </div>
                <input type="text" className="form-input w-auto" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="datatables">
                <DataTable
                    className={`${isDark} table-hover whitespace-nowrap`}
                    records={records}
                    columns={columns}
                    highlightOnHover
                    totalRecords={totalCount}
                    recordsPerPage={pageSize}
                    fetching={loading}
                    page={page}
                    onPageChange={(p) => setPage(p)}
                    recordsPerPageOptions={PAGE_SIZES}
                    onRecordsPerPageChange={setPageSize}
                    sortStatus={sortStatus}
                    onSortStatusChange={setSortStatus}
                    paginationText={({ from, to, totalRecords }) => `Showing  ${from} to ${to} of ${totalRecords} entries`}
                />
            </div>
        </div>
    );
};

export default SupplierPurchaseHistory;
