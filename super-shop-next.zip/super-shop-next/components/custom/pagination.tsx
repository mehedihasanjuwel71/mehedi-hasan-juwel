import React, { useCallback } from 'react';

const Pagination = ({ data, handlePaginationChange }: any) => {
    const { currentPage, totalPages } = data;

    const getPageNumbers = () => {
        const pageNumbers = [];
        for (let i = 1; i <= totalPages; i++) {
            pageNumbers.push(
                <button
                    key={i}
                    className={`mx-1 rounded-lg px-3 py-2 ${i === currentPage ? 'bg-gradient-to-br from-pink-500 to-orange-400   text-white' : 'bg-gray-200 text-gray-700'}`}
                    onClick={handlePageNumberClick(i)}
                >
                    {i}
                </button>
            );
        }
        return pageNumbers;
    };

    const handlePreviousClick = useCallback(() => {
        handlePaginationChange(currentPage - 1);
    }, [currentPage, handlePaginationChange]);

    const handleNextClick = useCallback(() => {
        if (currentPage >= totalPages) {
            return;
        }
        handlePaginationChange(currentPage + 1);
    }, [currentPage, handlePaginationChange, totalPages]);

    const handlePageNumberClick = useCallback(
        (pageNumber: number) => () => {
            handlePaginationChange(pageNumber);
        },
        [handlePaginationChange]
    );

    return (
        <div className="mt-5 flex justify-center">
            <button className="mx-1 rounded-lg bg-gray-200 px-4 py-2 " disabled={currentPage === 1} onClick={handlePreviousClick}>
                Previous
            </button>
            {getPageNumbers()}
            <button className="mx-1 rounded-lg bg-gray-200 px-4 py-2" disabled={currentPage === totalPages} onClick={handleNextClick}>
                Next
            </button>
        </div>
    );
};

export default Pagination;
