import { useState } from 'react';

const LimitedText = ({ text, limit }:any) => {
    const [showFullText, setShowFullText] = useState(false);

    const toggleShowFullText = () => {
        setShowFullText(!showFullText);
    };

    const displayedText = showFullText ? text : text.substring(0, limit);

    return (
        <div>
            <p>{displayedText}</p>
            {!showFullText && text.length > limit && <button onClick={toggleShowFullText}>Read More</button>}
        </div>
    );
};

export default LimitedText;
