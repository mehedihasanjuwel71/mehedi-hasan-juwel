import { useSelector } from "react-redux";

const Footer = () => {
    const { settings } = useSelector((state: any) => state.commonData);
    return (
        <div>
            <p className="pt-6 text-center dark:text-white-dark ltr:sm:text-left rtl:sm:text-right">
                © {settings?.copyright_text ? settings?.copyright_text : new Date().getFullYear() +' All rights reserved'}
            </p>
        </div>
    );
};

export default Footer;
