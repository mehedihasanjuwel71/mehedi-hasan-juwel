import { SalaryAddService, SalaryUpdateService } from '@/Service/staffSalary';
import { STATUS_ACTIVE, USER_MODULE_ADMIN, statusArray } from '@/libs/functions';
import { ShowBranchList } from '@/store/actions/branch';
import { SalaryGetAction } from '@/store/actions/salary';
import { showUserList } from '@/store/actions/user';
import { Dialog, Transition, Tab } from '@headlessui/react';
import { useRouter } from 'next/router';
import { useState, Fragment, useEffect } from 'react';
import { toast } from 'react-toastify';

const StaffSalaryModal = ({ modal1, setModal1, uid, setDependency }: any) => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});
    const [branchList, setBranchList] = useState<any>([]);
    const [staffList, setStaffList] = useState<any>([]);
    const [list, setList] = useState(0);
    const router = useRouter();

    const [credentials, setCredentials] = useState({
        uid: uid,
        staff_id: '',
        amount: 0,
        branch_id: '',
        status: '',
        salary_month: '',
        note: '',
    });
    const [processing, setProcessing] = useState(false);
    const submitForm = async (e: any) => {
        setProcessing(true);
        e.preventDefault();
        let response;
        if (uid) {
            response = await SalaryUpdateService(credentials);
        } else {
            response = await SalaryAddService(credentials);
        }
        if (response.success) {
            router.push('/admin/staff-salary');
            toast.success(response.message);
            resetCredential();
            setDependency(Math.random);
            setList(Math.random);
            setModal1(false);
        } else {
            toast.error(response.message);
        }
        setProcessing(false);
    };

    const resetCredential = () => {
        setCredentials({ uid: uid, staff_id: '', amount: 0, branch_id: '', status: '', salary_month: '', note: '' });
    };
    const closeModal = () => {
        resetCredential();
        setModal1(false);
    };

    useEffect(() => {
        uid && SalaryGetAction(uid?.toString(), setLoading, setData);
    }, [uid]);

    useEffect(() => {
        setCredentials({
            ...credentials,
            salary_month: data.salary_month ? data.salary_month.substring(0, 10) : '',
            amount: data ? Number(data.amount) : 0,
            branch_id: data ? data.branch_id : '',
            staff_id: data ? data.staff_id : '',
            status: data ? data.status : '',
            note: data ? data.note : '',
            uid: data ? data.unique_code : '',
        });
    }, [data]);

    useEffect(() => {
        ShowBranchList(200, 1, STATUS_ACTIVE, '', 'all', setBranchList, setBranchList);
    }, []);

    useEffect(() => {
        if (branchList.length > 0) {
            setCredentials({
                ...credentials,
                branch_id: branchList[0].id,
            });
        }
    }, [branchList]);
    useEffect(() => {
        showUserList(20, 1, STATUS_ACTIVE, USER_MODULE_ADMIN, '', '', '', '', 'all', setStaffList, setStaffList);
    }, []);

    return (
        <div className="mb-5">
            <Transition appear show={modal1} as={Fragment}>
                <Dialog as="div" open={modal1} onClose={() => setModal1(false)}>
                    <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
                        <div className="fixed inset-0" />
                    </Transition.Child>
                    <div className="fixed inset-0 z-[999] overflow-y-auto bg-[black]/60">
                        <div className="flex min-h-screen items-start justify-center px-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel as="div" className="panel my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                    <div className="flex items-center justify-between bg-[#fbfbfb] px-5 py-3 dark:bg-[#121c2c]">
                                        <div className="text-lg font-bold">{uid ? 'Update Cash' : 'Add Daily cash'}</div>
                                    </div>
                                    <div className="p-5">
                                        <form className="space-y-5" onSubmit={submitForm}>
                                            <div className="mt-1 px-4">
                                                <div className="flex flex-col justify-between lg:flex-row">
                                                    <div className="mb-6 w-full ltr:lg:mr-6 rtl:lg:ml-6">
                                                        <div className="mt-1 flex items-center">
                                                            <label className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">Branch</label>
                                                            <select
                                                                className="form-select flex-1"
                                                                value={credentials.branch_id}
                                                                onChange={(e) => setCredentials({ ...credentials, branch_id: e.target.value })}
                                                            >
                                                                <option value="">Select Branch</option>
                                                                {branchList &&
                                                                    branchList?.map((item: any) => (
                                                                        <option key={item.id} value={item.id}>
                                                                            {item.name}
                                                                        </option>
                                                                    ))}
                                                            </select>
                                                        </div>
                                                        <div className="mt-1 flex items-center">
                                                            <label className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">Staff</label>
                                                            <select
                                                                className="form-select flex-1"
                                                                value={credentials.staff_id}
                                                                onChange={(e) => setCredentials({ ...credentials, staff_id: e.target.value })}
                                                            >
                                                                <option value="">Select Staff</option>
                                                                {staffList &&
                                                                    staffList?.map((item: any) => (
                                                                        <option key={item.id} value={item.id}>
                                                                            {item.username}
                                                                        </option>
                                                                    ))}
                                                            </select>
                                                        </div>
                                                        <div className="mt-1 flex items-center">
                                                            <label htmlFor="name" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                                                Salary Month
                                                            </label>
                                                            <input
                                                                value={credentials.salary_month}
                                                                onChange={(e) => {
                                                                    setCredentials({ ...credentials, salary_month: e.target.value });
                                                                }}
                                                                type="date"
                                                                name="inv-date"
                                                                className="form-input w-2/3 flex-1"
                                                            />
                                                        </div>
                                                        <div className="mt-1 flex items-center">
                                                            <label className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">Salary</label>
                                                            <input
                                                                value={credentials.amount}
                                                                onChange={(e) => {
                                                                    setCredentials({ ...credentials, amount: Number(e.target.value) });
                                                                }}
                                                                type="number"
                                                                className="form-input flex-1"
                                                            />
                                                        </div>

                                                        <div className="mt-1 flex items-center">
                                                            <label className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">Note</label>
                                                            <input
                                                                value={credentials.note}
                                                                onChange={(e) => {
                                                                    setCredentials({ ...credentials, note: e.target.value });
                                                                }}
                                                                type="text"
                                                                className="form-input flex-1"
                                                            />
                                                        </div>
                                                        <div className="mt-1 flex items-center">
                                                            <label className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">Activation Status</label>
                                                            <select
                                                                className="form-select flex-1"
                                                                value={credentials.status}
                                                                onChange={(e) => setCredentials({ ...credentials, status: e.target.value })}
                                                            >
                                                                <option value="">Choose Status</option>
                                                                {Object.entries(statusArray()).map(([key, value]): any => (
                                                                    <option key={key} value={key}>
                                                                        {value}
                                                                    </option>
                                                                ))}
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-8 flex items-center justify-end">
                                                <button type="button" className="btn btn-outline-danger" onClick={() => closeModal()}>
                                                    Discard
                                                </button>
                                                <button onClick={() => submitForm} disabled={processing} type="submit" className="btn btn-primary ltr:ml-4 rtl:mr-4">
                                                    {processing ? 'Processing...' : 'Submit'}
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </div>
    );
};

export default StaffSalaryModal;
