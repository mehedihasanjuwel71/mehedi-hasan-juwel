
import { Dialog, Transition, Tab } from '@headlessui/react';
import { useRouter } from 'next/router';
import { Fragment } from 'react';

const AlertProductModal = ({ alertModal, setAlertModal,alertProductCount,alertProduct }: any) => {

    const router = useRouter();


    const closeModal = () => {
        setAlertModal(false);
    };

    return (
        <div className="mb-5">
            <Transition appear show={alertModal} as={Fragment}>
                <Dialog as="div" open={alertModal} onClose={() => setAlertModal(false)}>
                    <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
                        <div className="fixed inset-0" />
                    </Transition.Child>
                    <div className="fixed inset-0 z-[999] overflow-y-auto bg-[black]/60">
                        <div className="flex min-h-screen items-start justify-center px-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel as="div" className="panel my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                    <div className="flex items-center justify-between bg-[#fbfbfb] px-5 py-3 dark:bg-[#121c2c]">
                                        <div className="text-lg font-bold">{'Some products stock may expire soon, Please upgrade it soon'}</div>
                                    </div>
                                    <div className="p-5">
                                        <form className="space-y-5">
                                            <div className="mt-1 px-4">
                                                <div className="flex flex-col justify-between lg:flex-row">
                                                    <div className="mb-6 w-full ltr:lg:mr-6 rtl:lg:ml-6">
                                                        <ol>
                                                            {alertProduct &&
                                                                alertProduct.length > 0 &&
                                                                alertProduct.map((product: any) => (
                                                                    <li className="mt-1 font-bold text-red-600" key={product.id}>
                                                                        <div className="flex">
                                                                            <div className="w-max rounded-full bg-white-dark/30 p-0.5 ltr:mr-2 rtl:ml-2">
                                                                                <img
                                                                                    className="h-12 w-12 rounded-full object-cover"
                                                                                    src={product.featured_image ? product.featured_image : '/assets/images/demo.png'}
                                                                                    alt=""
                                                                                />
                                                                            </div>
                                                                            <div>{product.name}</div>
                                                                            <div>(available only {product.available} piece)</div>
                                                                        </div>
                                                                        
                                                                    </li>
                                                                ))}
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-8 flex items-center justify-end">
                                                <button type="button" className="btn btn-outline-danger" onClick={() => closeModal()}>
                                                    Discard
                                                </button>
                                                <button onClick={() => closeModal()} type="button" className="btn btn-primary ltr:ml-4 rtl:mr-4">
                                                    Ok
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </div>
    );
};

export default AlertProductModal;
