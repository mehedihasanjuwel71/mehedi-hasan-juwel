import { FileAddService } from '@/Service/fileSystem';
import { FILE_LIST_TYPE_GENERAL, STATUS_ACTIVE } from '@/libs/functions';
import { FileListShow } from '@/store/actions/fileSystem';
import { Dialog, Transition, Tab } from '@headlessui/react';
import { useRouter } from 'next/router';
import { useState, Fragment, useEffect } from 'react';
import { toast } from 'react-toastify';



const FileListModal = ({ modalImage, setModalImage, dependency, setImageId, setImagePath }: any) => {
    const [loading, setLoading] = useState(false);
    const [items, setItems] = useState<any>([]);
    const router = useRouter();
    const [image, setImage]: any = useState<any>();
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [upload, setUpload] = useState(0);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = event.target.files && event.target.files[0];
        if (selectedFile) {
            setImage(selectedFile);

            const reader = new FileReader();
            reader.onload = () => {
                setPreviewUrl(reader.result as string);
            };
            reader.readAsDataURL(selectedFile);
        }
    };
    const handleFileClick = (selectedImage:any,path:any) => {
        if (selectedImage) {
            toast.success('Image selected');
            setImageId(selectedImage);
            if (setImagePath) {
                setImagePath(path);
            }
            setModalImage(false);
        }
    };
    const [processing, setProcessing] = useState(false)
    const submitForm = async (e: any) => {
        setProcessing(true)
        e.preventDefault();
        const formData = new FormData();
        formData.append('files', image);
        const response = await FileAddService(formData);

        if (response.success) {
            toast.success(response.message);
            setImageId(response.data.unique_code);
            if (setImagePath) {
                setImagePath(response.data.file_path)
            }
            setUpload(Math.random);
            setPreviewUrl(null);
            setModalImage(false);
        } else {
            toast.error(response.message);
        }
        setProcessing(false)
    };

    const closeModal = () => {
        setPreviewUrl(null);
        setModalImage(false);
    };

    useEffect(() => {
        FileListShow(10, 1, STATUS_ACTIVE, FILE_LIST_TYPE_GENERAL, '','', setItems, setItems);
    }, [dependency, upload]);

    return (
        <div className="mb-5">
            <Transition appear show={modalImage} as={Fragment}>
                <Dialog as="div" open={modalImage} onClose={() => setModalImage(false)}>
                    <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
                        <div className="fixed inset-0" />
                    </Transition.Child>
                    <div className="fixed inset-0 z-[999] overflow-y-auto bg-[black]/60">
                        <div className="flex min-h-screen items-start justify-center px-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel as="div" className="panel my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                    <div className="flex items-center justify-between bg-[#fbfbfb] px-5 py-3 dark:bg-[#121c2c]">
                                        <div className="text-lg font-bold">{'Select File'}</div>
                                    </div>
                                    <div className="p-5">
                                        <form className="space-y-5" onSubmit={submitForm}>
                                            <div className="mt-1 px-4">
                                                <div className="flex flex-col justify-between lg:flex-row">
                                                    <div className="mb-6 w-full ltr:lg:mr-6 rtl:lg:ml-6">
                                                        <div className="custom-file-container" data-upload-id="myFirstImage">
                                                            <div className="label-container">
                                                                <label>Upload </label>
                                                                <input type="file" required onChange={handleFileChange} />
                                                            </div>

                                                            {previewUrl && (
                                                                <div>
                                                                    <h3>Preview Image:</h3>
                                                                    <img className="w-120 h-120" src={previewUrl} alt="Preview" />
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-8 flex items-center justify-end">
                                                <button onClick={() => submitForm} disabled={processing} type="submit" className="btn btn-primary ltr:ml-4 rtl:mr-4">
                                                    {processing ? 'Processing...' : 'Upload'}
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                    <div>
                                        <div className="mx-auto mb-5 grid max-w-[900px] grid-cols-4 justify-items-center gap-1">
                                            {items &&
                                                items.length > 0 &&
                                                items?.map((item: any) => (
                                                    <div key={item.id}>
                                                        <div className="flex h-[100px] w-[100px] flex-col justify-center rounded border border-white-light shadow-[1px_2px_12px_0_rgba(31,45,61,0.10)] dark:border-[#1b2e4b] sm:h-[100px] sm:w-[100px]">
                                                            <img onClick={() => handleFileClick(item.unique_code, item.file_path)} src={item.file_path} alt="" />
                                                        </div>
                                                    </div>
                                                ))}
                                        </div>
                                        <div className="mt-8 flex items-center justify-end">
                                            <button type="button" className="btn btn-outline-danger" onClick={() => closeModal()}>
                                                Discard
                                            </button>
                                        </div>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </div>
    );
};

export default FileListModal;
