import { UserUpdatePassword } from '@/Service/user';
import { Dialog, Transition, Tab } from '@headlessui/react';
import { useState, Fragment, useEffect } from 'react';
import { toast } from 'react-toastify';


const ChangeUserPasswordModal = ({ modal1, setModal1, uid }: any) => {

    const [credentials, setCredentials] = useState({
        id: uid,
        password: '',
        confirm_password: '',
    });
    const [processing, setProcessing] = useState(false)
    const submitForm = async (e: any) => {
        setProcessing(true)
        e.preventDefault();
        const response = await UserUpdatePassword(credentials);
        if (response.success) {
            toast.success(response.message);
            resetCredential();
            setModal1(false);
        } else {
            toast.error(response.message);
        }
        setProcessing(false)
    };
    useEffect(() => {
        setCredentials({ ...credentials, id: uid });
    }, [uid]);
    const resetCredential = () => {
        setCredentials(prev=>({...prev, password: '', confirm_password: '' }));
    }

  return (
      <div className="mb-5">
          <Transition appear show={modal1} as={Fragment}>
              <Dialog as="div" open={modal1} onClose={() => setModal1(false)}>
                  <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
                      <div className="fixed inset-0" />
                  </Transition.Child>
                  <div className="fixed inset-0 z-[999] overflow-y-auto bg-[black]/60">
                      <div className="flex min-h-screen items-start justify-center px-4">
                          <Transition.Child
                              as={Fragment}
                              enter="ease-out duration-300"
                              enterFrom="opacity-0 scale-95"
                              enterTo="opacity-100 scale-100"
                              leave="ease-in duration-200"
                              leaveFrom="opacity-100 scale-100"
                              leaveTo="opacity-0 scale-95"
                          >
                              <Dialog.Panel as="div" className="panel my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                  <div className="flex items-center justify-between bg-[#fbfbfb] px-5 py-3 dark:bg-[#121c2c]">
                                      <div className="text-lg font-bold">Change User Password</div>
                                      <button type="button" className="text-white-dark hover:text-dark" onClick={() => setModal1(false)}>
                                          <svg>...</svg>
                                      </button>
                                  </div>
                                  <div className="p-5">
                                      <form className="space-y-5" onSubmit={submitForm}>
                                          <div className="mt-1 px-4">
                                              <div className="flex flex-col justify-between lg:flex-row">
                                                  <div className="mb-6 w-full ltr:lg:mr-6 rtl:lg:ml-6">

                                                      <div className="mt-1 flex items-center">
                                                          <label htmlFor="password" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                                              Password
                                                          </label>
                                                          <input
                                                              value={credentials.password}
                                                              onChange={(e) => {
                                                                  setCredentials({ ...credentials, password: e.target.value });
                                                              }}
                                                              id="password"
                                                              type="password"
                                                              className="form-input flex-1"
                                                              placeholder="Enter Password"
                                                          />
                                                      </div>
                                                      <div className="mt-1 flex items-center">
                                                          <label htmlFor="confirm_password" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                                              Confirm Password
                                                          </label>
                                                          <input
                                                              value={credentials.confirm_password}
                                                              onChange={(e) => {
                                                                  setCredentials({ ...credentials, confirm_password: e.target.value });
                                                              }}
                                                              id="confirm_password"
                                                              type="password"
                                                              className="form-input flex-1"
                                                              placeholder="Enter Confirm Password"
                                                          />
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>

                                          <div className="mt-8 flex items-center justify-end">
                                              <button type="button" className="btn btn-outline-danger" onClick={() => setModal1(false)}>
                                                  Discard
                                              </button>
                                              <button onClick={() => submitForm} disabled={processing} type="submit" className="btn btn-primary ltr:ml-4 rtl:mr-4">
                                                  {processing ? 'Processing...' : 'Update'}
                                              </button>
                                          </div>
                                      </form>
                                  </div>
                              </Dialog.Panel>
                          </Transition.Child>
                      </div>
                  </div>
              </Dialog>
          </Transition>
      </div>
  );
}

export default ChangeUserPasswordModal;
