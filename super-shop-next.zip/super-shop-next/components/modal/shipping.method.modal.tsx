import { ShippingMethodAddService, ShippingMethodUpdateService } from '@/Service/shippingMethod';
import { statusArray } from '@/libs/functions';
import { ShippingMethodGet } from '@/store/actions/shippingMethod';
import { Dialog, Transition } from '@headlessui/react';
import { useRouter } from 'next/router';
import { useState, Fragment, useEffect } from 'react';
import { toast } from 'react-toastify';

const ShippingMethodModal = ({ modal1, setModal1, uid, setDependency }: any) => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<any>({});
    const router = useRouter();

    const [credentials, setCredentials] = useState({
        uid: uid,
        name: '',
        status: '',
        details: '',
    });
    const [processing, setProcessing] = useState(false);
    const submitForm = async (e: any) => {
        setProcessing(true)
        e.preventDefault();
        let response;
        if (uid) {
            response = await ShippingMethodUpdateService(credentials);
        } else {
            response = await ShippingMethodAddService(credentials);
        }
        if (response.success) {
            router.push('/admin/shipping-method');
            toast.success(response.message);
            resetCredential();
            setDependency(Math.random);
            setModal1(false);
        } else {
            toast.error(response.message);
        }
        setProcessing(false)
    };
    const resetCredential = () => {
        setCredentials({ name: '', status: '', uid: '', details: '' });
    };
    const closeModal = () => {
        resetCredential();
        setModal1(false);
    };
    useEffect(() => {
        uid && ShippingMethodGet(uid?.toString(), setLoading, setData);
    }, [uid]);

    useEffect(() => {
        setCredentials({
            ...credentials,
            name: data ? data.name : '',
            status: data ? data.status : '',
            details: data ? data.details : '',
            uid: data ? data.unique_code : '',
        });
    }, [data]);

    return (
        <div className="mb-5">
            <Transition appear show={modal1} as={Fragment}>
                <Dialog as="div" open={modal1} onClose={() => setModal1(false)}>
                    <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
                        <div className="fixed inset-0" />
                    </Transition.Child>
                    <div className="fixed inset-0 z-[999] overflow-y-auto bg-[black]/60">
                        <div className="flex min-h-screen items-start justify-center px-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel as="div" className="panel my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                    <div className="flex items-center justify-between bg-[#fbfbfb] px-5 py-3 dark:bg-[#121c2c]">
                                        <div className="text-lg font-bold">{uid ? 'Update Shipping Method' : 'Add New Shipping Method'}</div>
                                    </div>
                                    <div className="p-5">
                                        <form className="space-y-5" onSubmit={submitForm}>
                                            <div className="mt-1 px-4">
                                                <div className="flex flex-col justify-between lg:flex-row">
                                                    <div className="mb-6 w-full ltr:lg:mr-6 rtl:lg:ml-6">
                                                        <div className="mt-1 flex items-center">
                                                            <label htmlFor="name" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                                                Name
                                                            </label>
                                                            <input
                                                                value={credentials.name}
                                                                onChange={(e) => {
                                                                    setCredentials({ ...credentials, name: e.target.value });
                                                                }}
                                                                type="text"
                                                                className="form-input flex-1"
                                                            />
                                                        </div>
                                                        <div className="mt-1 flex items-center">
                                                            <label htmlFor="confirm_password" className="mb-0 w-1/3 ltr:mr-2 rtl:ml-2">
                                                                Activation Status
                                                            </label>
                                                            <select
                                                                id="status"
                                                                name="status"
                                                                className="form-select flex-1"
                                                                value={credentials.status}
                                                                onChange={(e) => setCredentials({ ...credentials, status: e.target.value })}
                                                            >
                                                                <option value="">Choose Status</option>
                                                                {Object.entries(statusArray()).map(([key, value]) => (
                                                                    <option key={key} value={key}>
                                                                        {value}
                                                                    </option>
                                                                ))}
                                                            </select>
                                                        </div>
                                                        <div className="mt-1 flex items-center">
                                                            <label htmlFor="short_name" className="mb-0 w-1/2 ltr:mr-2 rtl:ml-2">
                                                                Details
                                                            </label>
                                                            <textarea
                                                                className="form-textarea min-h-[80px]"
                                                                placeholder="About Shipping Method"
                                                                value={credentials.details}
                                                                onChange={(e) => {
                                                                    setCredentials({ ...credentials, details: e.target.value });
                                                                }}
                                                            ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-8 flex items-center justify-end">
                                                <button type="button" className="btn btn-outline-danger" onClick={() => closeModal()}>
                                                    Discard
                                                </button>
                                                <button onClick={() => submitForm} disabled={processing} type="submit" className="btn btn-primary ltr:ml-4 rtl:mr-4">
                                                    {processing ? 'Processing...' : 'Submit'}
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </div>
    );
};

export default ShippingMethodModal;
