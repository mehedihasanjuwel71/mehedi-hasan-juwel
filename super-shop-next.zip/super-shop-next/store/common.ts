import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import Cookie from 'js-cookie';
import Router from 'next/router';

export type commonType = {
    settings: {}
  user: {}
  isLoggedIn: false;
};

const initialState: any = {
    settings: {},
    user: {},
    isLoggedIn: false
};

export const commonSlice = createSlice({
    name: 'common',
    initialState,
    reducers: {
        setSettings: (state, action: PayloadAction<commonType>) => {
            state.settings = action.payload;
        },
        setUser: (state, action: PayloadAction<commonType>) => {
            state.user = action.payload;
            state.isLoggedIn = true;
        },
        LogoutAction: (dispatch: any) => {
            Cookie.remove('token');
            Router.replace('/login');
        },
    },
});

export const { setSettings, setUser, LogoutAction } = commonSlice.actions;
export default commonSlice.reducer;
