import { combineReducers, configureStore } from '@reduxjs/toolkit';
import themeConfigSlice from './themeConfigSlice';
import { commonSlice } from './common';

const rootReducer = combineReducers({
    themeConfig: themeConfigSlice,
    commonData: commonSlice.reducer,
});

export default configureStore({
    reducer: rootReducer,
});

export type IRootState = ReturnType<typeof rootReducer>;
