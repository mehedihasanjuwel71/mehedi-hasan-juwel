import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { ProductAddService, ProductDeleteService, ProductGetDataService, ProductGetService, ProductListService, ProductUpdateService } from '@/Service/product';

export const ProductAddAction = async (payload: any, router: any) => {
    const response = await ProductAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/product');
    } else {
        toast.error(response.message);
    }
};

export const ProductUpdateAction = async (payload: any, router: any) => {
    const response = await ProductUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        // router.push('/admin/product');
    } else {
        toast.error(response.message);
    }
};

export const ProductListShow = async (
    per_page: number,
    page: number,
    status: any,
    category_id: any,
    brand_id: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await ProductListService(per_page, page, status, category_id, brand_id, search, fromDate, toDate, dateType, list_size);

    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const ProductGet = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await ProductGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const ProductGetById = async (uid: number, setLoading: any, setData: any, productInfo: any, setProductInfo: any) => {
    setLoading(true);
    const response = await ProductGetDataService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const ProductDelete = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await ProductDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

