import { toast } from 'react-toastify';
import { AccountingDataGetService, DashboardDataService, LandingDataService, SettingDataService, UpdateAdminSetting } from '@/Service/setting';



export const SettingUpdateAction = async (payload: any, router: any) => {
    const response = await UpdateAdminSetting(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/settings');
    } else {
        toast.error(response.message);
    }
};

export const DashboardDataAction = async (
    setData: any,
    setRecentOrder: any,
    setTopProduct: any,
) => {
    const response = await DashboardDataService();
    if (response.success == true) {
        setData(response.data);
        setRecentOrder(response.data.recent_order);
        setTopProduct(response.data.top_selling_product);
    }
};

export const LandingDataAction = async (
    group: any,
    setData: any,
) => {
    const response = await LandingDataService(group);
    if (response.success == true) {
        setData(response.data);
    }
};

export const SettingDataAction = async (
    group: any,
    setData: any,
) => {
    const response = await SettingDataService(group);
    if (response.success == true) {
        setData(response.data);
    }
};

export const AccountingDataGetAction = async (
    fromDate: any,
    toDate: any,
    dateType: any,
    setData: any,
) => {
    const response = await AccountingDataGetService(fromDate,toDate,dateType);
    if (response.success == true) {
        setData(response.data);
    }
};



