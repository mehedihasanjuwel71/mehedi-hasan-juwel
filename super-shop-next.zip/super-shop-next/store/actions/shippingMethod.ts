import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { ShippingMethodAddService, ShippingMethodDeleteService, ShippingMethodGetService, ShippingMethodListService, ShippingMethodUpdateService } from '@/Service/shippingMethod';


export const ShippingMethodAddAction = async (payload: any, router: any) => {
    const response = await ShippingMethodAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/shipping-method');
    } else {
        toast.error(response.message);
    }
};

export const ShippingMethodUpdateAction = async (payload: any, router: any) => {
    const response = await ShippingMethodUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/shipping-method');
    } else {
        toast.error(response.message);
    }
};

export const ShippingMethodListShow = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await ShippingMethodListService(per_page, page, status, search, list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const ShippingMethodGet = async (uid: string, setLoading: any, setData: any) => {
    setLoading(true);
    const response = await ShippingMethodGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const ShippingMethodDelete = async (uid: string, setLoading: any) => {
    setLoading(true);
    const response = await ShippingMethodDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

