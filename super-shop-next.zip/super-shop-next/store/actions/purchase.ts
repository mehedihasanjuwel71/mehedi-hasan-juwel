import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { PurchaseAddService, PurchaseDeleteService, PurchaseDueAdjustService, PurchaseGetService, PurchaseListProductService, PurchaseListService, PurchaseUpdateService, PurchasedProductGetService, UpdateSellPriceService } from '@/Service/purchase';

export const PurchaseAddAction = async (payload: any, router: any) => {
    const response = await PurchaseAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/product/purchase/list');
    } else {
        toast.error(response.message);
    }
};


export const PurchaseUpdateAction = async (payload: any, router: any) => {
    const response = await PurchaseUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/product/purchase/list');
    } else {
        toast.error(response.message);
    }
};

export const PurchaseDueAdjustAction = async (payload: any, router: any) => {
    const response = await PurchaseDueAdjustService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/product/purchase/list');
    } else {
        toast.error(response.message);
    }
};

export const UpdateSellPriceAction = async (payload: any, router: any) => {
    const response = await UpdateSellPriceService(payload);
    if (response.success) {
        toast.success(response.message);
        // router.push('/admin/product/purchase/list');
    } else {
        toast.error(response.message);
    }
};

export const PurchaseListShow = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    due_status: any,
    branch_id: any,
    supplier_id: any,
    added_by: any,
    payment_method: any,
    shipping_method: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await PurchaseListService(per_page, page, status, search, fromDate, toDate, dateType, due_status, branch_id, supplier_id, added_by, payment_method, shipping_method, list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const PurchaseGet = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await PurchaseGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const PurchasedProductGetAction = async (
    uid: any,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await PurchasedProductGetService(uid);

    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const PurchaseDelete = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await PurchaseDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

export const PurchaseListProductAction = async (
    payload: any,
    setItems: any,
    setRecords: any,
) => {
    const response = await PurchaseListProductService(payload);
    if (response.success == true) {
        setItems(response.data);
        setRecords(response.data);
    }
};
