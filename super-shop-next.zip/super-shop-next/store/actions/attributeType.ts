import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { AttributeTypeAddService, AttributeTypeUpdateService, AttributeTypeListService, AttributeTypeGetService, AttributeTypeDeleteService, AttributeTypeGetDataService } from '@/Service/attributeType';

export const AttributeTypeAddAction = async (payload: any, router: any) => {
    const response = await AttributeTypeAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/attribute-type');
    } else {
        toast.error(response.message);
    }
};

export const AttributeTypeUpdateAction = async (payload: any, router: any) => {
    const response = await AttributeTypeUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/attribute-type');
    } else {
        toast.error(response.message);
    }
};

export const ShowAttributeTypeList = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size:any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await AttributeTypeListService(per_page, page, status, search,list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const GetAttributeType = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await AttributeTypeGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const GetAttributeTypeData = async (
    uid: number,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await AttributeTypeGetDataService(uid);

    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const DeleteAttributeType = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await AttributeTypeDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

