import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { PermissionListService, RoleAddService, RoleDeleteService, RoleGetService, RoleListService, RoleUpdateService } from '@/Service/role';

export const RoleAddAction = async (payload: any, router: any) => {
    const response = await RoleAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/role');
    } else {
        toast.error(response.message);
    }
};

export const RoleUpdateAction = async (payload: any, router: any) => {
    const response = await RoleUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/role');
    } else {
        toast.error(response.message);
    }
};

export const RoleListAction = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await RoleListService(per_page, page, status, search, list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const PermissionListAction = async (
    group: any,
    search: any,
    setItems: any,
    setRecords: any,
) => {
    const response = await PermissionListService(group, search);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
    }
};

export const RoleGetAction = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await RoleGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const RoleDeleteAction = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await RoleDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

