import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { ExpenseAddService, ExpenseDeleteService, ExpenseGetService, ExpenseListService, ExpenseUpdateService } from '@/Service/expense';

export const ExpenseAddAction = async (payload: any, router: any) => {
    const response = await ExpenseAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/expense');
    } else {
        toast.error(response.message);
    }
};

export const ExpenseUpdateAction = async (payload: any, router: any) => {
    const response = await ExpenseUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/expense');
    } else {
        toast.error(response.message);
    }
};

export const ExpenseListShow = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    branch_id: any,
    category_id: any,
    expense_for: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await ExpenseListService(
        per_page,
        page,
        status,
        search,
        branch_id,
        category_id,
        expense_for,
        fromDate,
        toDate,
        dateType,
        list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const ExpenseGet = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await ExpenseGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const ExpenseDelete = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await ExpenseDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

