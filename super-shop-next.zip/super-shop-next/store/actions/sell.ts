import { toast } from 'react-toastify';
import { PurchasedProductListService, SellCreateService, SellDeleteService, SellDueAdjustService, SellGetService, SellListService, SellReturnCreateService, SellReturnDeleteService, SellReturnGetService, SellReturnListService, SellReturnUpdateService, SellUpdateService } from '@/Service/sell';

export const SellCreateAction = async (payload: any, router: any, actionType:string) => {
    const response = await SellCreateService(payload);
    if (response.success) {
        toast.success(response.message);
        if (actionType === 'sellAndPrint') {
            router.push('/admin/sell/order/invoice/'+response.data.unique_code+'?shouldAutoClick=true');
        } else {
            router.push('/admin/sell/order/invoice/'+response.data.unique_code);
        }

    } else {
        toast.error(response.message);
    }
};

export const SellUpdateAction = async (payload: any, router: any) => {
    const response = await SellUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/sell/order/invoice/' + response.data.unique_code);
    } else {
        toast.error(response.message);
    }
};

export const SellDueAdjustAction = async (payload: any, router: any) => {
    const response = await SellDueAdjustService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/sell/order');
    } else {
        toast.error(response.message);
    }
};

export const SellListShow = async (
    per_page: number,
    page: number,
    status: any,
    branch_id: any,
    customer_id: any,
    seller_id: any,
    payment_type: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    dueStatus: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await SellListService(per_page, page, status, branch_id, customer_id, seller_id, payment_type, search, fromDate, toDate, dateType, dueStatus, list_size);

    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const PurchasedProductListShow = async (
    per_page: number,
    page: number,
    status: any,
    category_id: any,
    brand_id: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
    available_type:any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await PurchasedProductListService(
        per_page,
        page,
        status,
        category_id,
        brand_id,
        search,
        fromDate,
        toDate,
        dateType,
        list_size,
        available_type
    );

    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const SellGetAction = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await SellGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const SellDeleteAction = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await SellDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

export const SellReturnCreateAction = async (payload: any, router: any) => {
    const response = await SellReturnCreateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/sell/order/return');
    } else {
        toast.error(response.message);
    }
};

export const SellReturnUpdateAction = async (payload: any, router: any) => {
    const response = await SellReturnUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/sell/order/return');
    } else {
        toast.error(response.message);
    }
};


export const SellReturnListAction = async (
    per_page: number,
    page: number,
    status: any,
    sell_id: any,

    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,

    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await SellReturnListService(per_page, page, status, sell_id, search, fromDate, toDate, dateType, list_size);

    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};


export const SellReturnGetAction = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await SellReturnGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const SellReturnDeleteAction = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await SellReturnDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};
