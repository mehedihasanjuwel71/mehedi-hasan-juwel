import { CommonSetting } from "@/Service/common";
import { toast } from "react-toastify";
import Cookie from "js-cookie";
import { Profile } from "@/Service/auth";
import { setSettings, setUser } from "../common";


export const initialSettings = () => async (dispatch :any) => {
    const response = await CommonSetting();
    if (response.success) {
        dispatch(setSettings(response.data));
    } else {
        toast.error(response.message);
    }

    const token = Cookie.get("token");
    if (token) {
        const userResponse = await Profile();
        if (response.success) {
            const user = userResponse.data;
            dispatch(setUser(user.data));
        }
    }
}
