import { toast } from 'react-toastify';
import Cookie from 'js-cookie';
import { CustomerAddService, CustomerDeleteService, CustomerListService, CustomerUpdateService, ProfileUpdateService, UpdatePassword, UserAddService, UserDeleteService, UserGetService, UserListService, UserUpdatePassword, UserUpdateService } from '@/Service/user';

export const UserAddAction = async (payload: any, router: any, dispatch: any) => {
    const response = await UserAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/user');
    } else {
        toast.error(response.message);
    }
};

export const UserUpdateAction = async (payload: any, router: any, dispatch: any) => {
    const response = await UserUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/user');
    } else {
        toast.error(response.message);
    }
};

export const ProfileUpdateAction = async (payload: any, router: any) => {
    const response = await ProfileUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/profile');
    } else {
        toast.error(response.message);
    }
};
export const CustomerAddAction = async (payload: any, router: any, dispatch: any) => {
    const response = await CustomerAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/customer');
    } else {
        toast.error(response.message);
    }
};

export const CustomerUpdateAction = async (payload: any, router: any, dispatch: any) => {
    const response = await CustomerUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/customer');
    } else {
        toast.error(response.message);
    }
};

export const UserUpdatePasswordAction = async (payload: any, router: any) => {
    const response = await UserUpdatePassword(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/user');
    } else {
        toast.error(response.message);
    }
};

export const UpdatePasswordAction = async (payload: any, router: any) => {
    const response = await UpdatePassword(payload);
    if (response.success) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
};

export const showUserList = async (
    per_page: number,
    page: number,
    status: any,
    module: number,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await UserListService(per_page, page, status, module, search, fromDate, toDate, dateType, list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const customerListAction = async (
    per_page: number,
    page: number,
    status: any,
    module: number,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await CustomerListService(per_page, page, status, module, search, fromDate, toDate, dateType, list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const getUser = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await UserGetService(uid);

    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const deleteUser = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await UserDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

export const customerDeleteAction = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await CustomerDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

