import { CashAddService, CashDeleteService, CashGetService, CashListService, CashUpdateService } from '@/Service/dailyCash';
import { toast } from 'react-toastify';

export const CashAddAction = async (payload: any, router: any) => {
    const response = await CashAddService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/daily-cash/list');
    } else {
        toast.error(response.message);
    }
};


export const CashUpdateAction = async (payload: any, router: any) => {
    const response = await CashUpdateService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/admin/daily-cash/list');
    } else {
        toast.error(response.message);
    }
};


export const CashListAction = async (
    per_page: number,
    page: number,
    status: any,
    search: any,
    fromDate: any,
    toDate: any,
    dateType: any,
    branch_id: any,
    list_size: any,
    setItems: any,
    setRecords: any,
    setPage?: any,
    setPageSize?: any,
    setTotalCount?: any,
    setTotalPage?: any
) => {
    const response = await CashListService(per_page, page, status, search, fromDate, toDate, dateType, branch_id, list_size);
    if (response.success == true) {
        setItems(response.data.data);
        setRecords(response.data.data);
        setPage ? setPage(response.data.current_page) : 1;
        setPageSize ? setPageSize(response.data.per_page) : 10;
        setTotalCount ? setTotalCount(response.data.total_count) : 0;
        setTotalPage ? setTotalPage(response.data.total_page) : 0;
    }
};

export const CashGetAction = async (
    uid: string,
    setLoading: any,
    setData:any,
) => {
    setLoading(true);
    const response = await CashGetService(uid);
    if (response.success == true) {
        setData(response.data);
    }
    setLoading(false);
};

export const CashDeleteAction = async (
    uid: string,
    setLoading: any,
) => {
    setLoading(true);
    const response = await CashDeleteService(uid);
    if (response.success == true) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
    setLoading(false);
};

