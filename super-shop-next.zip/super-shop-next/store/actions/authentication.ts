import { ForgotPasswordService, LoginService, ParentUser, RegisterService, ResetPasswordService } from "@/Service/auth"
import { toast } from "react-toastify";
import Cookie from "js-cookie";
import { setUser } from "../common";
import Router from 'next/router';


export const LoginAction = async (payload: any,router :any, dispatch: any) => {
    const response = await LoginService(payload);
    if (response.success) {
        toast.success(response.message);
        const accessToken = response.data.accessToken;
        Cookie.set('token', accessToken);
        dispatch(setUser(response.data.user));
        router.push('/admin');
    } else {
        toast.error(response.message);
    }
}

export const ForgotPasswordAction = async (payload: any,router :any, dispatch: any) => {
    const response = await ForgotPasswordService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/reset-password?email='+payload.email);
    } else {
        toast.error(response.message);
    }
}

export const ResetPasswordAction = async (payload: any,router :any, dispatch: any) => {
    const response = await ResetPasswordService(payload);
    if (response.success) {
        toast.success(response.message);
        router.push('/login');
    } else {
        toast.error(response.message);
    }
}

export const RegisterAction = async (payload: any) => {
    const response = await RegisterService(payload);
    if (response.success) {
        toast.success(response.message);
    } else {
        toast.error(response.message);
    }
}
// export const LogoutAction = () => async (dispatch: any) => {
//     Cookie.remove('token');
//     Router.replace('/login');
// };
